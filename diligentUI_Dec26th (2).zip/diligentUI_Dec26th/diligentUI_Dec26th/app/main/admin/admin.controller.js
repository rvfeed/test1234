(function ()
{
    'use strict';

    angular
        .module('app.admin')
        .controller('adminController', adminController);

    /** @ngInject */
    function adminController($scope)
    {
	// if(localStorage.permission == "SuperAdmin"){
	// $("md-sidenav").hide();
	// }
	
	function notesController($scope, $mdDialog) {
  $scope.notestitle = localStorage.tabvalue;
	  var vm = this;
	  $scope.taToolbar = [
            ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'pre', 'quote', 'bold', 'italics', 'underline', 'strikeThrough', 'ul', 'ol', 'redo', 'undo', 'clear'],
            ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent', 'html', 'insertImage', 'insertLink', 'insertVideo', 'wordcount', 'charcount']
        ];
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  $scope.notespage = true;
$scope.savepopup = function(){
$mdDialog.cancel();
}
  }
  $scope.NoteSecFlag = false;
 
		
		$scope.notesInfo = function(ev,value) {
		
    $mdDialog.show({
      controller: notesController,
      templateUrl: 'app/main/add-customer/views/manual/form/notespage.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	


 
    }
})();