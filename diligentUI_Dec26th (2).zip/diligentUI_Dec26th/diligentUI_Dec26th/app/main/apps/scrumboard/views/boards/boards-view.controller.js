(function ()
{
    'use strict';

    angular
        .module('app.scrumboard')
        .controller('BoardsViewController', BoardsViewController);

    /** @ngInject */
    function BoardsViewController(BoardList, customerList)
    {
        var vm = this;
debugger;
        // Data
        vm.boardList = BoardList.data;
		vm.contacts = customerList.data;

        // Methods

        //////////
    }
})();