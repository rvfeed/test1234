(function ()
{
    'use strict';

    angular
        .module('app.gantt-chart', [
            'gantt',
            'gantt.sortable',
            'gantt.movable',
            'gantt.drawtask',
            'gantt.tooltips',
            'gantt.bounds',
            'gantt.progress',
            'gantt.table',
            'gantt.tree',
            'gantt.groups',
            'gantt.dependencies',
            'gantt.overlap',
            'ngAnimate',
            'gantt.resizeSensor'
        ])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider)
    {

        $stateProvider.state('app.gantt-chart', {
            url    : '/add-customer',
            views  : {
                'content@app': {
                    templateUrl: 'app/main/apps/gantt-chart/gantt-chart.html',
                    controller : 'GanttChartController as vm'
                }
            },
            resolve: {
                Tasks    : function (msApi)
                {
                    return msApi.resolve('ganttChart.tasks@get');
                },
                Timespans: function (msApi)
                {
                    return msApi.resolve('ganttChart.timespans@get');
                }
            }
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/apps/gantt-chart');

        // Navigation
        msNavigationServiceProvider.saveItem('apps.gantt-chart', {
            title : 'Add Customer',
            icon  : 'icon-calendar-text',
            state : 'app.gantt-chart',
            weight: 2
        });

        // Api
        msApiProvider.register('ganttChart.tasks', ['app/data/gantt-chart/tasks.json']);
        msApiProvider.register('ganttChart.timespans', ['app/data/gantt-chart/timespans.json']);

    }

})();