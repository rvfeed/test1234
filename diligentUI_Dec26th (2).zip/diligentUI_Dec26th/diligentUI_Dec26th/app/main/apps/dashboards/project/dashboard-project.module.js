(function ()
{
    'use strict';

    angular
        .module('app.dashboards.project', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, msApiProvider)
    {
        // State
        $stateProvider.state('app.dashboards_project', {
            url      : '/dashboard',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/apps/dashboards/project/dashboard-project.html',
                    controller : 'DashboardProjectController as vm'
                }
            },
            resolve  : {
                DashboardData: function (msApi)
                {
                    return msApi.resolve('dashboard.project@get');
                },
				Contacts: function (msApi)
                {
                    return msApi.resolve('dashboard.contact@get');
                },
				Contacts1: function (msApi)
                {
                    return msApi.resolve('dashboard.contact1@get');
                },
				Contacts2: function (msApi)
                {
                    return msApi.resolve('dashboard.contact2@get');
                },
				Contacts3: function (msApi)
                {
                    return msApi.resolve('dashboard.contact3@get');
                },
				TableData1: function (msApi)
                {
                    return msApi.resolve('dashboard.table1@get');
                },
				TableData2: function (msApi)
                {
                    return msApi.resolve('dashboard.table2@get');
                },
				TableData3: function (msApi)
                {
                    return msApi.resolve('dashboard.table3@get');
                },
				TableData4: function (msApi)
                {
                    return msApi.resolve('dashboard.table4@get');
                },
				TableData5: function (msApi)
                {
                    return msApi.resolve('dashboard.table5@get');
                },
				TableData6: function (msApi)
                {
                    return msApi.resolve('dashboard.table6@get');
                },
				TableData7: function (msApi)
                {
                    return msApi.resolve('dashboard.table7@get');
                },
				TableData8: function (msApi)
                {
                    return msApi.resolve('dashboard.table8@get');
                },
				Announcements: function (msApi)
                {
                    return msApi.resolve('dashboard.activities@get');
                }
            
            },
			
            bodyClass: 'dashboard-project'
        });

        // Api
        msApiProvider.register('dashboard.project', ['app/data/dashboard/project/data.json']);
		msApiProvider.register('dashboard.contact', ['app/data/dashboard/project/contacts.json']);
		msApiProvider.register('dashboard.contact1', ['app/data/dashboard/project/contacts1.json']);
		msApiProvider.register('dashboard.contact2', ['app/data/dashboard/project/contacts2.json']);
		msApiProvider.register('dashboard.contact3', ['app/data/dashboard/project/contacts3.json']);
		msApiProvider.register('dashboard.table1', ['app/data/dashboard/project/table1.json']);
		msApiProvider.register('dashboard.table2', ['app/data/dashboard/project/table2.json']);
		msApiProvider.register('dashboard.table3', ['app/data/dashboard/project/table3.json']);
		msApiProvider.register('dashboard.table4', ['app/data/dashboard/project/table4.json']);
		msApiProvider.register('dashboard.table5', ['app/data/dashboard/project/table5.json']);
		msApiProvider.register('dashboard.table6', ['app/data/dashboard/project/table6.json']);
		msApiProvider.register('dashboard.table7', ['app/data/dashboard/project/table7.json']);
		msApiProvider.register('dashboard.table8', ['app/data/dashboard/project/table8.json']);
		msApiProvider.register('dashboard.activities', ['app/data/quick-panel/activities.json']);
		
    }

})();