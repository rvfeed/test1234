(function ()
{
    'use strict';

    angular
        .module('app.dashboards.project')
        .controller('DashboardProjectController', DashboardProjectController);

    /** @ngInject */
    function DashboardProjectController($scope, $interval, $mdSidenav, DashboardData, TableData1, TableData2, TableData3, TableData4,TableData5, TableData6, TableData7, TableData8, Announcements, Contacts, Contacts1, Contacts2, Contacts3, DTOptionsBuilder, DTColumnDefBuilder, $location, $mdDialog, $timeout, $http, $window)
    {
		
		$("#kitkat").hide();
		$timeout(function(){
	    if(localStorage.permission == "admin"){
			$("#menu1").hide();
			$("#menu6").show();
		}else if(localStorage.permission == "maker"){
			$("#menu1").show();
			$("#menu6").hide();
		}
		},2000);
		$scope.sampleClick = function(){
			debugger;
			$http({
            url : 'assets/tabIcon/sample.pdf',
            method : 'GET',
            headers : {
                'Content-type' : 'application/pdf'
            },
            responseType : 'arraybuffer'
        }).success(function(data, status, headers, config) {
            var pdfFile = new Blob([ data ], {
                type : 'application/pdf'
            });
            var pdfUrl = URL.createObjectURL(pdfFile);
            $window.open(pdfUrl);
        }).error(function(data, status, headers, config) {
            alert('Sorry, something went wrong')
        });
		}
		
		
		
		 $scope.showviewflag = function(ev) {
		$mdDialog.show({
		  controller: PotentialController,
		  templateUrl: 'app/main/add-customer/views/manual/form/comparePopUp.html',
		  parent: angular.element(document.body),
		  targetEvent: ev,
		  clickOutsideToClose:true,
		  fullscreen : true
		})
		
		 };
		 
		 $scope.getNewDate = function(data){
			 vm.tableValue5 = TableData5.datesort1;
		 }
		 
		 $scope.getNewDate1 = function(data){
			 vm.tableValue5 = TableData5.datesort2;
		 }
		 
		 $scope.getNewDate2 = function(data){
			 vm.tableValue6 = TableData6.datesort1;
		 }
		 
		 $scope.getNewDate3 = function(data){
			 vm.tableValue6 = TableData6.datesort2;
		 }
		 
		 $scope.getNewDate4 = function(data){
			 vm.tableValue7 = TableData7.datesort1;
		 }
		 
		 $scope.getNewDate5 = function(data){
			 vm.tableValue7 = TableData7.datesort2;
		 }
		 
		 $scope.getNewDate6 = function(data){
			 vm.tableValue8 = TableData8.datesort1;
		 }
		 
		 $scope.getNewDate7 = function(data){
			 vm.tableValue8 = TableData8.datesort2;
		 }
		 
		 
		
	  function PotentialController($scope, $mdDialog) {
  $scope.potentialTableFn = function() {
    $mdDialog.hide();
	var vm = this;
		vm.potentials = Potential.data;
		$scope.showPercentageFlag = true;
		$scope.showPotentialMatchFlag1 = true;
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  }
		
		
	$('.ms-theme-options-button3').show();
		$('.ms-theme-options-button4').show();
	  
  $scope.graphCon = function(data){
	  if(data == "LW2"){
		  var fusioncharts = new FusionCharts({
    type: 'pareto2d',
    renderAt: 'chart-container',
    width: '360',
    height: '260',
    dataFormat: 'json',
    dataSource: {
        "chart": {
            "sYAxisname": "Cumulative Percentage",
            "showHoverEffect": "1",
			"paletteColors": "#c7ecfc",
            "theme": "fint"

        },
        "data": [{
            "label": "SDD - A",
            "value": "7"
        }, {
            "label": "CIP",
            "value": "10"
        }, {
            "label": "SDD - B",
            "value": "12"
        }, {
            "label": "SPDD",
            "value": "11"
        }, {
            "label": "LDD",
            "value": "13"
        }]
    }
}
);
    fusioncharts.render();
	$scope.errorValue = 53;	  
	  }else if(data == "TW"){
		  var fusioncharts = new FusionCharts({
    type: 'pareto2d',
    renderAt: 'chart-container',
    width: '360',
    height: '260',
    dataFormat: 'json',
    dataSource: {
        "chart": {
            "sYAxisname": "Cumulative Percentage",
            "showHoverEffect": "1",
			"paletteColors": "#c7ecfc",
            "theme": "fint"

        },
        "data": [{
            "label": "SDD - A",
            "value": "5"
        }, {
            "label": "CIP",
            "value": "13"
        }, {
            "label": "SDD - B",
            "value": "9"
        }, {
            "label": "SPDD",
            "value": "11"
        }, {
            "label": "LDD",
            "value": "15"
        }]
    }
}
);
    fusioncharts.render();
	$scope.errorValue = 53;	  
	  }else if(data == "LW"){
		var fusioncharts = new FusionCharts({
    type: 'pareto2d',
    renderAt: 'chart-container',
   width: '360',
    height: '260',
    dataFormat: 'json',
    dataSource: {
        "chart": {
            "sYAxisname": "Cumulative Percentage",
            "showHoverEffect": "1",
			"paletteColors": "#c7ecfc",
            "theme": "fint"

        },
        "data": [{
            "label": "SDD - A",
            "value": "5"
        }, {
            "label": "CIP",
            "value": "13"
        }, {
            "label": "SDD - B",
            "value": "9"
        }, {
            "label": "SPDD",
            "value": "11"
        }, {
            "label": "LDD",
            "value": "15"
        }]
    }
}
);
    fusioncharts.render(); 
$scope.errorValue = 53;	
	  }else if(data == "2W"){
		var fusioncharts = new FusionCharts({
    type: 'pareto2d',
    renderAt: 'chart-container',
   width: '360',
    height: '260',
    dataFormat: 'json',
    dataSource: {
        "chart": {
            "sYAxisname": "Cumulative Percentage",
            "showHoverEffect": "1",
			"paletteColors": "#c7ecfc",
            "theme": "fint"

        },
        "data": [{
            "label": "SDD - A",
            "value": "9"
        }, {
            "label": "CIP",
            "value": "14"
        }, {
            "label": "SDD - B",
            "value": "5"
        }, {
            "label": "SPDD",
            "value": "11"
        }, {
            "label": "LDD",
            "value": "10"
        }]
    }
}
);
    fusioncharts.render(); 
$scope.errorValue = 49;	
	  }else if(data == "LW1"){
		var fusioncharts = new FusionCharts({
    type: 'pareto2d',
    renderAt: 'chart-container',
   width: '360',
    height: '260',
    dataFormat: 'json',
    dataSource: {
        "chart": {
            "sYAxisname": "Cumulative Percentage",
            "showHoverEffect": "1",
			"paletteColors": "#c7ecfc",
            "theme": "fint"

        },
        "data": [{
            "label": "SDD - A",
            "value": "7"
        }, {
            "label": "CIP",
            "value": "10"
        }, {
            "label": "SDD - B",
            "value": "15"
        }, {
            "label": "SPDD",
            "value": "7"
        }, {
            "label": "LDD",
            "value": "55"
        }]
    }
}
);
    fusioncharts.render();
$scope.errorValue = 94;	
	  }
    
  }
  
  $timeout(function(){
	$scope.graphCon("TW");  
  },2000);
  
  
  

	
	
        var vm = this;
		$scope.policytab = function(data){
			if(data == "one"){
				vm.tableValue5 = TableData5.data2;
			}else if(data == "two"){
				vm.tableValue5 = TableData5.data1;
			}else if(data == "three"){
				vm.tableValue5 = TableData5.data;
			}
		}
		
		$scope.policytab = function(data){
			if(data == "one"){
				vm.tableValue5 = TableData5.data2;
			}else if(data == "two"){
				vm.tableValue5 = TableData5.data1;
			}else if(data == "three"){
				vm.tableValue5 = TableData5.data;
			}
		}
		
		$scope.policytab1 = function(data){
			if(data == "one"){
				vm.tableValue6 = TableData6.data2;
			}else if(data == "two"){
				vm.tableValue6 = TableData6.data1;
			}else if(data == "three"){
				vm.tableValue6 = TableData6.data;
			}
		}
		
		$scope.policytab2 = function(data){
			if(data == "one"){
				vm.tableValue7 = TableData7.data2;
			}else if(data == "two"){
				vm.tableValue7 = TableData7.data1;
			}else if(data == "three"){
				vm.tableValue7 = TableData7.data;
			}
		}
		
		$scope.policytab3 = function(data){
			if(data == "one"){
				vm.tableValue8 = TableData8.data2;
			}else if(data == "two"){
				vm.tableValue8 = TableData8.data1;
			}else if(data == "three"){
				vm.tableValue8 = TableData8.data;
			}
			else if(data == "four"){
				vm.tableValue8 = TableData8.data3;
			}
		}
		vm.tableValue5 = TableData5.data
		vm.tableValue6 = TableData6.data;
		vm.tableValue7 = TableData7.data;
		vm.tableValue8 = TableData8.data;
		vm.activities = Announcements.data;
		 $('.ms-theme-options-button').hide();
		$('.ms-theme-options-button1').hide();
		$('.ms-theme-options-button2').hide();
		
		
		$scope.sizes = [
          "Customer Information Program",
          "Standard Due Digilence-A",
          "Local Due Digilence",
          "Enhanced Due Digilence",
		  "Standard Due Digilence-B"
      ];
		
		$scope.tableDetail = function(data){
		localStorage.tableName = data;
		$location.path('/dashboard-Detail');
		}
		
		$scope.casesSubmitted = function(data){
		if(data == "1"){
		vm.barChart1 = {
            labels: ['HIGH', 'MEDIUM', 'LOW'],
            series: ['ME', 'MY TEAM'],
            data  : [
			    [2, 3, 2],
                [5, 9, 4] 
            ],
			colours: ['#c3d69b', '#fac090']
        };
        $scope.showCasesSubmitted = 1;		
		$scope.graphvalue1 = 7;
		$scope.graphvalue2 = 18;
		$scope.targetValue = 11;
		}else if(data == "2"){
		vm.barChart1 = {
            labels: ['HIGH', 'MEDIUM', 'LOW'],
            series: ['ME', 'MY TEAM'],
            data  : [
			[3, 4, 5],
                [6, 8, 9]
                
            ],
			colours: ['#c3d69b', '#fac090']
        };
        $scope.showCasesSubmitted = 2;		
		$scope.graphvalue1 = 12;
		$scope.graphvalue2 = 23;
		$scope.targetValue = 13;
		}else if(data == "3"){
		vm.barChart1 = {
            labels: ['HIGH', 'MEDIUM', 'LOW'],
            series: ['ME', 'MY TEAM'],
            data  : [
                [2, 5, 7],
                [5, 7, 9]
            ],
			colours: ['#c3d69b', '#fac090']
        };	
		$scope.showCasesSubmitted = 3;
		$scope.graphvalue1 = 14;
		$scope.graphvalue2 = 21;
		$scope.targetValue = 14;
		}
		
		else if(data == "4"){
		vm.barChart1 = {
            labels: ['HIGH', 'MEDIUM', 'LOW'],
            series: ['ME', 'MY TEAM'],
            data  : [
                [2, 5, 7],
                [6, 7, 9]
            ],
			colours: ['#c3d69b', '#fac090']
        };	
		$scope.showCasesSubmitted = 4;
		$scope.graphvalue1 = 14;
		$scope.graphvalue2 = 22;
		$scope.targetValue = 15;
		}
		
		else if(data == "5"){
		vm.barChart1 = {
            labels: ['HIGH', 'MEDIUM', 'LOW'],
            series: ['ME', 'MY TEAM'],
            data  : [
                [5, 8, 9],
                [10, 13, 16]
            ],
			colours: ['#c3d69b', '#fac090']
        };	
		$scope.showCasesSubmitted = 5;
		$scope.graphvalue1 = 22;
		$scope.graphvalue2 = 39;
		$scope.targetValue = 25;
		}
		
		}
		$scope.casesSubmitted("2");
		
		$scope.errorSubmitted = function(data){
		if(data == "1"){
		vm.barChart = {
            labels: ['MAJOR', 'MINOR'],
            series: ['ME', 'MY TEAM'],
            data  : [
                [3, 5],
                [5, 9]
            ],
			colours: ['#c3d69b', '#fac090']
		};	
		$scope.showErrorSubmitted = 1;
		$scope.graphvalue3 = 8;
		$scope.graphvalue4 = 14;
		$scope.targetValue1 = 12;
		}else if(data == "2"){
		vm.barChart = {
            labels: ['MAJOR', 'MINOR'],
            series: ['ME', 'MY TEAM'],
            data  : [
                [5, 6],
				[7, 9]
                
            ],
			colours: ['#c3d69b', '#fac090']
		};	
		$scope.showErrorSubmitted = 2;
		$scope.graphvalue3 = 7;
		$scope.graphvalue4 = 16;
		$scope.targetValue1 = 15;
		}else if(data == "3"){
		vm.barChart = {
            labels: ['MAJOR', 'MINOR'],
            series: ['ME', 'MY TEAM'],
            data  : [
                [6, 8],
               [9, 15]
            ],
			colours: ['#c3d69b', '#fac090']
		};	
		$scope.showErrorSubmitted = 3;
		$scope.graphvalue3 = 14;
		$scope.graphvalue4 = 24;
		$scope.targetValue1 = 22;
		}else if(data == "4"){
		vm.barChart = {
            labels: ['MAJOR', 'MINOR'],
            series: ['ME', 'MY TEAM'],
            data  : [
                [2, 6],
				[4, 9]
            ],
			colours: ['#c3d69b', '#fac090']
		};	
		$scope.showErrorSubmitted = 4;
		$scope.graphvalue3 = 8;
		$scope.graphvalue4 = 13;
		$scope.targetValue1 = 15;
		}else if(data == "5"){
		vm.barChart = {
            labels: ['MAJOR', 'MINOR'],
            series: ['ME', 'MY TEAM'],
            data  : [
                [6, 4],
               [7, 10]
            ],
			colours: ['#c3d69b', '#fac090']
		};	
		$scope.showErrorSubmitted = 5;
		$scope.graphvalue3 = 10;
		$scope.graphvalue4 = 17;
		$scope.targetValue1 = 17;
		}
		}
		$scope.errorSubmitted("2");
		
		$scope.graphindividual = function(data){
		if(data == "LW2"){
		vm.barChart2 = {
            labels: ['MAJOR', 'MINOR'],
            series: ['ME','ME'],
            data  : [
                [3, 9],
               
            ],
			colours: ['#c3d69b']
		};	
		
		}else if(data == "TW"){
		vm.barChart2 = {
            labels: ['MAJOR', 'MINOR'],
            series: ['ME','ME'],
            data  : [
                [5, 6],
                [2, 7]
            ],
			colours: ['#c3d69b']
		};	
		}else if(data == "LW"){
		vm.barChart2 = {
            labels: ['MAJOR', 'MINOR'],
            series: ['ME','ME'],
            data  : [
                [7, 6],
                [2, 4]
            ],
			colours: ['#c3d69b']
		};	
		}else if(data == "2W"){
		vm.barChart2 = {
            labels: ['MAJOR', 'MINOR'],
            series: ['ME','ME'],
            data  : [
                [2, 6],
                [5, 8]
            ],
			colours: ['#c3d69b']
		};	
		}else if(data == "LW1"){
		vm.barChart2 = {
            labels: ['MAJOR', 'MINOR'],
            series: ['ME','ME'],
            data  : [
                [6, 4],
                [2, 8]
            ],
			colours: ['#c3d69b']
		};	
		}
		}
		$scope.graphindividual("TW");
		
		
		$scope.graphPages = function(data){
		if(data == 1){
		vm.barChart2 = {
            labels: ['MAJOR', 'MINOR'],
            series: ['ME','ME'],
            data  : [
                [12, 7]
            ],
			colours: ['#c3d69b', '#fac090']
        };	
		}
			
		}
		$scope.graphPages(1);
		
		
		$scope.value1 = "<=15 days";	
		$scope.value2 = "16-30 days";
		$scope.value3 = ">30 days";
		$scope.value4 = "Total";
		$scope.value5 = "<=15 days";
		$scope.value6 = "16-30 days";
		$scope.value7 = ">30 days";
		$scope.value8 = "Total";
		$scope.value9 = "Policy Name";
		$scope.value10 = "Effective Date";
		$scope.value11 = "Archive Data";
		$scope.value12 = "Author/Owner";
		//alert(localStorage.permission);
		
		if(localStorage.permission == "maker" || localStorage.permission == "admin"){
		vm.tableData1 = TableData1;
		vm.tableValue1 = vm.tableData1.table1;
		vm.tableValue2 = vm.tableData1.table2;
		vm.tableValue3 = vm.tableData1.table3;
		vm.tableValue4 = vm.tableData1.table4;
		}  else if(localStorage.permission == "checker"){
		vm.tableData2 = TableData2;
		vm.tableValue1 = vm.tableData2.table1;
		vm.tableValue2 = vm.tableData2.table2;
		vm.tableValue3 = vm.tableData2.table3;
		vm.tableValue4 = vm.tableData2.table4;
		} else if(localStorage.permission == "advisor"){
		vm.tableData3 = TableData3;
		vm.tableValue1 = vm.tableData3.table1;
		vm.tableValue2 = vm.tableData3.table2;
		vm.tableValue3 = vm.tableData3.table3;
		vm.tableValue4 = vm.tableData3.table4;
		} else if(localStorage.permission == "approver"){
		vm.tableData4 = TableData4;
		vm.tableValue1 = vm.tableData4.table1;
		vm.tableValue2 = vm.tableData4.table2;
		vm.tableValue3 = vm.tableData4.table3;
		vm.tableValue4 = vm.tableData4.table4;
		} 
		
		$("md-sidenav").show();
	    $("md-toolbar").show();
		
		
		 vm.contacts = Contacts.data;
		 vm.contacts1 = Contacts1.data;
		 vm.contacts2 = Contacts2.data;
		 vm.contacts3 = Contacts3.data;

        // Data
        vm.dashboardData = DashboardData;
        vm.projects = vm.dashboardData.projects;

        // Widget 1
        vm.widget1 = vm.dashboardData.widget1;

        // Widget 2
        vm.widget2 = vm.dashboardData.widget2;

        // Widget 3
        vm.widget3 = vm.dashboardData.widget3;

        // Widget 4
        vm.widget4 = vm.dashboardData.widget4;
		//debugger;
		// Widget 12
        vm.widget12 = vm.dashboardData.widget12;
		
		// Widget 13
        vm.widget13 = vm.dashboardData.widget13;
		
		// Widget 14
        vm.widget14 = vm.dashboardData.widget14;
		
		// Widget 15
        vm.widget15 = vm.dashboardData.widget15;
		
		// Widget 16
        vm.widget16 = vm.dashboardData.widget16;
		
		// Widget 17
        vm.widget17 = vm.dashboardData.widget17;
		// Widget 19
        vm.widget19 = vm.dashboardData.widget19;
		
		// Widget 22
        vm.widget22 = vm.dashboardData.widget22;
		
		vm.dtOptions = DTOptionsBuilder.newOptions().withOption('order', [1, 'asc']).withOption('lengthMenu', [5, 10, 25, 50, 100])
		
		 vm.dtOptions = {
            dom       : '<"top"f>rt<"bottom"<"left"<"length"l>><"right"<"info"i><"pagination"p>>>',
            pagingType: 'simple',
            autoWidth : true,
            responsive: true,
			lengthMenu: [5, 10, 25, 50, 100]
        };
		
		
		
		
		$scope.chartFn = function(){
		$scope.chartHideFlag = true;
		$scope.chartHideFlag1 = false;
		}
		
		$scope.chartFn1 = function(){
		$scope.chartHideFlag = false;
		$scope.chartHideFlag1 = true;
		}
		
		$scope.chartFn2 = function(){
		$scope.chartHideFlag2 = true;
		$scope.chartHideFlag3 = false;
		}
		
		$scope.chartFn3 = function(){
		$scope.chartHideFlag2 = false;
		$scope.chartHideFlag3 = true;
		}
		/* BARCHART SEC BY DINESH */
		
		
		

        // Widget 5
        vm.widget5 = {
            title       : vm.dashboardData.widget5.title,
            mainChart   : {
                config : {
                    refreshDataOnly: true,
                    deepWatchData  : true
                },
                options: {
                    chart: {
                        type        : 'multiBarChart',
                        color       : ['#03a9f4', '#b3e5fc'],
                        height      : 300,
                        margin      : {
                            top   : 8,
                            right : 16,
                            bottom: 32,
                            left  : 32
                        },
                        clipEdge    : true,
                        groupSpacing: 0.3,
                        reduceXTicks: false,
                        stacked     : false,
                        duration    : 250,
                        x           : function (d)
                        {
                            return d.x;
                        },
                        y           : function (d)
                        {
                            return d.y;
                        },
                        yAxis       : {
                            tickFormat: function (d)
                            {
                                return d;
                            }
                        },
                        legend      : {
                            margin: {
                                top   : 8,
                                bottom: 32
                            }
                        },
                        controls    : {
                            margin: {
                                top   : 8,
                                bottom: 32
                            }
                        },
                        tooltip     : {
                            gravity: 's',
                            classes: 'gravity-s'
                        }
                    }
                },
                data   : []
            },
            supporting  : {
                widgets: {
                    created  : {
                        data : vm.dashboardData.widget5.supporting.created,
                        chart: {
                            data: []
                        }
                    },
                    closed   : {
                        data : vm.dashboardData.widget5.supporting.closed,
                        chart: {
                            data: []
                        }
                    },
                    reOpened : {
                        data : vm.dashboardData.widget5.supporting.reOpened,
                        chart: {
                            data: []
                        }
                    },
                    wontFix  : {
                        data : vm.dashboardData.widget5.supporting.wontFix,
                        chart: {
                            data: []
                        }
                    },
                    needsTest: {
                        data : vm.dashboardData.widget5.supporting.needsTest,
                        chart: {
                            data: []
                        }
                    },
                    fixed    : {
                        data : vm.dashboardData.widget5.supporting.fixed,
                        chart: {
                            data: []
                        }
                    }
                },
                chart  : {
                    config : {
                        refreshDataOnly: true,
                        deepWatchData  : true
                    },
                    options: {
                        chart: {
                            type                   : 'lineChart',
                            color                  : ['#03A9F4'],
                            height                 : 50,
                            margin                 : {
                                top   : 8,
                                right : 0,
                                bottom: 0,
                                left  : 0
                            },
                            isArea                 : true,
                            interpolate            : 'cardinal',
                            clipEdge               : true,
                            duration               : 500,
                            showXAxis              : false,
                            showYAxis              : false,
                            showLegend             : false,
                            useInteractiveGuideline: true,
                            x                      : function (d)
                            {
                                return d.x;
                            },
                            y                      : function (d)
                            {
                                return d.y;
                            },
                            yDomain                : [0, 9],
                            xAxis                  : {
                                tickFormat: function (d)
                                {
                                    return vm.widget5.days[d];
                                }
                            },
                            interactiveLayer       : {
                                tooltip: {
                                    gravity: 'e',
                                    classes: 'gravity-e'
                                }
                            }
                        }
                    },
                    data   : []
                }
            },
            days        : ['HIGH', 'MEDIUM', 'LOW'],
            ranges      : vm.dashboardData.widget5.ranges,
            currentRange: '',
            changeRange : function (range)
            {
                vm.widget5.currentRange = range;

                /**
                 * Update main chart data by iterating through the
                 * chart dataset and separately adding every single
                 * dataset by hand.
                 *
                 * You MUST NOT swap the entire data object by doing
                 * something similar to this:
                 * vm.widget.mainChart.data = chartData
                 *
                 * It would be easier but it won't work with the
                 * live updating / animated charts due to how d3
                 * works.
                 *
                 * If you don't need animated / live updating charts,
                 * you can simplify these greatly.
                 */
                angular.forEach(vm.dashboardData.widget5.mainChart, function (chartData, index)
                {
                    vm.widget5.mainChart.data[index] = {
                        key   : chartData.key,
                        values: chartData.values[range]
                    };
                });

                /**
                 * Do the same thing for the supporting widgets but they
                 * only have 1 dataset so we can do [0] without needing to
                 * iterate through in their data arrays
                 */
                angular.forEach(vm.dashboardData.widget5.supporting, function (widget, name)
                {
                    vm.widget5.supporting.widgets[name].chart.data[0] = {
                        key   : widget.chart.key,
                        values: widget.chart.values[range]
                    };
                });
            },
            init        : function ()
            {
                // Run this function once to initialize widget

                /**
                 * Update the range for the first time
                 */
                vm.widget5.changeRange(2);
            }
        };
		
		 // Widget 5
        vm.widget29 = {
            title       : vm.dashboardData.widget29.title,
            mainChart   : {
                config : {
                    refreshDataOnly: true,
                    deepWatchData  : true
                },
                options: {
                    chart: {
                        type        : 'multiBarChart',
                        color       : ['#03a9f4', '#b3e5fc'],
                        height      : 300,
                        margin      : {
                            top   : 8,
                            right : 16,
                            bottom: 32,
                            left  : 32
                        },
                        clipEdge    : true,
                        groupSpacing: 0.3,
                        reduceXTicks: false,
                        stacked     : true,
                        duration    : 250,
                        x           : function (d)
                        {
                            return d.x;
                        },
                        y           : function (d)
                        {
                            return d.y;
                        },
                        yAxis       : {
                            tickFormat: function (d)
                            {
                                return d;
                            }
                        },
                        legend      : {
                            margin: {
                                top   : 8,
                                bottom: 32
                            }
                        },
                        controls    : {
                            margin: {
                                top   : 8,
                                bottom: 32
                            }
                        },
                        tooltip     : {
                            gravity: 's',
                            classes: 'gravity-s'
                        }
                    }
                },
                data   : []
            },
            supporting  : {
                widgets: {
                    created  : {
                        data : vm.dashboardData.widget29.supporting.created,
                        chart: {
                            data: []
                        }
                    },
                    closed   : {
                        data : vm.dashboardData.widget29.supporting.closed,
                        chart: {
                            data: []
                        }
                    },
                    reOpened : {
                        data : vm.dashboardData.widget29.supporting.reOpened,
                        chart: {
                            data: []
                        }
                    },
                    wontFix  : {
                        data : vm.dashboardData.widget29.supporting.wontFix,
                        chart: {
                            data: []
                        }
                    },
                    needsTest: {
                        data : vm.dashboardData.widget29.supporting.needsTest,
                        chart: {
                            data: []
                        }
                    },
                    fixed    : {
                        data : vm.dashboardData.widget29.supporting.fixed,
                        chart: {
                            data: []
                        }
                    }
                },
                chart  : {
                    config : {
                        refreshDataOnly: true,
                        deepWatchData  : true
                    },
                    options: {
                        chart: {
                            type                   : 'lineChart',
                            color                  : ['#03A9F4'],
                            height                 : 50,
                            margin                 : {
                                top   : 8,
                                right : 0,
                                bottom: 0,
                                left  : 0
                            },
                            isArea                 : true,
                            interpolate            : 'cardinal',
                            clipEdge               : true,
                            duration               : 500,
                            showXAxis              : false,
                            showYAxis              : false,
                            showLegend             : false,
                            useInteractiveGuideline: true,
                            x                      : function (d)
                            {
                                return d.x;
                            },
                            y                      : function (d)
                            {
                                return d.y;
                            },
                            yDomain                : [0, 9],
                            xAxis                  : {
                                tickFormat: function (d)
                                {
                                    return vm.widget29.days[d];
                                }
                            },
                            interactiveLayer       : {
                                tooltip: {
                                    gravity: 'e',
                                    classes: 'gravity-e'
                                }
                            }
                        }
                    },
                    data   : []
                }
            },
            days        : ['HIGH', 'MEDIUM', 'LOW'],
            ranges      : vm.dashboardData.widget29.ranges,
            currentRange: '',
            changeRange : function (range)
            {
                vm.widget29.currentRange = range;

                /**
                 * Update main chart data by iterating through the
                 * chart dataset and separately adding every single
                 * dataset by hand.
                 *
                 * You MUST NOT swap the entire data object by doing
                 * something similar to this:
                 * vm.widget.mainChart.data = chartData
                 *
                 * It would be easier but it won't work with the
                 * live updating / animated charts due to how d3
                 * works.
                 *
                 * If you don't need animated / live updating charts,
                 * you can simplify these greatly.
                 */
                angular.forEach(vm.dashboardData.widget29.mainChart, function (chartData, index)
                {
                    vm.widget29.mainChart.data[index] = {
                        key   : chartData.key,
                        values: chartData.values[range]
                    };
                });

                /**
                 * Do the same thing for the supporting widgets but they
                 * only have 1 dataset so we can do [0] without needing to
                 * iterate through in their data arrays
                 */
                angular.forEach(vm.dashboardData.widget29.supporting, function (widget, name)
                {
                    vm.widget29.supporting.widgets[name].chart.data[0] = {
                        key   : widget.chart.key,
                        values: widget.chart.values[range]
                    };
                });
            },
            init        : function ()
            {
                // Run this function once to initialize widget

                /**
                 * Update the range for the first time
                 */
                vm.widget29.changeRange(2);
            }
        };
		
		vm.widget30 = {
            title       : vm.dashboardData.widget30.title,
            mainChart   : {
                config : {
                    refreshDataOnly: true,
                    deepWatchData  : true
                },
                options: {
                    chart: {
                        type        : 'multiBarChart',
                        color       : ['#03a9f4', '#b3e5fc'],
                        height      : 300,
                        margin      : {
                            top   : 8,
                            right : 16,
                            bottom: 32,
                            left  : 32
                        },
                        clipEdge    : true,
                        groupSpacing: 0.3,
                        reduceXTicks: false,
                        stacked     : true,
                        duration    : 250,
                        x           : function (d)
                        {
                            return d.x;
                        },
                        y           : function (d)
                        {
                            return d.y;
                        },
                        yAxis       : {
                            tickFormat: function (d)
                            {
                                return d;
                            }
                        },
                        legend      : {
                            margin: {
                                top   : 8,
                                bottom: 32
                            }
                        },
                        controls    : {
                            margin: {
                                top   : 8,
                                bottom: 32
                            }
                        },
                        tooltip     : {
                            gravity: 's',
                            classes: 'gravity-s'
                        }
                    }
                },
                data   : []
            },
            supporting  : {
                widgets: {
                    created  : {
                        data : vm.dashboardData.widget30.supporting.created,
                        chart: {
                            data: []
                        }
                    },
                    closed   : {
                        data : vm.dashboardData.widget30.supporting.closed,
                        chart: {
                            data: []
                        }
                    },
                    reOpened : {
                        data : vm.dashboardData.widget30.supporting.reOpened,
                        chart: {
                            data: []
                        }
                    },
                    wontFix  : {
                        data : vm.dashboardData.widget30.supporting.wontFix,
                        chart: {
                            data: []
                        }
                    },
                    needsTest: {
                        data : vm.dashboardData.widget30.supporting.needsTest,
                        chart: {
                            data: []
                        }
                    },
                    fixed    : {
                        data : vm.dashboardData.widget30.supporting.fixed,
                        chart: {
                            data: []
                        }
                    }
                },
                chart  : {
                    config : {
                        refreshDataOnly: true,
                        deepWatchData  : true
                    },
                    options: {
                        chart: {
                            type                   : 'lineChart',
                            color                  : ['#03A9F4'],
                            height                 : 50,
                            margin                 : {
                                top   : 8,
                                right : 0,
                                bottom: 0,
                                left  : 0
                            },
                            isArea                 : true,
                            interpolate            : 'cardinal',
                            clipEdge               : true,
                            duration               : 500,
                            showXAxis              : false,
                            showYAxis              : false,
                            showLegend             : false,
                            useInteractiveGuideline: true,
                            x                      : function (d)
                            {
                                return d.x;
                            },
                            y                      : function (d)
                            {
                                return d.y;
                            },
                            yDomain                : [0, 9],
                            xAxis                  : {
                                tickFormat: function (d)
                                {
                                    return vm.widget30.days[d];
                                }
                            },
                            interactiveLayer       : {
                                tooltip: {
                                    gravity: 'e',
                                    classes: 'gravity-e'
                                }
                            }
                        }
                    },
                    data   : []
                }
            },
            days        : ['HIGH', 'MEDIUM', 'LOW'],
            ranges      : vm.dashboardData.widget30.ranges,
            currentRange: '',
            changeRange : function (range)
            {
                vm.widget30.currentRange = range;

                /**
                 * Update main chart data by iterating through the
                 * chart dataset and separately adding every single
                 * dataset by hand.
                 *
                 * You MUST NOT swap the entire data object by doing
                 * something similar to this:
                 * vm.widget.mainChart.data = chartData
                 *
                 * It would be easier but it won't work with the
                 * live updating / animated charts due to how d3
                 * works.
                 *
                 * If you don't need animated / live updating charts,
                 * you can simplify these greatly.
                 */
                angular.forEach(vm.dashboardData.widget30.mainChart, function (chartData, index)
                {
                    vm.widget30.mainChart.data[index] = {
                        key   : chartData.key,
                        values: chartData.values[range]
                    };
                });

                /**
                 * Do the same thing for the supporting widgets but they
                 * only have 1 dataset so we can do [0] without needing to
                 * iterate through in their data arrays
                 */
                angular.forEach(vm.dashboardData.widget30.supporting, function (widget, name)
                {
                    vm.widget30.supporting.widgets[name].chart.data[0] = {
                        key   : widget.chart.key,
                        values: widget.chart.values[range]
                    };
                });
            },
            init        : function ()
            {
                // Run this function once to initialize widget

                /**
                 * Update the range for the first time
                 */
                vm.widget30.changeRange('TW');
            }
        };
		
		
		  vm.widget24 = {
            title       : vm.dashboardData.widget24.title,
            mainChart   : {
                config : {
                    refreshDataOnly: true,
                    deepWatchData  : true
                },
                options: {
                    chart: {
                        type        : 'multiBarChart',
                        color       : ['#03a9f4', '#b3e5fc'],
                        height      : 300,
                        margin      : {
                            top   : 8,
                            right : 16,
                            bottom: 32,
                            left  : 32
                        },
                        clipEdge    : true,
                        groupSpacing: 0.3,
                        reduceXTicks: false,
                        stacked     : false,
                        duration    : 250,
                        x           : function (d)
                        {
                            return d.x;
                        },
                        y           : function (d)
                        {
                            return d.y;
                        },
                        yAxis       : {
                            tickFormat: function (d)
                            {
                                return d;
                            }
                        },
                        legend      : {
                            margin: {
                                top   : 8,
                                bottom: 32
                            }
                        },
                        controls    : {
                            margin: {
                                top   : 8,
                                bottom: 32
                            }
                        },
                        tooltip     : {
                            gravity: 's',
                            classes: 'gravity-s'
                        }
                    }
                },
                data   : []
            },
            supporting  : {
                widgets: {
                    created  : {
                        data : vm.dashboardData.widget24.supporting.created,
                        chart: {
                            data: []
                        }
                    },
                    closed   : {
                        data : vm.dashboardData.widget24.supporting.closed,
                        chart: {
                            data: []
                        }
                    },
                    reOpened : {
                        data : vm.dashboardData.widget24.supporting.reOpened,
                        chart: {
                            data: []
                        }
                    },
                    wontFix  : {
                        data : vm.dashboardData.widget24.supporting.wontFix,
                        chart: {
                            data: []
                        }
                    },
                    needsTest: {
                        data : vm.dashboardData.widget24.supporting.needsTest,
                        chart: {
                            data: []
                        }
                    },
                    fixed    : {
                        data : vm.dashboardData.widget24.supporting.fixed,
                        chart: {
                            data: []
                        }
                    }
                },
                chart  : {
                    config : {
                        refreshDataOnly: true,
                        deepWatchData  : true
                    },
                    options: {
                        chart: {
                            type                   : 'lineChart',
                            color                  : ['#03A9F4'],
                            height                 : 50,
                            margin                 : {
                                top   : 8,
                                right : 0,
                                bottom: 0,
                                left  : 0
                            },
                            isArea                 : true,
                            interpolate            : 'cardinal',
                            clipEdge               : true,
                            duration               : 500,
                            showXAxis              : false,
                            showYAxis              : false,
                            showLegend             : false,
                            useInteractiveGuideline: true,
                            x                      : function (d)
                            {
                                return d.x;
                            },
                            y                      : function (d)
                            {
                                return d.y;
                            },
                            yDomain                : [0, 9],
                            xAxis                  : {
                                tickFormat: function (d)
                                {
                                    return vm.widget24.days[d];
                                }
                            },
                            interactiveLayer       : {
                                tooltip: {
                                    gravity: 'e',
                                    classes: 'gravity-e'
                                }
                            }
                        }
                    },
                    data   : []
                }
            },
            days        : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            ranges      : vm.dashboardData.widget24.ranges,
            currentRange: '',
            changeRange : function (range)
            {
                vm.widget24.currentRange = range;

                /**
                 * Update main chart data by iterating through the
                 * chart dataset and separately adding every single
                 * dataset by hand.
                 *
                 * You MUST NOT swap the entire data object by doing
                 * something similar to this:
                 * vm.widget.mainChart.data = chartData
                 *
                 * It would be easier but it won't work with the
                 * live updating / animated charts due to how d3
                 * works.
                 *
                 * If you don't need animated / live updating charts,
                 * you can simplify these greatly.
                 */
                angular.forEach(vm.dashboardData.widget24.mainChart, function (chartData, index)
                {
                    vm.widget24.mainChart.data[index] = {
                        key   : chartData.key,
                        values: chartData.values[range]
                    };
                });

                /**
                 * Do the same thing for the supporting widgets but they
                 * only have 1 dataset so we can do [0] without needing to
                 * iterate through in their data arrays
                 */
                angular.forEach(vm.dashboardData.widget24.supporting, function (widget, name)
                {
                    vm.widget24.supporting.widgets[name].chart.data[0] = {
                        key   : widget.chart.key,
                        values: widget.chart.values[range]
                    };
                });
            },
            init        : function ()
            {
                // Run this function once to initialize widget

                /**
                 * Update the range for the first time
                 */
                vm.widget24.changeRange(2);
            }
        };
		
		// Widget 5
        vm.widget25 = {
            title       : vm.dashboardData.widget25.title,
            mainChart   : {
                config : {
                    refreshDataOnly: true,
                    deepWatchData  : true
                },
                options: {
                    chart: {
                        type        : 'multiBarChart',
                        color       : ['#03a9f4', '#b3e5fc'],
                        height      : 300,
                        margin      : {
                            top   : 8,
                            right : 16,
                            bottom: 32,
                            left  : 32
                        },
                        clipEdge    : true,
                        groupSpacing: 0.3,
                        reduceXTicks: false,
                        stacked     : true,
                        duration    : 250,
                        x           : function (d)
                        {
                            return d.x;
                        },
                        y           : function (d)
                        {
                            return d.y;
                        },
                        yAxis       : {
                            tickFormat: function (d)
                            {
                                return d;
                            }
                        },
                        legend      : {
                            margin: {
                                top   : 8,
                                bottom: 32
                            }
                        },
                        controls    : {
                            margin: {
                                top   : 8,
                                bottom: 32
                            }
                        },
                        tooltip     : {
                            gravity: 's',
                            classes: 'gravity-s'
                        }
                    }
                },
                data   : []
            },
            supporting  : {
                widgets: {
                    created  : {
                        data : vm.dashboardData.widget25.supporting.created,
                        chart: {
                            data: []
                        }
                    },
                    closed   : {
                        data : vm.dashboardData.widget25.supporting.closed,
                        chart: {
                            data: []
                        }
                    },
                    reOpened : {
                        data : vm.dashboardData.widget25.supporting.reOpened,
                        chart: {
                            data: []
                        }
                    },
                    wontFix  : {
                        data : vm.dashboardData.widget25.supporting.wontFix,
                        chart: {
                            data: []
                        }
                    },
                    needsTest: {
                        data : vm.dashboardData.widget25.supporting.needsTest,
                        chart: {
                            data: []
                        }
                    },
                    fixed    : {
                        data : vm.dashboardData.widget25.supporting.fixed,
                        chart: {
                            data: []
                        }
                    }
                },
                chart  : {
                    config : {
                        refreshDataOnly: true,
                        deepWatchData  : true
                    },
                    options: {
                        chart: {
                            type                   : 'lineChart',
                            color                  : ['#03A9F4'],
                            height                 : 50,
                            margin                 : {
                                top   : 8,
                                right : 0,
                                bottom: 0,
                                left  : 0
                            },
                            isArea                 : true,
                            interpolate            : 'cardinal',
                            clipEdge               : true,
                            duration               : 500,
                            showXAxis              : false,
                            showYAxis              : false,
                            showLegend             : false,
                            useInteractiveGuideline: true,
                            x                      : function (d)
                            {
                                return d.x;
                            },
                            y                      : function (d)
                            {
                                return d.y;
                            },
                            yDomain                : [0, 9],
                            xAxis                  : {
                                tickFormat: function (d)
                                {
                                    return vm.widget25.days[d];
                                }
                            },
                            interactiveLayer       : {
                                tooltip: {
                                    gravity: 'e',
                                    classes: 'gravity-e'
                                }
                            }
                        }
                    },
                    data   : []
                }
            },
            days        : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            ranges      : vm.dashboardData.widget25.ranges,
            currentRange: '',
            changeRange : function (range)
            {
                vm.widget25.currentRange = range;

                /**
                 * Update main chart data by iterating through the
                 * chart dataset and separately adding every single
                 * dataset by hand.
                 *
                 * You MUST NOT swap the entire data object by doing
                 * something similar to this:
                 * vm.widget.mainChart.data = chartData
                 *
                 * It would be easier but it won't work with the
                 * live updating / animated charts due to how d3
                 * works.
                 *
                 * If you don't need animated / live updating charts,
                 * you can simplify these greatly.
                 */
                angular.forEach(vm.dashboardData.widget25.mainChart, function (chartData, index)
                {
                    vm.widget25.mainChart.data[index] = {
                        key   : chartData.key,
                        values: chartData.values[range]
                    };
                });

                /**
                 * Do the same thing for the supporting widgets but they
                 * only have 1 dataset so we can do [0] without needing to
                 * iterate through in their data arrays
                 */
                angular.forEach(vm.dashboardData.widget25.supporting, function (widget, name)
                {
                    vm.widget25.supporting.widgets[name].chart.data[0] = {
                        key   : widget.chart.key,
                        values: widget.chart.values[range]
                    };
                });
            },
            init        : function ()
            {
                // Run this function once to initialize widget

                /**
                 * Update the range for the first time
                 */
                vm.widget25.changeRange('TW');
            }
        };
		
		
		
		

        // Widget 6
        vm.widget6 = {
            title       : vm.dashboardData.widget6.title,
            mainChart   : {
                config : {
                    refreshDataOnly: true,
                    deepWatchData  : true
                },
                options: {
                    chart: {
                        type        : 'pieChart',
                        color       : ['#f44336', '#9c27b0', '#03a9f4', '#e91e63'],
                        height      : 400,
                        margin      : {
                            top   : 0,
                            right : 0,
                            bottom: 0,
                            left  : 0
                        },
                        donut       : true,
                        clipEdge    : true,
                        cornerRadius: 0,
                        labelType   : 'percent',
                        padAngle    : 0.02,
                        x           : function (d)
                        {
                            return d.label;
                        },
                        y           : function (d)
                        {
                            return d.value;
                        },
                        tooltip     : {
                            gravity: 's',
                            classes: 'gravity-s'
                        }
                    }
                },
                data   : []
            },
			mainChart1   : {
                config : {
                    refreshDataOnly: true,
                    deepWatchData  : true
                },
                options: {
                    chart: {
                        type        : 'pieChart',
                        color       : ['#f44336', '#9c27b0', '#03a9f4', '#e91e63'],
                        height      : 400,
                        margin      : {
                            top   : 0,
                            right : 0,
                            bottom: 0,
                            left  : 0
                        },
                        donut       : true,
                        clipEdge    : true,
                        cornerRadius: 0,
                        labelType   : 'percent',
                        padAngle    : 0.02,
                        x           : function (d)
                        {
                            return d.label;
                        },
                        y           : function (d)
                        {
                            return d.value;
                        },
                        tooltip     : {
                            gravity: 's',
                            classes: 'gravity-s'
                        }
                    }
                },
                data   : []
            },
            footerLeft  : vm.dashboardData.widget6.footerLeft,
            footerRight : vm.dashboardData.widget6.footerRight,
            ranges      : vm.dashboardData.widget6.ranges,
            currentRange: '',
            changeRange : function (range)
            {
                vm.widget6.currentRange = range;

                /**
                 * Update main chart data by iterating through the
                 * chart dataset and separately adding every single
                 * dataset by hand.
                 *
                 * You MUST NOT swap the entire data object by doing
                 * something similar to this:
                 * vm.widget.mainChart.data = chartData
                 *
                 * It would be easier but it won't work with the
                 * live updating / animated charts due to how d3
                 * works.
                 *
                 * If you don't need animated / live updating charts,
                 * you can simplify these greatly.
                 */
                angular.forEach(vm.dashboardData.widget6.mainChart, function (data, index)
                {
                    vm.widget6.mainChart.data[index] = {
                        label: data.label,
                        value: data.values[range]
                    };
                });
				 angular.forEach(vm.dashboardData.widget6.mainChart1, function (data, index)
                {
                    vm.widget6.mainChart1.data[index] = {
                        label: data.label,
                        value: data.values[range]
                    };
                });
            },
            init        : function ()
            {
                // Run this function once to initialize widget

                /**
                 * Update the range for the first time
                 */
                vm.widget6.changeRange('TW');
            }
        };
		
		
		// Widget 18
        vm.widget18 = {
            title       : vm.dashboardData.widget18.title,
            mainChart   : {
                config : {
                    refreshDataOnly: true,
                    deepWatchData  : true
                },
                options: {
                    chart: {
                        type        : 'pieChart',
                        color       : ['#f44336', '#9c27b0', '#03a9f4', '#e91e63'],
                        height      : 400,
                        margin      : {
                            top   : 0,
                            right : 0,
                            bottom: 0,
                            left  : 0
                        },
                        donut       : true,
                        clipEdge    : true,
                        cornerRadius: 0,
                        labelType   : 'percent',
                        padAngle    : 0.02,
                        x           : function (d)
                        {
                            return d.label;
                        },
                        y           : function (d)
                        {
                            return d.value;
                        },
                        tooltip     : {
                            gravity: 's',
                            classes: 'gravity-s'
                        }
                    }
                },
                data   : []
            },
			mainChart1   : {
                config : {
                    refreshDataOnly: true,
                    deepWatchData  : true
                },
                options: {
                    chart: {
                        type        : 'pieChart',
                        color       : ['#f44336', '#9c27b0', '#03a9f4', '#e91e63'],
                        height      : 400,
                        margin      : {
                            top   : 0,
                            right : 0,
                            bottom: 0,
                            left  : 0
                        },
                        donut       : true,
                        clipEdge    : true,
                        cornerRadius: 0,
                        labelType   : 'percent',
                        padAngle    : 0.02,
                        x           : function (d)
                        {
                            return d.label;
                        },
                        y           : function (d)
                        {
                            return d.value;
                        },
                        tooltip     : {
                            gravity: 's',
                            classes: 'gravity-s'
                        }
                    }
                },
                data   : []
            },
            footerLeft  : vm.dashboardData.widget18.footerLeft,
            footerRight : vm.dashboardData.widget18.footerRight,
            ranges      : vm.dashboardData.widget18.ranges,
            currentRange: '',
            changeRange : function (range)
            {
                vm.widget18.currentRange = range;

                /**
                 * Update main chart data by iterating through the
                 * chart dataset and separately adding every single
                 * dataset by hand.
                 *
                 * You MUST NOT swap the entire data object by doing
                 * something similar to this:
                 * vm.widget.mainChart.data = chartData
                 *
                 * It would be easier but it won't work with the
                 * live updating / animated charts due to how d3
                 * works.
                 *
                 * If you don't need animated / live updating charts,
                 * you can simplify these greatly.
                 */
                angular.forEach(vm.dashboardData.widget18.mainChart, function (data, index)
                {
                    vm.widget18.mainChart.data[index] = {
                        label: data.label,
                        value: data.values[range]
                    };
                });
				
				angular.forEach(vm.dashboardData.widget18.mainChart1, function (data, index)
                {
                    vm.widget18.mainChart1.data[index] = {
                        label: data.label,
                        value: data.values[range]
                    };
                });
            },
            init        : function ()
            {
                // Run this function once to initialize widget

                /**
                 * Update the range for the first time
                 */
                vm.widget18.changeRange('TW');
            }
        };
		
		// Widget 20
        vm.widget20 = {
            title       : vm.dashboardData.widget20.title,
            mainChart   : {
                config : {
                    refreshDataOnly: true,
                    deepWatchData  : true
                },
                options: {
                    chart: {
                        type        : 'pieChart',
                        color       : ['#f44336', '#9c27b0', '#03a9f4', '#e91e63','#ff0000'],
                        height      : 400,
                        margin      : {
                            top   : 0,
                            right : 0,
                            bottom: 0,
                            left  : 0
                        },
                        donut       : true,
                        clipEdge    : true,
                        cornerRadius: 0,
                        labelType   : 'percent',
                        padAngle    : 0.02,
                        x           : function (d)
                        {
                            return d.label;
                        },
                        y           : function (d)
                        {
                            return d.value;
                        },
                        tooltip     : {
                            gravity: 's',
                            classes: 'gravity-s'
                        }
                    }
                },
                data   : []
            },
			mainChart1   : {
                config : {
                    refreshDataOnly: true,
                    deepWatchData  : true
                },
                options: {
                    chart: {
                        type        : 'pieChart',
                        color       : ['#f44336', '#9c27b0', '#03a9f4', '#e91e63','#ff0000'],
                        height      : 400,
                        margin      : {
                            top   : 0,
                            right : 0,
                            bottom: 0,
                            left  : 0
                        },
                        donut       : true,
                        clipEdge    : true,
                        cornerRadius: 0,
                        labelType   : 'percent',
                        padAngle    : 0.02,
                        x           : function (d)
                        {
                            return d.label;
                        },
                        y           : function (d)
                        {
                            return d.value;
                        },
                        tooltip     : {
                            gravity: 's',
                            classes: 'gravity-s'
                        }
                    }
                },
                data   : []
            },
            footerLeft  : vm.dashboardData.widget20.footerLeft,
            footerRight : vm.dashboardData.widget20.footerRight,
            ranges      : vm.dashboardData.widget20.ranges,
            currentRange: '',
            changeRange : function (range)
            {
                vm.widget20.currentRange = range;

                /**
                 * Update main chart data by iterating through the
                 * chart dataset and separately adding every single
                 * dataset by hand.
                 *
                 * You MUST NOT swap the entire data object by doing
                 * something similar to this:
                 * vm.widget.mainChart.data = chartData
                 *
                 * It would be easier but it won't work with the
                 * live updating / animated charts due to how d3
                 * works.
                 *
                 * If you don't need animated / live updating charts,
                 * you can simplify these greatly.
                 */
                angular.forEach(vm.dashboardData.widget20.mainChart, function (data, index)
                {
                    vm.widget20.mainChart.data[index] = {
                        label: data.label,
                        value: data.values[range]
                    };
                });
				
				angular.forEach(vm.dashboardData.widget20.mainChart1, function (data, index)
                {
                    vm.widget20.mainChart1.data[index] = {
                        label: data.label,
                        value: data.values[range]
                    };
                });
            },
            init        : function ()
            {
                // Run this function once to initialize widget

                /**
                 * Update the range for the first time
                 */
                vm.widget20.changeRange('TW');
            }
        };


        // Widget 7
        vm.widget7 = {
            title       : vm.dashboardData.widget7.title,
            ranges      : vm.dashboardData.widget7.ranges,
            schedule    : vm.dashboardData.widget7.schedule,
            currentRange: 'T'
        };

        // Widget 8
        vm.widget8 = {
            title    : vm.dashboardData.widget8.title,
            mainChart: {
                options: {
                    chart: {
                        type     : 'pieChart',
                        color    : ['#f44336', '#9c27b0', '#03a9f4', '#e91e63', '#ffc107'],
                        height   : 400,
                        margin   : {
                            top   : 0,
                            right : 0,
                            bottom: 0,
                            left  : 0
                        },
                        labelType: 'percent',
                        x        : function (d)
                        {
                            return d.label;
                        },
                        y        : function (d)
                        {
                            return d.value;
                        },
                        tooltip  : {
                            gravity: 's',
                            classes: 'gravity-s'
                        }
                    }
                },
                data   : vm.dashboardData.widget8.mainChart
            }
        };

        // Widget 9
        vm.widget9 = {
            title       : vm.dashboardData.widget9.title,
            weeklySpent : {
                title    : vm.dashboardData.widget9.weeklySpent.title,
                count    : vm.dashboardData.widget9.weeklySpent.count,
                chartData: []
            },
            totalSpent  : {
                title    : vm.dashboardData.widget9.totalSpent.title,
                count    : vm.dashboardData.widget9.totalSpent.count,
                chartData: []
            },
            remaining   : {
                title    : vm.dashboardData.widget9.remaining.title,
                count    : vm.dashboardData.widget9.remaining.count,
                chartData: []
            },
            totalBudget : vm.dashboardData.widget9.totalBudget,
            chart       : {
                config : {
                    refreshDataOnly: true,
                    deepWatchData  : true
                },
                options: {
                    chart: {
                        type                   : 'lineChart',
                        color                  : ['#00BCD4'],
                        height                 : 50,
                        margin                 : {
                            top   : 8,
                            right : 0,
                            bottom: 0,
                            left  : 0
                        },
                        isArea                 : true,
                        interpolate            : 'cardinal',
                        clipEdge               : true,
                        duration               : 500,
                        showXAxis              : false,
                        showYAxis              : false,
                        showLegend             : false,
                        useInteractiveGuideline: true,
                        x                      : function (d)
                        {
                            return d.x;
                        },
                        y                      : function (d)
                        {
                            return d.y;
                        },
                        yDomain                : [0, 9],
                        xAxis                  : {
                            tickFormat: function (d)
                            {
                                return vm.widget9.days[d];
                            }
                        },
                        interactiveLayer       : {
                            tooltip: {
                                gravity: 'e',
                                classes: 'gravity-e'
                            }
                        }
                    }
                }
            },
            days        : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            ranges      : vm.dashboardData.widget9.ranges,
            currentRange: '',
            changeRange : function (range)
            {
                vm.widget9.currentRange = range;

                /**
                 * Update mini charts. They only have 1 dataset
                 * so we can do [0] without needing to iterate
                 * through in their data arrays
                 */
                vm.widget9.weeklySpent.chartData[0] = {
                    key   : vm.dashboardData.widget9.weeklySpent.chart.label,
                    values: vm.dashboardData.widget9.weeklySpent.chart.values[range]
                };

                vm.widget9.totalSpent.chartData[0] = {
                    key   : vm.dashboardData.widget9.totalSpent.chart.label,
                    values: vm.dashboardData.widget9.totalSpent.chart.values[range]
                };

                vm.widget9.remaining.chartData[0] = {
                    key   : vm.dashboardData.widget9.remaining.chart.label,
                    values: vm.dashboardData.widget9.remaining.chart.values[range]
                };
            },
            init        : function ()
            {
                // Run this function once to initialize widget

                /**
                 * Update the range for the first time
                 */
                vm.widget9.changeRange('TW');
            }
        };

        // Widget 10
        vm.widget10 = vm.dashboardData.widget10;

        // Widget 11
        vm.widget11 = {
            title    : vm.dashboardData.widget11.title,
            table    : vm.dashboardData.widget11.table,
            dtOptions: {
                dom       : '<"top"f>rt<"bottom"<"left"<"length"l>><"right"<"info"i><"pagination"p>>>',
                pagingType: 'simple',
                autoWidth : false,
                responsive: true,
                order     : [1, 'asc'],
                columnDefs: [
                    {
                        width    : '40',
                        orderable: false,
                        targets  : [0]
                    },
                    {
                        width  : '20%',
                        targets: [1, 2, 3, 4, 5]
                    }
                ]
            }
        };

        // Now widget
        vm.nowWidget = {
            now   : {
                second: '',
                minute: '',
                hour  : '',
                day   : '',
                month : '',
                year  : ''
            },
            ticker: function ()
            {
                var now = moment();
                vm.nowWidget.now = {
                    second : now.format('ss'),
                    minute : now.format('mm'),
                    hour   : now.format('HH'),
                    day    : now.format('D'),
                    weekDay: now.format('dddd'),
                    month  : now.format('MMMM'),
                    year   : now.format('YYYY')
                };
            }
        };

        // Weather widget
        vm.weatherWidget = vm.dashboardData.weatherWidget;

        // Methods
        vm.toggleSidenav = toggleSidenav;
        vm.selectProject = selectProject;

        //////////
        vm.selectedProject = vm.projects[0];

        // Initialize Widget 5
        vm.widget5.init();
		vm.widget25.init();
		vm.widget29.init();
		vm.widget30.init();
			vm.widget24.init();
        // Initialize Widget 6
        vm.widget6.init();
		
		// Initialize Widget 18
        vm.widget18.init();
		
		// Initialize Widget 18
        vm.widget20.init();

        // Initialize Widget 9
        vm.widget9.init();

        // Now widget ticker
        vm.nowWidget.ticker();

        var nowWidgetTicker = $interval(vm.nowWidget.ticker, 1000);

        $scope.$on('$destroy', function ()
        {
            $interval.cancel(nowWidgetTicker);
        });

        /**
         * Toggle sidenav
         *
         * @param sidenavId
         */
        function toggleSidenav(sidenavId)
        {
            $mdSidenav(sidenavId).toggle();
        }

        /**
         * Select project
         */
        function selectProject(project)
        {
            vm.selectedProject = project;
        }
		$scope.readmoreflag = false;
		$scope.readmorefn = function(){
		$scope.readmoreflag = true;
		
		}
		
    }

})();

(function () {
    'use strict';

    angular
        .module('app.dashboards.project')
        .directive('ddCollapseText', collapseText);

    collapseText.$inject = ['$compile'];

    /* @ngInject */
    function collapseText($compile) {
        return {
            restrict: 'A',
            replace: true,
            link: function(scope, element, attrs) {

                // start collapsed
                scope.collapsed = false;

                // create the function to toggle the collapse
                scope.toggle = function() {
                    scope.collapsed = !scope.collapsed;
                };

                // get the value of the dd-collapse-text attribute
                attrs.$observe('ddCollapseText', function(maxLength) {
                    // get the contents of the element
                    var text = element.text();

                    if (text.length > maxLength) {
                        // split the text in two parts, the first always showing
                        var firstPart = String(text).substring(0, maxLength);
                        var secondPart = String(text).substring(maxLength, text.length);

                        // create some new html elements to hold the separate info
                        var firstSpan = $compile('<span>' + firstPart + '</span>')(scope);
                        var secondSpan = $compile('<span ng-if="collapsed">' + secondPart + '</span>')(scope);
                        var moreIndicatorSpan = $compile('<span ng-if="!collapsed"></span>')(scope);
                        var toggleButton = $compile('<span class="collapse-text-toggle" ng-click="toggle()">{{collapsed ? "" : "more..."}}</span>')(scope);

                        // remove the current contents of the element
                        // and add the new ones we created
                        element.empty();
                        element.append(firstSpan);
                        element.append(secondSpan);
                        element.append(moreIndicatorSpan);
                        element.append(toggleButton);
                    }
                });
            }
        };
    }
})();

angular.module('app.dashboards.project').directive("scroll", function ($window) {
    return function(scope, element, attrs) {
        angular.element($window).bind("scroll", function() {
             if (this.pageYOffset >= 100) {
                 scope.boolChangeClass = true;
             } else {
                 scope.boolChangeClass = false;
             }
            scope.$apply();
        });
    };
});





