(function ()
{
    'use strict';

    angular
        .module('app.periodicnewreviews')
        .controller('periodicnewController', periodicnewControllerssec);

    /** @ngInject */
    function periodicnewControllerssec(customerList, $scope, $state, $location,$mdDialog,$rootScope)
    {
        
		
		$scope.viewDetails = function(data){
	    localStorage.customerFlag = "view";
		localStorage.name = data.Name;
	    localStorage.aliasName = data.aliasname;
	    localStorage.regNo = data.regNo;
	    localStorage.ofcNo = data.ofcContact;
		if(data.Stage == "Onboarded" || data.Stage == "New Customer"){
		localStorage.sidenavShowFlag = "redFlag";
		$location.path('/periodicnewreview');
		}else if(data.Stage == "Periodic Review"){
		localStorage.sidenavShowFlag = "periodic";
		$location.path('/periodicnewreview');	
		}else if(data.Stage == "Trigger"){
		localStorage.sidenavShowFlag = "trigger";
		$location.path('/periodicnewreview');	
		}
		}
		$scope.countrydetails = function(data1,data2,data3) {
		localStorage.value = data1;
		localStorage.valuehead = data2;
		localStorage.valuecontent = data3;
		
		$mdDialog.show({
		  controller: PotentialController,
		  templateUrl: 'app/main/add-customer/views/manual/form/periodicreviewpopup.html',
		  parent: angular.element(document.body),
		  
		  clickOutsideToClose:true,
		  fullscreen : true
		})
		debugger
		
		 };
		 function PotentialController($scope, $mdDialog,$rootScope) {
		// alert("data")
		// $scope.valuetab = $rootScope.value;
		
		$scope.headvalue = localStorage.valuehead;
		$scope.contentvalue = localStorage.value;
		$scope.checkercontentvalue = localStorage.valuecontent;
		 
		 
 
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  }

        // Methods

        //////////
    }
})();