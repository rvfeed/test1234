(function ()
{
    'use strict';

    angular
        .module('app.periodicreviews',[])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {

        // State
        $stateProvider.state('app.periodicreviews', {
            url    : '/periodicreview',
            views  : {
                'content@app': {
                    templateUrl: 'app/main/assignperiodicreview/periodicreview.html',
                    controller : 'periodicController as vm'
                }
            },
            resolve: {
                customerList: function (msApi)
                    {
                        return msApi.resolve('viewcustomer.list@get');
                    }
            }
        });


        // Api

        // Contacts data must be alphabatically ordered.
        // msApiProvider.register('chat.contacts', ['app/data/chat/contacts.json']);

        // msApiProvider.register('chat.chats', ['app/data/chat/chats/:id.json']);

        // msApiProvider.register('chat.user', ['app/data/chat/user.json']);
		
		msApiProvider.register('viewcustomer.list', ['app/data/scrumboard/customerlist.json']);


        // Navigation
        msNavigationServiceProvider.saveItem('apps.periodicreviews', {
            title : 'ASSIGN PERIODIC REVIEW',
			icon  : 'nav-assign-periodic-review',
            state : 'app.periodicreviews',
            weight: 5
        });
    }

})();