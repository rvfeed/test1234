(function ()
{
    'use strict';

    angular
        .module('app.periodicreviews')
        .controller('periodicController', periodicControllerssec);

    /** @ngInject */
    function periodicControllerssec(customerList, $scope, $state, $location)
    {
        var vm = this;
        // Data
		vm.contacts = customerList.data;
		
		$('.ms-theme-options-button').hide();
		$('.ms-theme-options-button1').hide();
		$('.ms-theme-options-button2').hide();
		
		// Data
        //vm.employees = Employees.data;

        vm.dtOptions = {
            dom       : '<"top"f>rt<"bottom"<"left"<"length"l>><"right"<"info"i><"pagination"p>>>',
            pagingType: 'simple',
            autoWidth : true,
            responsive: true
        };
		
		
		$scope.viewSummary = function(data){
		if(data.Stage == "Onboarded" && data.State == "Completed"){
		localStorage.sumName = data.Name;
		localStorage.sumImg = data.avatar;
		localStorage.sumAgg = data.Aggredator;
		localStorage.sumRisk = data.Risk;
		localStorage.sumAccNo = data.Number;
		$location.path('/summary');
		}else{
		return false;
		}
		
		}
		
		$scope.viewEdit = function(data){
		localStorage.customerFlag = "view";
		localStorage.name = data.Name;
	    localStorage.aliasName = data.aliasname;
	    localStorage.regNo = data.regNo;
	    localStorage.ofcNo = data.ofcContact;
		if(data.Stage == "Onboarded" || data.Stage == "New Customer"){
		localStorage.sidenavShowFlag = "redFlag";
		$location.path('/add-customer/manual');
		}else if(data.Stage == "Periodic Review"){
		localStorage.sidenavShowFlag = "periodic";
		$location.path('/add-customer/manual');	
		}else if(data.Stage == "Trigger"){
		localStorage.sidenavShowFlag = "trigger";
		$location.path('/add-customer/manual');	
		}
		}
		
		$scope.viewDetails = function(data){
	    localStorage.customerFlag = "view";
		localStorage.name = data.Name;
	    localStorage.aliasName = data.aliasname;
	    localStorage.regNo = data.regNo;
	    localStorage.ofcNo = data.ofcContact;
		if(data.Stage == "Onboarded" || data.Stage == "New Customer"){
		localStorage.sidenavShowFlag = "redFlag";
		$location.path('/periodicnewreview');
		}else if(data.Stage == "Periodic Review"){
		localStorage.sidenavShowFlag = "periodic";
		$location.path('/periodicnewreview');	
		}else if(data.Stage == "Trigger"){
		localStorage.sidenavShowFlag = "trigger";
		$location.path('/periodicnewreview');	
		}
		}

        // Methods

        //////////
    }
})();