(function ()
{
    'use strict';

    angular
        .module('app.appInfo')
        .controller('appInfoController', appInfoController);

    /** @ngInject */
    function appInfoController($scope, $location)
    {

	$("md-sidenav").hide();
	$("md-toolbar").hide();
	$("#content").css({"margin-top" :"-64px"});
	
    $scope.showFirstFlag = true;
	$scope.showFirstFlag1 = true;
	$scope.factaClick = function(data){
	if(data == "yes"){
	$scope.showFirstFlag = false;
	$scope.showFirstFlag1 = false;
	}else{
	$scope.showFirstFlag = true;
	$scope.showFirstFlag1 = true;
	}
	}
	
	$scope.factaClick1 = function(data){
	if(data == "no"){
	$scope.showFirstFlag1 = false;
	}else{
	$scope.showFirstFlag1 = true;
	}
	}
	
	$scope.showGiinFlag = false;
	$scope.factaClick2 = function(data){
	if(data == "yes"){
	$scope.showGiinFlag = true;
	}else{
	$scope.showGiinFlag = false;
	}
	}
	
	
	
	
	// Screen 3 Start
	// Non Banking Financial Institution Start
	$scope.showNonLicenseFlag = false;
	$scope.nonLicense = false;
	$scope.licenseShow = function(data){
	if(data == "no"){
	$scope.showNonLicenseFlag = true;
	$scope.nonLicense = true;
	} else{
	$scope.showNonLicenseFlag = false;
	$scope.nonLicense = false;
	}
	}
	
	$scope.requiredComment1 = false;
	$scope.requiredComment2 = false;
	$scope.requiredComment3 = false;
	$scope.requiredComment4 = false;
	$scope.requiredComment5 = false;
	$scope.requiredComment6 = false;
	$scope.requiredComment7 = false;
	$scope.requiredComment8 = false;
	$scope.requiredComment9 = false;
	$scope.requiredComment10 = false;
	$scope.requiredComment11 = false;
	$scope.requiredComment12 = false;
	$scope.requiredComment13 = false;
	$scope.requiredComment14 = false;
	$scope.requiredComment15 = false;
	$scope.requiredComment16 = false;
	$scope.requiredComment17 = false;
	$scope.requiredComment18 = false;
	$scope.requiredComment19 = false;
	
	$scope.showBankingComment1 = false;
	$scope.showBankingComment2 = false;
	$scope.showBankingComment3 = false;
	$scope.showBankingComment4 = false;
	$scope.showBankingComment5 = false;
	$scope.showBankingComment6 = false;
	$scope.showBankingComment7 = false;
	$scope.showBankingComment8 = false;
	$scope.showBankingComment9 = false;
	$scope.showBankingComment10 = false;
	$scope.showBankingComment11 = false;
	$scope.showBankingComment12 = false;
	$scope.showBankingComment13 = false;
	$scope.showBankingComment14 = false;
	$scope.showBankingComment15 = false;
	$scope.showBankingComment16 = false;
	$scope.showBankingComment17 = false;
	$scope.showBankingComment18 = false;
	$scope.showBankingComment19 = false;
	
	$scope.amlQuestion = function(value, data){
	if(value == 1){
	if(data == "no"){
	$scope.showBankingComment1 = true;
	$scope.requiredComment1 = true;
	} else {
	$scope.showBankingComment1 = false;
	$scope.requiredComment1 = false;
	}
	} else if(value == 2){
	if(data == "no"){
	$scope.showBankingComment2 = true;
	$scope.requiredComment2 = true;
	} else {
	$scope.showBankingComment2 = false;
	$scope.requiredComment2 = false;
	}
	} else if(value == 3){
	if(data == "no"){
	$scope.showBankingComment3 = true;
	$scope.requiredComment3 = true;
	} else {
	$scope.showBankingComment3 = false;
	$scope.requiredComment3 = false;
	}
	} else if(value == 4){
	if(data == "no"){
	$scope.showBankingComment4 = true;
	$scope.requiredComment4 = true;
	} else {
	$scope.showBankingComment4 = false;
	$scope.requiredComment4 = false;
	}
	} else if(value == 5){
	if(data == "no"){
	$scope.showBankingComment5 = true;
	$scope.requiredComment5 = true;
	} else {
	$scope.showBankingComment5 = false;
	$scope.requiredComment5 = false;
	}
	} else if(value == 6){
	if(data == "no"){
	$scope.showBankingComment6 = true;
	$scope.requiredComment6 = true;
	} else {
	$scope.showBankingComment6 = false;
	$scope.requiredComment6 = false;
	}
	} else if(value == 7){
	if(data == "no"){
	$scope.showBankingComment7 = true;
	$scope.requiredComment7 = true;
	} else {
	$scope.showBankingComment7 = false;
	$scope.requiredComment7 = false;
	}
	} else if(value == 8){
	if(data == "no"){
	$scope.showBankingComment8 = true;
	$scope.requiredComment8 = true;
	} else {
	$scope.showBankingComment8 = false;
	$scope.requiredComment8 = false;
	}
	} else if(value == 9){
	if(data == "no"){
	$scope.showBankingComment9 = true;
	$scope.requiredComment9 = true;
	} else {
	$scope.showBankingComment9 = false;
	$scope.requiredComment9 = false;
	}
	} else if(value == 10){
	if(data == "no"){
	$scope.showBankingComment10 = true;
	$scope.requiredComment10 = true;
	} else {
	$scope.showBankingComment10 = false;
	$scope.requiredComment10 = false;
	}
	} else if(value == 11){
	if(data == "no"){
	$scope.showBankingComment11 = true;
	$scope.requiredComment11 = true;
	} else {
	$scope.showBankingComment11 = false;
	$scope.requiredComment11 = false;
	}
	} else if(value == 12){
	if(data == "no"){
	$scope.showBankingComment12 = true;
	$scope.requiredComment12 = true;
	} else {
	$scope.showBankingComment12 = false;
	$scope.requiredComment12 = false;
	}
	} else if(value == 13){
	if(data == "yes"){
	$scope.showBankingComment13 = true;
	$scope.requiredComment13 = true;
	} else {
	$scope.showBankingComment13 = false;
	$scope.requiredComment13 = false;
	}
	} else if(value == 14){
	if(data == "yes"){
	$scope.showBankingComment14 = true;
	$scope.requiredComment14 = true;
	} else {
	$scope.showBankingComment14 = false;
	$scope.requiredComment14 = false;
	}
	} else if(value == 15){
	if(data == "yes"){
	$scope.showBankingComment15 = true;
	$scope.requiredComment15 = true;
	} else {
	$scope.showBankingComment15 = false;
	$scope.requiredComment15 = false;
	}
	} else if(value == 16){
	if(data == "yes"){
	$scope.showBankingComment16 = true;
	$scope.requiredComment16 = true;
	} else {
	$scope.showBankingComment16 = false;
	$scope.requiredComment16 = false;
	}
	} else if(value == 17){
	if(data == "yes"){
	$scope.showBankingComment17 = true;
	$scope.requiredComment17 = true;
	} else {
	$scope.showBankingComment17 = false;
	$scope.requiredComment17 = false;
	}
	} else if(value == 18){
	if(data == "yes"){
	$scope.showBankingComment18 = true;
	$scope.requiredComment18 = true;
	} else {
	$scope.showBankingComment18 = false;
	$scope.requiredComment18 = false;
	}
	} else if(value == 19){
	if(data == "yes"){
	$scope.showBankingComment19 = true;
	$scope.requiredComment19 = true;
	} else {
	$scope.showBankingComment19 = false;
	$scope.requiredComment19 = false;
	}
	}
	}
	
	$scope.assessmentFn = function(data, invalid){
	if(data == "proceed"){
	if(invalid == true){
	alert("Please fill all the values");
	angular.element("[name='" + ClientForm.$name + "']").find('.required:visible:first').focus();
	return false;
	}
	alert("Proceed");
	} else {
	alert("data has been saved");
	}
	}
	
	// Non Banking Financial Institution End
	
	// Correspondent Bank Start
	$scope.showNonLicenseFlag1 = false;
	$scope.nonLicense1 = false;
	$scope.licenseShow1 = function(data){
	if(data == "no"){
	$scope.showNonLicenseFlag1 = true;
	$scope.nonLicense1 = true;
	} else{
	$scope.showNonLicenseFlag1 = false;
	$scope.nonLicense1 = false;
	}
	}
	
	$scope.showCountryReg = false;
	$scope.countryRegFlag = false;
	$scope.bankName = function(data){
	if(data == "yes"){
	$scope.showCountryReg = true;
	$scope.countryRegFlag = true;
	} else{
	$scope.showCountryReg = false;
	$scope.countryRegFlag = false;
	}
	}
	
	$scope.showAccountPurpose = false;
	$scope.accountPurposeFlag = false;
	$scope.InsLocation = function(data){
	if(data == "yes"){
	$scope.showAccountPurpose = true;
	$scope.accountPurposeFlag = true;
	} else{
	$scope.showAccountPurpose = false;
	$scope.accountPurposeFlag = false;
	}
	}
	
	
	$scope.showWolfsbergComment1 = false;
	$scope.showWolfsbergComment2 = false;
	$scope.showWolfsbergComment3 = false;
	$scope.showWolfsbergComment4 = false;
	$scope.showWolfsbergComment5 = false;
	$scope.showWolfsbergComment6 = false;
	$scope.showWolfsbergComment7 = false;
	$scope.showWolfsbergComment8 = false;
	$scope.showWolfsbergComment9 = false;
	$scope.showWolfsbergComment10 = false;
	$scope.showWolfsbergComment11 = false;
	$scope.showWolfsbergComment12 = false;
	$scope.showWolfsbergComment13 = false;
	$scope.showWolfsbergComment14 = false;
	$scope.showWolfsbergComment15 = false;
	$scope.showWolfsbergComment16 = false;
	$scope.showWolfsbergComment17 = false;
	$scope.showWolfsbergComment18 = false;
	$scope.showWolfsbergComment19 = false;
	$scope.showWolfsbergComment20 = false;
	$scope.showWolfsbergComment21 = false;
	$scope.showWolfsbergComment22 = false;
	$scope.showWolfsbergComment23 = false;
	$scope.showWolfsbergComment24 = false;
	$scope.showWolfsbergComment25 = false;
	$scope.showWolfsbergComment26 = false;
	$scope.showWolfsbergComment27 = false;
	$scope.showWolfsbergComment28 = false;
	
	$scope.requiredWolfsberg1 = false;
	$scope.requiredWolfsberg2 = false;
	$scope.requiredWolfsberg3 = false;
	$scope.requiredWolfsberg4 = false;
	$scope.requiredWolfsberg5 = false;
	$scope.requiredWolfsberg6 = false;
	$scope.requiredWolfsberg7 = false;
	$scope.requiredWolfsberg8 = false;
	$scope.requiredWolfsberg9 = false;
	$scope.requiredWolfsberg10 = false;
	$scope.requiredWolfsberg11 = false;
	$scope.requiredWolfsberg12 = false;
	$scope.requiredWolfsberg13 = false;
	$scope.requiredWolfsberg14 = false;
	$scope.requiredWolfsberg15 = false;
	$scope.requiredWolfsberg16 = false;
	$scope.requiredWolfsberg17 = false;
	$scope.requiredWolfsberg18 = false;
	$scope.requiredWolfsberg19 = false;
	$scope.requiredWolfsberg20 = false;
	$scope.requiredWolfsberg21 = false;
	$scope.requiredWolfsberg22 = false;
	$scope.requiredWolfsberg23 = false;
	$scope.requiredWolfsberg24 = false;
	$scope.requiredWolfsberg25 = false;
	$scope.requiredWolfsberg26 = false;
	$scope.requiredWolfsberg27 = false;
	$scope.requiredWolfsberg28 = false;
	
	$scope.showAMLTrainingDiv = false;
	$scope.requiredAMLTraining = false;
	
	$scope.WolfsbergQuestion = function(value, data){
	if(value == 1){
	if(data == "no"){
	$scope.showWolfsbergComment1 = true;
	$scope.requiredWolfsberg1 = true;
	} else {
	$scope.showWolfsbergComment1 = false;
	$scope.requiredWolfsberg1 = false;
	}
	} else if(value == 2){
	if(data == "no"){
	$scope.showWolfsbergComment2 = true;
	$scope.requiredWolfsberg2 = true;
	} else {
	$scope.showWolfsbergComment2 = false;
	$scope.requiredWolfsberg2 = false;
	}
	} else if(value == 3){
	if(data == "no"){
	$scope.showWolfsbergComment3 = true;
	$scope.requiredWolfsberg3 = true;
	} else {
	$scope.showWolfsbergComment3 = false;
	$scope.requiredWolfsberg3 = false;
	}
	} else if(value == 4){
	if(data == "no"){
	$scope.showWolfsbergComment4 = true;
	$scope.requiredWolfsberg4 = true;
	} else {
	$scope.showWolfsbergComment4 = false;
	$scope.requiredWolfsberg4 = false;
	}
	} else if(value == 5){
	if(data == "no"){
	$scope.showWolfsbergComment5 = true;
	$scope.requiredWolfsberg5 = true;
	} else {
	$scope.showWolfsbergComment5 = false;
	$scope.requiredWolfsberg5 = false;
	}
	} else if(value == 6){
	if(data == "no"){
	$scope.showWolfsbergComment6 = true;
	$scope.requiredWolfsberg6 = true;
	} else {
	$scope.showWolfsbergComment6 = false;
	$scope.requiredWolfsberg6 = false;
	}
	} else if(value == 7){
	if(data == "no"){
	$scope.showWolfsbergComment7 = true;
	$scope.requiredWolfsberg7 = true;
	} else {
	$scope.showWolfsbergComment7 = false;
	$scope.requiredWolfsberg7 = false;
	}
	} else if(value == 8){
	if(data == "no"){
	$scope.showWolfsbergComment8 = true;
	$scope.requiredWolfsberg8 = true;
	} else {
	$scope.showWolfsbergComment8 = false;
	$scope.requiredWolfsberg8 = false;
	}
	} else if(value == 9){
	if(data == "no"){
	$scope.showWolfsbergComment9 = true;
	$scope.requiredWolfsberg9 = true;
	} else {
	$scope.showWolfsbergComment9 = false;
	$scope.requiredWolfsberg9 = false;
	}
	} else if(value == 10){
	if(data == "no"){
	$scope.showWolfsbergComment10 = true;
	$scope.requiredWolfsberg10 = true;
	} else {
	$scope.showWolfsbergComment10 = false;
	$scope.requiredWolfsberg10 = false;
	}
	} else if(value == 11){
	if(data == "no"){
	$scope.showWolfsbergComment11 = true;
	$scope.requiredWolfsberg11 = true;
	} else {
	$scope.showWolfsbergComment11 = false;
	$scope.requiredWolfsberg11 = false;
	}
	} else if(value == 12){
	if(data == "no"){
	$scope.showWolfsbergComment12 = true;
	$scope.requiredWolfsberg12 = true;
	} else {
	$scope.showWolfsbergComment12 = false;
	$scope.requiredWolfsberg12 = false;
	}
	} else if(value == 13){
	if(data == "no"){
	$scope.showWolfsbergComment13 = true;
	$scope.requiredWolfsberg13 = true;
	} else {
	$scope.showWolfsbergComment13 = false;
	$scope.requiredWolfsberg13 = false;
	}
	} else if(value == 14){
	if(data == "no"){
	$scope.showWolfsbergComment14 = true;
	$scope.requiredWolfsberg14 = true;
	} else {
	$scope.showWolfsbergComment14 = false;
	$scope.requiredWolfsberg14 = false;
	}
	} else if(value == 15){
	if(data == "no"){
	$scope.showWolfsbergComment15 = true;
	$scope.requiredWolfsberg15 = true;
	} else {
	$scope.showWolfsbergComment15 = false;
	$scope.requiredWolfsberg15 = false;
	}
	} else if(value == 16){
	if(data == "no"){
	$scope.showWolfsbergComment16 = true;
	$scope.requiredWolfsberg16 = true;
	} else {
	$scope.showWolfsbergComment16 = false;
	$scope.requiredWolfsberg16 = false;
	}
	} else if(value == 17){
	if(data == "no"){
	$scope.showWolfsbergComment17 = true;
	$scope.requiredWolfsberg17 = true;
	} else {
	$scope.showWolfsbergComment17 = false;
	$scope.requiredWolfsberg17 = false;
	}
	} else if(value == 18){
	if(data == "no"){
	$scope.showWolfsbergComment18 = true;
	$scope.requiredWolfsberg18 = true;
	} else {
	$scope.showWolfsbergComment18 = false;
	$scope.requiredWolfsberg18 = false;
	}
	} else if(value == 19){
	if(data == "no"){
	$scope.showWolfsbergComment19 = true;
	$scope.requiredWolfsberg19 = true;
	} else {
	$scope.showWolfsbergComment19 = false;
	$scope.requiredWolfsberg19 = false;
	}
	} else if(value == 20){
	if(data == "no"){
	$scope.showWolfsbergComment20 = true;
	$scope.requiredWolfsberg20 = true;
	} else {
	$scope.showWolfsbergComment20 = false;
	$scope.requiredWolfsberg20 = false;
	}
	} else if(value == 21){
	if(data == "no"){
	$scope.showWolfsbergComment21 = true;
	$scope.requiredWolfsberg21 = true;
	} else {
	$scope.showWolfsbergComment21 = false;
	$scope.requiredWolfsberg21 = false;
	}
	} else if(value == 22){
	if(data == "no"){
	$scope.showWolfsbergComment22 = true;
	$scope.requiredWolfsberg22 = true;
	} else {
	$scope.showWolfsbergComment22 = false;
	$scope.requiredWolfsberg22 = false;
	}
	} else if(value == 23){
	if(data == "no"){
	$scope.showWolfsbergComment23 = true;
	$scope.requiredWolfsberg23 = true;
	} else {
	$scope.showWolfsbergComment23 = false;
	$scope.requiredWolfsberg23 = false;
	}
	} else if(value == 24){
	if(data == "no"){
	$scope.showWolfsbergComment24 = true;
	$scope.requiredWolfsberg24 = true;
	} else {
	$scope.showWolfsbergComment24 = false;
	$scope.requiredWolfsberg24 = false;
	}
	} else if(value == 25){
	if(data == "no"){
	$scope.showWolfsbergComment25 = true;
	$scope.requiredWolfsberg25 = true;
	} else {
	$scope.showWolfsbergComment25 = false;
	$scope.requiredWolfsberg25 = false;
	}
	} else if(value == 26){
	if(data == "no"){
	$scope.showWolfsbergComment26 = true;
	$scope.requiredWolfsberg26 = true;
	} else {
	$scope.showWolfsbergComment26 = false;
	$scope.requiredWolfsberg26 = false;
	}
	} else if(value == 27){
	if(data == "no"){
	$scope.showWolfsbergComment27 = true;
	$scope.requiredWolfsberg27 = true;
	} else {
	$scope.showWolfsbergComment27 = false;
	$scope.requiredWolfsberg27 = false;
	}
	} else if(value == 28){
	if(data == "no"){
	$scope.showWolfsbergComment28 = true;
	$scope.requiredWolfsberg28 = true;
	} else {
	$scope.showWolfsbergComment28 = false;
	$scope.requiredWolfsberg28 = false;
	}
	}
	
	if($scope.correspondent.Wolfsberg25 == "no" && $scope.correspondent.Wolfsberg26 == "no" && $scope.correspondent.Wolfsberg27 == "no"){
		$scope.showAMLTrainingDiv = true;
		$scope.requiredAMLTraining = true;
	} else{
		$scope.showAMLTrainingDiv = false;
		$scope.requiredAMLTraining = false;
	}
		}
	
	
	$scope.correspondentFn = function(data, invalid){
	if(data == "proceed"){
	if(invalid == true){
	alert("Please fill all the values");
	return false;
	}
	alert("Proceed");
	} else {
	alert("data has been saved");
	}
	
	}
	// Correspondent Bank End
	
	
	// Money Service Business Start
	$scope.showNonLicenseFlag2 = false;
	$scope.nonLicense2 = false;
	$scope.licenseShow2 = function(data){
	if(data == "no"){
	$scope.showNonLicenseFlag2 = true;
	$scope.nonLicense2 = true;
	} else{
	$scope.showNonLicenseFlag2 = false;
	$scope.nonLicense2 = false;
	}
	}
	
	$scope.checkCustomerFlag = false;
	$scope.requiredThreshold = false;
	$scope.checkCustomer = function(data){
	if(data == "yes"){
	$scope.checkCustomerFlag = true;
	$scope.requiredThreshold = true;
	} else{
	$scope.checkCustomerFlag = false;
	$scope.requiredThreshold = false;
	alert("You are not an MSB Customer. Please proceed with the next form");
	}
	}
	
	$scope.checkCustomerFlag1 = false;
	$scope.requiredRevenue = false;
	$scope.checkCustomer1 = function(data){
	if(data == "yes"){
	$scope.checkCustomerFlag1 = true;
	$scope.requiredRevenue = true;
	} else{
	$scope.checkCustomerFlag1 = false;
	$scope.requiredRevenue = false;
	alert("You are not an MSB Customer. Please proceed with the next form");
	}
	}
	
	$scope.checkCustomerFlag2 = false;
	$scope.requiredActivity = false;
	$scope.checkCustomer2 = function(data){
	if(data == "yes"){
	$scope.checkCustomerFlag2 = true;
	$scope.requiredActivity = true;
	} else{
	$scope.checkCustomerFlag2 = false;
	$scope.requiredActivity = false;
	alert("You are not an MSB Customer. Please proceed with the next form");
	}
	}
	
	$scope.checkCustomerFlag3 = false;
	$scope.requiredBusinessFields = false;
	$scope.checkCustomer3 = function(data){
	if(data == "yes"){
	$scope.checkCustomerFlag3 = true;
	$scope.requiredBusinessFields = true;
	} else{
	$scope.checkCustomerFlag3 = false;
	$scope.requiredBusinessFields = false;
	alert("You are not an MSB Customer. Please proceed with the next form");
	}
	}
	
	
	$scope.requiredType = false;
	$scope.showDropdownValue = false;
	$scope.showDropdownValue1 = false;
	$scope.showDropdownValue2 = false;
	$scope.customerTypes = function(data){
	debugger;
	if(data == "Walk-In"){
	$scope.requiredType = true;
	$scope.showDropdownValue = true;
	$scope.showDropdownValue1 = false;
	$scope.showDropdownValue2 = false;
	} else if(data == "Online"){
	$scope.requiredType = true;
	$scope.showDropdownValue = false;
	$scope.showDropdownValue1 = true;
	$scope.showDropdownValue2 = false;
	} else if(data == "Other"){
	$scope.requiredType = true;
	$scope.showDropdownValue = false;
	$scope.showDropdownValue1 = false;
	$scope.showDropdownValue2 = true;
	} else{
	$scope.requiredType = false;
	$scope.showDropdownValue = false;
	$scope.showDropdownValue1 = false;
	$scope.showDropdownValue2 = false;
	}
	}
	
	$scope.showOthersDiv = false;
	$scope.requiredOthersFields = false;
	$scope.typeCheck = function(data, value){
	if(value == "others"){
	$scope.showOthersDiv = true;
	$scope.requiredOthersFields = true;
	} else{
	$scope.showOthersDiv = false;
	$scope.requiredOthersFields = false;
	}
	}
	
	$scope.showPrincipalFlag = false;
	$scope.showAgentFlag = false;
	$scope.requiredAgentFields = false;
	$scope.requiredPrincipalFields = false;
	$scope.catagoryFn = function(data){
	if(data == "Principal"){
	$scope.showPrincipalFlag = true;
	$scope.showAgentFlag = false;
	$scope.requiredAgentFields = true;
	$scope.requiredPrincipalFields = false;
	} else {
	$scope.showAgentFlag = true;
	$scope.showPrincipalFlag = false;
	$scope.requiredAgentFields = false;
	$scope.requiredPrincipalFields = true;
	}
	}
	
	$scope.agentReviewCommentFlag = false;
	$scope.requiredAgentCommentFields = false;
	$scope.agentConcernCommentFlag = false;
	$scope.requiredAgentConcernFields = false;
	$scope.agentReviewFn = function(value, data){
	if(value == 1){
	if(data == "no"){
	$scope.agentReviewCommentFlag = true;
	$scope.requiredAgentCommentFields = true;
	} else {
	$scope.agentReviewCommentFlag = false;
	$scope.requiredAgentCommentFields = false;
	}
	} else if(value == 2){
	if(data == "yes"){
	$scope.agentConcernCommentFlag = true;
	$scope.requiredAgentConcernFields = true;
	} else {
	$scope.agentConcernCommentFlag = false;
	$scope.requiredAgentConcernFields = false;
	}
	}
	}
	
	$scope.showMSBComment1 = false;
	$scope.showMSBComment2 = false;
	$scope.showMSBComment3 = false;
	$scope.showMSBComment4 = false;
	$scope.showMSBComment5 = false;
	$scope.showMSBComment6 = false;
	$scope.showMSBComment7 = false;
	$scope.showMSBComment8 = false;
	$scope.showMSBComment9 = false;
	$scope.showMSBComment10 = false;
	$scope.showMSBComment11 = false;
	$scope.showMSBComment12 = false;
	$scope.showMSBComment13 = false;
	$scope.showMSBComment14 = false;
	$scope.showMSBComment15 = false;
	$scope.showMSBComment16 = false;
	$scope.showMSBComment17 = false;
	$scope.showMSBComment18 = false;
	$scope.showMSBComment19 = false;
	
	$scope.requiredMSBQuestion1 = false;
	$scope.requiredMSBQuestion2 = false;
	$scope.requiredMSBQuestion3 = false;
	$scope.requiredMSBQuestion4 = false;
	$scope.requiredMSBQuestion5 = false;
	$scope.requiredMSBQuestion6 = false;
	$scope.requiredMSBQuestion7 = false;
	$scope.requiredMSBQuestion8 = false;
	$scope.requiredMSBQuestion9 = false;
	$scope.requiredMSBQuestion10 = false;
	$scope.requiredMSBQuestion11 = false;
	$scope.requiredMSBQuestion12 = false;
	$scope.requiredMSBQuestion13 = false;
	$scope.requiredMSBQuestion14 = false;
	$scope.requiredMSBQuestion15 = false;
	$scope.requiredMSBQuestion16 = false;
	$scope.requiredMSBQuestion17 = false;
	$scope.requiredMSBQuestion18 = false;
	$scope.requiredMSBQuestion19 = false;
	
	$scope.MSBQuestionFn = function(value, data){
	if(value == 1){
	if(data == "no"){
	$scope.showMSBComment1 = true;
	$scope.requiredMSBQuestion1 = true;
	} else {
	$scope.showMSBComment1 = false;
	$scope.requiredMSBQuestion1 = false;
	}
	} else if(value == 2){
	if(data == "no"){
	$scope.showMSBComment2 = true;
	$scope.requiredMSBQuestion2 = true;
	} else {
	$scope.showMSBComment2 = false;
	$scope.requiredMSBQuestion2 = false;
	}
	} else if(value == 3){
	if(data == "no"){
	$scope.showMSBComment3 = true;
	$scope.requiredMSBQuestion3 = true;
	} else {
	$scope.showMSBComment3 = false;
	$scope.requiredMSBQuestion3 = false;
	}
	} else if(value == 4){
	if(data == "no"){
	$scope.showMSBComment4 = true;
	$scope.requiredMSBQuestion4 = true;
	} else {
	$scope.showMSBComment4 = false;
	$scope.requiredMSBQuestion4 = false;
	}
	} else if(value == 5){
	if(data == "no"){
	$scope.showMSBComment5 = true;
	$scope.requiredMSBQuestion5 = true;
	} else {
	$scope.showMSBComment5 = false;
	$scope.requiredMSBQuestion5 = false;
	}
	} else if(value == 6){
	if(data == "no"){
	$scope.showMSBComment6 = true;
	$scope.requiredMSBQuestion6 = true;
	} else {
	$scope.showMSBComment6 = false;
	$scope.requiredMSBQuestion6 = false;
	}
	} else if(value == 7){
	if(data == "no"){
	$scope.showMSBComment7 = true;
	$scope.requiredMSBQuestion7 = true;
	} else {
	$scope.showMSBComment7 = false;
	$scope.requiredMSBQuestion7 = false;
	}
	} else if(value == 8){
	if(data == "no"){
	$scope.showMSBComment8 = true;
	$scope.requiredMSBQuestion8 = true;
	} else {
	$scope.showMSBComment8 = false;
	$scope.requiredMSBQuestion8 = false;
	}
	} else if(value == 9){
	if(data == "no"){
	$scope.showMSBComment9 = true;
	$scope.requiredMSBQuestion9 = true;
	} else {
	$scope.showMSBComment9 = false;
	$scope.requiredMSBQuestion9 = false;
	}
	} else if(value == 10){
	if(data == "no"){
	$scope.showMSBComment10 = true;
	$scope.requiredMSBQuestion10 = true;
	} else {
	$scope.showMSBComment10 = false;
	$scope.requiredMSBQuestion10 = false;
	}
	} else if(value == 11){
	if(data == "no"){
	$scope.showMSBComment11 = true;
	$scope.requiredMSBQuestion11 = true;
	} else {
	$scope.showMSBComment11 = false;
	$scope.requiredMSBQuestion11 = false;
	}
	} else if(value == 12){
	if(data == "no"){
	$scope.showMSBComment12 = true;
	$scope.requiredMSBQuestion12 = true;
	} else {
	$scope.showMSBComment12 = false;
	$scope.requiredMSBQuestion12 = false;
	}
	} else if(value == 13){
	if(data == "yes"){
	$scope.showMSBComment13 = true;
	$scope.requiredMSBQuestion13 = true;
	} else {
	$scope.showMSBComment13 = false;
	$scope.requiredMSBQuestion13 = false;
	}
	} else if(value == 14){
	if(data == "yes"){
	$scope.showMSBComment14 = true;
	$scope.requiredMSBQuestion14 = true;
	} else {
	$scope.showMSBComment14 = false;
	$scope.requiredMSBQuestion14 = false;
	}
	} else if(value == 15){
	if(data == "yes"){
	$scope.showMSBComment15 = true;
	$scope.requiredMSBQuestion15 = true;
	} else {
	$scope.showMSBComment15 = false;
	$scope.requiredMSBQuestion15 = false;
	}
	} else if(value == 16){
	if(data == "yes"){
	$scope.showMSBComment16 = true;
	$scope.requiredMSBQuestion16 = true;
	} else {
	$scope.showMSBComment16 = false;
	$scope.requiredMSBQuestion16 = false;
	}
	} else if(value == 17){
	if(data == "yes"){
	$scope.showMSBComment17 = true;
	$scope.requiredMSBQuestion17 = true;
	} else {
	$scope.showMSBComment17 = false;
	$scope.requiredMSBQuestion17 = false;
	}
	} else if(value == 18){
	if(data == "yes"){
	$scope.showMSBComment18 = true;
	$scope.requiredMSBQuestion18 = true;
	} else {
	$scope.showMSBComment18 = false;
	$scope.requiredMSBQuestion18 = false;
	}
	} else if(value == 19){
	if(data == "yes"){
	$scope.showMSBComment19 = true;
	$scope.requiredMSBQuestion19 = true;
	} else {
	$scope.showMSBComment19 = false;
	$scope.requiredMSBQuestion19 = false;
	}
	}
	}
	
	
	$scope.MSBForm = function(data, invalid){
	if(data == "proceed"){
	if(invalid == true){
	alert("Please fill all the values");
	angular.element("[name='" + ClientForm.$name + "']").find('.required:visible:first').focus();
	return false;
	}
	alert("Proceed");
	} else {
	alert("data has been saved");
	}
	}
	
	
	// Money Service Business End
	// Screen 3 End
	

	

 
    }
})();


