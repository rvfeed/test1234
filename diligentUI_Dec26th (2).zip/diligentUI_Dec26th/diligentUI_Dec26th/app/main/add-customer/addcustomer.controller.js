(function ()
{
    'use strict';

    angular
        .module('app.addcustomer')
        .controller('addcustomerController', addcustomerController);

    /** @ngInject */
    function addcustomerController($scope, $state, $location)
    {
	
   
	    $('.ms-theme-options-button').hide();
		$('.ms-theme-options-button1').hide();
		$('.ms-theme-options-button2').hide();
		$('.ms-theme-options-button3').hide();
		$('.ms-theme-options-button4').hide();
		$("#kitkat").hide();
		$scope.showMicIcon = true;
		$scope.showNoteIcon = true;
  $scope.timelineFn = function(){
	  localStorage.timelineFlag = $scope.timelineFlag;
  }
  
  $scope.scrollTopFn = function(id) {
    $location.hash(id);
    console.log($location.hash());
    $anchorScroll();
  };
  	
  if(localStorage.timelineFlag == false){
  $scope.showAddCustomerFlag1 = false;
  $scope.showAddCustomerFlag2 = true; 
  }
  $scope.showAddCustomerFlag1 = true;
  $scope.showAddCustomerFlag2 = false;
  $scope.showMaimCon = function(){
  $scope.showAddCustomerFlag1 = false;
  $scope.showAddCustomerFlag2 = true;
  }
	
	
	$scope.excelSheetFn = function(){
	$location.path('/add-customer/upload');
	}
	
	$scope.manualFn = function(){
    localStorage.sidenavShowFlag = "redFlag";
	localStorage.customerFlag = "manual";
	$location.path('/add-customer/manual');
	}

 
    }
})();