(function ()
{
    'use strict';

    angular
        .module('app.upload',[])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {

        // State
        $stateProvider.state('app.upload', {
            url    : '/add-customer/upload',
            views  : {
                'content@app': {
                    templateUrl: 'app/main/add-customer/views/upload/upload.html',
                    controller : 'uploadController as vm'
                }
            },
            resolve: {
                upload: function (msApi)
                {
                    return msApi.resolve('addcustomer.upload@get');
                }
            }
        });


        // Api

        // Contacts data must be alphabatically ordered.
        // msApiProvider.register('chat.contacts', ['app/data/chat/contacts.json']);

        // msApiProvider.register('chat.chats', ['app/data/chat/chats/:id.json']);

         msApiProvider.register('addcustomer.upload', ['app/data/add-customer/upload.json']);


        // Navigation
        // msNavigationServiceProvider.saveItem('apps.help', {
            // title : 'Help',
			// icon  : 'icon-tile-four',
            // state : 'app.help',
            // weight: 14
        // });
    }

})();