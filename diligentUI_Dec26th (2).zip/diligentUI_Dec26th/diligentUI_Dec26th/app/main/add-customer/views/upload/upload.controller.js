(function ()
{
    'use strict';

    angular
        .module('app.upload')
        .controller('uploadController', uploadController);

    /** @ngInject */
    function uploadController($scope, upload, $location)
    {
	
	var vm = this;
	
	$scope.uploadData = function(data){
	localStorage.name = data.Name;
	localStorage.aliasName = data.aliasname;
	localStorage.regNo = data.regNo;
	localStorage.ofcNo = data.ofcContact;
	$location.path('/add-customer/manual');
	}

	vm.uploads = upload.data;
	
	 vm.dtOptions = {
            dom       : '<"top"f>rt<"bottom"<"left"<"length"l>><"right"<"info"i><"pagination"p>>>',
            pagingType: 'simple',
            autoWidth : true,
            responsive: true
        };

 
    }
})();