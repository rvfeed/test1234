if($scope.AbilityToInfluence == "Yes" && $scope.ReputationRiskRisk == "Yes" && $scope.SOWSOIRisk == "Yes" && $scope.GeographicRisk == "High"){
$scope.riskAssementRating = "High";
}
else if($scope.AbilityToInfluence == "Yes" && $scope.ReputationRisk == "Yes" && $scope.SOWSOIRisk == "Yes" && $scope.GeographicRisk == "Medium"){
$scope.riskAssementRating = "High";
}
else if($scope.AbilityToInfluence == "Yes" && $scope.ReputationRisk == "Yes" && $scope.SOWSOIRisk == "Yes" && $scope.GeographicRisk == "Low"){
$scope.riskAssementRating = "High";
}

else if($scope.AbilityToInfluence == "Yes" && $scope.ReputationRisk == "Yes" && $scope.SOWSOIRisk == "No" && $scope.GeographicRisk == "High"){
$scope.riskAssementRating = "High";
}
else if($scope.AbilityToInfluence == "Yes" && $scope.ReputationRisk == "Yes" && $scope.SOWSOIRisk == "No" && $scope.GeographicRisk == "Medium"){
$scope.riskAssementRating = "Medium";
}
else if($scope.AbilityToInfluence == "Yes" && $scope.ReputationRisk == "Yes" && $scope.SOWSOIRisk == "No" && $scope.GeographicRisk == "Low"){
$scope.riskAssementRating = "Medium";
}
 
else if($scope.AbilityToInfluence == "Yes" && $scope.ReputationRisk == "No" && $scope.SOWSOIRisk == "Yes" && $scope.GeographicRisk == "High"){
$scope.riskAssementRating = "High";
}
else if($scope.AbilityToInfluence == "Yes" && $scope.ReputationRisk == "No" && $scope.SOWSOIRisk == "Yes" && $scope.GeographicRisk == "Medium"){
$scope.riskAssementRating = "High";
}
else if($scope.AbilityToInfluence == "Yes" && $scope.ReputationRisk == "No" && $scope.SOWSOIRisk == "Yes" && $scope.GeographicRisk == "Low"){
$scope.riskAssementRating = "Medium";
}

else if($scope.AbilityToInfluence == "Yes" && $scope.ReputationRisk == "No" && $scope.SOWSOIRisk == "No" && $scope.GeographicRisk == "High"){
$scope.riskAssementRating = "Medium";
}
else if($scope.AbilityToInfluence == "Yes" && $scope.ReputationRisk == "No" && $scope.SOWSOIRisk == "No" && $scope.GeographicRisk == "Medium"){
$scope.riskAssementRating = "Medium";
}
else if($scope.AbilityToInfluence == "Yes" && $scope.ReputationRisk == "No" && $scope.SOWSOIRisk == "No" && $scope.GeographicRisk == "Low"){
$scope.riskAssementRating = "Medium";
}

/* NO */

else if($scope.AbilityToInfluence == "No" && $scope.ReputationRisk == "Yes" && $scope.SOWSOIRisk == "Yes" && $scope.GeographicRisk == "High"){
$scope.riskAssementRating = "High";
}
else if($scope.AbilityToInfluence == "No" && $scope.ReputationRisk == "Yes" && $scope.SOWSOIRisk == "Yes" && $scope.GeographicRisk == "Medium"){
$scope.riskAssementRating = "High";
}
else if($scope.AbilityToInfluence == "No" && $scope.ReputationRisk == "Yes" && $scope.SOWSOIRisk == "Yes" && $scope.GeographicRisk == "Low"){
$scope.riskAssementRating = "Medium";
}

else if($scope.AbilityToInfluence == "No" && $scope.ReputationRisk == "Yes" && $scope.SOWSOIRisk == "No" && $scope.GeographicRisk == "High"){
$scope.riskAssementRating = "Medium";
}
else if($scope.AbilityToInfluence == "No" && $scope.ReputationRisk == "Yes" && $scope.SOWSOIRisk == "No" && $scope.GeographicRisk == "Medium"){
$scope.riskAssementRating = "Medium";
}
else if($scope.AbilityToInfluence == "No" && $scope.ReputationRisk == "Yes" && $scope.SOWSOIRisk == "No" && $scope.GeographicRisk == "Low"){
$scope.riskAssementRating = "Medium";
}
 
else if($scope.AbilityToInfluence == "No" && $scope.ReputationRisk == "No" && $scope.SOWSOIRisk == "Yes" && $scope.GeographicRisk == "High"){
$scope.riskAssementRating = "High";
}
else if($scope.AbilityToInfluence == "No" && $scope.ReputationRisk == "No" && $scope.SOWSOIRisk == "Yes" && $scope.GeographicRisk == "Medium"){
$scope.riskAssementRating = "Medium";
}
else if($scope.AbilityToInfluence == "No" && $scope.ReputationRisk == "No" && $scope.SOWSOIRisk == "Yes" && $scope.GeographicRisk == "Low"){
$scope.riskAssementRating = "Medium";
}

else if($scope.AbilityToInfluence == "No" && $scope.ReputationRisk == "No" && $scope.SOWSOIRisk == "No" && $scope.GeographicRisk == "High"){
$scope.riskAssementRating = "Medium";
}
else if($scope.AbilityToInfluence == "No" && $scope.ReputationRisk == "No" && $scope.SOWSOIRisk == "No" && $scope.GeographicRisk == "Medium"){
$scope.riskAssementRating = "Low";
}
else if($scope.AbilityToInfluence == "No" && $scope.ReputationRisk == "No" && $scope.SOWSOIRisk == "No" && $scope.GeographicRisk == "Low"){
$scope.riskAssementRating = "Low";
}