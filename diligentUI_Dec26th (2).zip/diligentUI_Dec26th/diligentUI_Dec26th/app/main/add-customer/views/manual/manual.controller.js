(function ()
{
    'use strict';

    angular
        .module('app.manual')
        .controller('manualController', manualController);

    /** @ngInject */
    function manualController($scope,$rootScope, Potential, Potential1, Potential2, Potential3, Document, Prohibited, Country, ISIC, Currency, Stock, $timeout, $window, Timeline,$mdDialog,addcustomerdedupe,$location, $anchorScroll,screeningData,$element,unwrappingData,relatedvalue,slidervalue)
    {
	
	
	var vm = this;
	localStorage.tabvalue = "Customer Information Program";
	
		vm.tableValue7 = addcustomerdedupe.table;	
		vm.relatedtableValue7 = relatedvalue.table;	
		vm.screeningDataList =screeningData.list
		vm.screeningDataListval =screeningData.listtab		
		vm.screeningDataListval1 =screeningData.listtab2
		vm.screeningDataListval2 =screeningData.listtab3
		vm.screeningDataListval3 =screeningData.listtab4  
		vm.unwrappingData=unwrappingData.data
		vm.slideScrData=slidervalue.data
		
		$scope.screenitem1 = [{id: 1, "name": "Nexus Bank"}];
		
		$scope.screenitem2 = [{id: 1, "name": "BO - 1"},{id: 2, "name": "BO - 2"},{id: 3, "name": "BO - 3"}];
		
		$scope.screenitem3 = [{id: 1, "name": "BO - 4"},{id: 2, "name": "BO - 5"},{id: 3, "name": "BO - 6"}];
		
		$scope.screenitem4 = [{id: 1, "name": "Mr. A"},{id: 2, "name": "Mr. B"}];
		
		$scope.screenitem5 = [{id: 1, "name": "Trustee I"},{id: 2, "name": "Trustee I"}];
		
		$scope.screenitem6 = [{id: 1, "name": "Trustee NI"},{id: 2, "name": "Trustee NI"}];
		
		$scope.countryarray = ["India","Singapore","Indonesia","Malaysia","Hongkong","Dubai"];
		  $scope.selecteddropdown = $scope.countryarray[1];
		  $scope.idvinfostandardFlag = 45; 
			$scope.fnidvstandard = function(data){
			$scope.idvinfostandardFlag = data; 
			}
			
			
			
  
  
			
				$scope.idvothersstandardFlag1 = 52; 
					$scope.fnidvothers1 = function(data){
					$scope.idvothersstandardFlag1 = data; 
					}
		
		$scope.risk_rating = ["High","Medium","Low"];
$scope.risk_rating_response = ["Yes","No"];
$scope.risk_rating_response1 = ["Yes","No"];
        // $scope.riskbasedvaluenew7 = "Low";
		
$scope.productrisk = function(value){
debugger
if(value.riskbasednew7 == "Yes" && value.riskbasednew6 == "Yes" && value.riskbasednew5 == "No"){
$scope.riskbasedvaluenew7 = "High"
}
else if(value.riskbasednew7 == "No" && value.riskbasednew6 == "Yes" && value.riskbasednew5 == "No"){
$scope.riskbasedvaluenew7 = "Medium"
}
else if(value.riskbasednew7 == "No" && value.riskbasednew6 == "No" && value.riskbasednew5 == "Yes"){
$scope.riskbasedvaluenew7 = "Low"
}
else if(value.riskbasednew7 == "Yes" && value.riskbasednew6 == "No" && value.riskbasednew5 == "No"){
$scope.riskbasedvaluenew7 = "High"
}
else if(value.riskbasednew7 == "Yes" && value.riskbasednew6 == "Yes" && value.riskbasednew5 == "Yes"){
$scope.riskbasedvaluenew7 = "High"
}
}

		//vm.screeningDataListval =screeningData.listtab2	
		$scope.value9="Customer Id"
		$scope.value10="Customer Legal Name"
		$scope.value10a="Registation Number"
		$scope.value11="Customer Alias Name"
		$scope.value12="Status"
		$scope.value13="Office Contact Number"
		$scope.value14="VIEW"
		$scope.relvalue15="Customer Name"
		$scope.relvalue16="Date Of Birth"
		$scope.relvalue17="Nationality"
		$scope.relvalue18="ID Number"
		$scope.nonrelvalue19="DOI"
		$scope.nonrelvalue20="Reg Identification No"
		
		$scope.mandatoryForm2step2slcount2="Customer"
		$scope.mandatoryForm2step2slcount3="Beneficiary"
		$scope.mandatoryForm2step2slcount7="Rajiv"
		$scope.mandatoryForm2step2slcount8="kumar"
		$scope.mandatoryForm2step2slcount9="kanna"
		$scope.mandatoryForm2step2slcount10="Alias"
		$scope.mandatoryForm2step2slcount11="Local"
		$scope.mandatoryForm2nonindivstep2slcount4="China Bank Limited"
		$scope.mandatoryForm2nonindivstep2slcount6="America"
		$scope.mandatoryForm2step2sldatecount11="24/11/2011"
		
		$('.ms-theme-options-button3').show();
		$('.ms-theme-options-button4').show();
		
		$scope.scrollTopFn = function(id) {
    $location.hash(id);
    console.log($location.hash());
    $anchorScroll();
  };
  
  $scope.date = new Date();

$scope.loginname = localStorage.permission;

  //$scope.showRelatedQuesFlag1 = false;
  $scope.showRelatedQues1 = function(){
  $scope.individualsetup = false;
  $scope.showrelatedMatchFlag1 = false;
  $scope.showRelatedQuesFlag1 = true; 
$scope.showRelatedQuesFlag2 = false;	
$scope.showRelatedQuesFlag3 = false;
  }
  $scope.dedupebtnshow = false;
  $scope.exportbtn = function(){
  debugger;
  $scope.menumaskflag = false;
  $scope.dedupebtnshow = true;
  $scope.individualexport = true;
  $scope.showexportrelatedadd = true;
  $scope.showrelatedMatchFlag1 = false;
  $scope.showrelatedMatchFlag2 = false;
  $scope.showrelatedMatchFlag3 = false;
  $scope.showrelatedMatchFlag4 = false;
  $scope.showrelatedMatchFlag5 = false;
  $scope.showrelatedMatchFlag6 = false;
  $scope.shownonrelatedMatchFlag1 = false;
  $scope.shownonrelatedMatchFlag2 = false;
  $scope.shownonrelatedMatchFlag3 = false;
  $scope.riskcode = "Ion12376";
  $scope.resolution = "value";
  $scope.resolutioncomments = "";
  $scope.relparty = "Frank";
  $scope.pinnumberl = "6002579";
  
  $scope.dedube_tablesec1 = false;
  $scope.dedube_tablesec2 = false;  
  
  }  
  $scope.emailidrel25 = "mdg@xome.com";
  $scope.Sourceofwealthlrel = "Salaried";
$scope.exportbtn1 = function(){
  debugger;
  $scope.shownonindRelatedQuesFlag4 = true;
  $scope.menumaskflag = false;
  $scope.dedupebtnshow = true;
  $scope.individualexport = true;
  $scope.showexportrelatedadd = true;
  $scope.showexportrelatedadd1 = true;
  $scope.showrelatedMatchFlag1 = false;
  $scope.showrelatedMatchFlag2 = false;
  $scope.showrelatedMatchFlag3 = false;
  $scope.showrelatedMatchFlag4 = false;
  $scope.showrelatedMatchFlag5 = false;
  $scope.showrelatedMatchFlag6 = false;
  $scope.shownonrelatedMatchFlag1 = false;
  $scope.shownonrelatedMatchFlag2 = false;
  $scope.shownonrelatedMatchFlag3 = false;
  $scope.riskcode = "Ion12376";
  $scope.resolution = "value";
  $scope.resolutioncomments = "";
  $scope.relparty = "Frank";
  $scope.pinnumberl = "600257";
  $scope.emailidrel25 = "mdg@xome.com";
  $scope.Sourceofwealthlrel = "Salaried";
  $scope.dedube_tablesec1 = false;
  $scope.dedube_tablesec2 = false; 
  $scope.exportInfononindAddress2l = "No.27";
  $scope.exportInfostep7OfficerelID = "IAH52145";
  $scope.exportInfononindaddressoff2l = "Jack Street";
  $scope.nonindwealthl = "Salaried";  
  $scope.vmCustomerApplicationnonInfostep7rel = "value";
  $scope.nonlistingonrec = "value";
  $scope.nonregulatedfi = "value";
  $scope.nonregf = "value";
  $scope.nonPubliclyquoted = "value";
  $scope.nonmajoritystatus = "value";
  
  }   
  $scope.riskcodeval = ["IAN1289","IAN1279","IAN1589"];
  $scope.relwithcustomerarray = ["BO","Executive Management","Directors","Authorised Signatories","Officers","Trustee","Settlor","Protector","Guarantor"];
  
  $scope.relnonindwithcustomerarray = ["BO","Trustee-Firm"]
  $scope.selecteddropdown1 = $scope.riskcodeval[1];
  $scope.riskresolution = ["Yes","NO"];
  $scope.selecteddropdown2 = $scope.riskresolution[1];
 $scope.exportInfostep7OfficerelID = "IAN1289";
$scope.exportInfostep7OfficeAddress2l = "No.10";     
$scope.exportInfostep7addressoff2l = "Kennedy Street";
$scope.addSourceofwealthl = "Export";
$scope.pinnumberl = "615489";
$scope.defaultSelectedVATexport = "Indonesia";

  $scope.accordionclick = function(){
  $scope.riskcode = "";
  $scope.resolution = "";
  $scope.resolutioncomments = "";
  $scope.relparty = "";
  $scope.pinnumberl = "";
  $scope.pinnumberl = "";
  $scope.emailidrel = "";
  $scope.Sourceofwealthl = "";
  $scope.shownonindRelatedQuesFlag4 = false;
   $scope.individualsetup = false;
   $scope.individualexport = false;
   $scope.showexportrelatedadd = false;
   $scope.showexportrelatedadd1 = false;  
  $scope.callbackflag = false;
	$scope.dedupebtnshow = false;
   $scope.showRelatedQuesFlag3 = false;
  $scope.showRelatedQuesFlag2 = false;
  $scope.showRelatedQuesFlag1 = false;
  $scope.showRelatedQuesFlag4 = false;
  $scope.showRelatedQuesFlag5 = false;
  $scope.showRelatedQuesFlag6 = false;
  $scope.riskcode = "";
  $scope.resolution = "";
  $scope.resolutioncomments = "";
  $scope.relparty = "";
  $scope.standardBForm6step6rpwithcustomer = "";
  $scope.standardBForm6step6rpname1 = "";
  $scope.standardBForm6step6rpname2 = "";
  $scope.standardBForm6step6rpname3 = "";
  $scope.standardBForm6step6rpname4 = "";
  $scope.standardBForm6steplocalname = "";
  $scope.standardBForm6step6rpname6 = "";
  $scope.standardBForm6step6rpname7 = "";
  
  
  $scope.vmCustomerApplicationInfostep7OfficeAddress2 = "";
	$scope.vmCustomerApplicationInfostep7addressoff2 = "";
	$scope.pinnumber = "";
	$scope.Sourceofwealth = "";
	$scope.IDNumber = "";
	$scope.defaultSelectedVAT = "";
	
$scope.vmCustomerApplicationInfostep7OfficeAddress2a = "";
	$scope.vmCustomerApplicationInfostep7addressoff2a = "";
	$scope.IDNumbera = "";
	$scope.Sourceofwealtha = "";	
$scope.vmCustomerApplicationInfostep7OfficeAddress2b = "";
	$scope.vmCustomerApplicationInfostep7addressoff2b = "";
	$scope.IDNumberb = "";
	$scope.Sourceofwealthb = "";		
$scope.vmCustomerApplicationInfostep7OfficeAddress2c = "";
	$scope.vmCustomerApplicationInfostep7addressoff2c = "";
	$scope.IDNumberc = "";
	$scope.Sourceofwealthc = "";	
$scope.vmCustomerApplicationInfostep7OfficeAddress2d = "";
	$scope.vmCustomerApplicationInfostep7addressoff2d = "";
	$scope.IDNumberd = "";
	$scope.Sourceofwealthd = "";	
$scope.vmCustomerApplicationInfostep7OfficeAddress2e = "";
	$scope.vmCustomerApplicationInfostep7addressoff2e = "";
	$scope.IDNumbere = "";
	$scope.Sourceofwealthe = "";	
	$scope.vmCustomerApplicationInfostep7OfficeAddress2f = "";
	$scope.vmCustomerApplicationInfostep7addressoff2f = "";
	$scope.IDNumberf = "";		
$scope.vmCustomerApplicationInfostep7OfficeAddress2g = "";
	$scope.vmCustomerApplicationInfostep7addressoff2g = "";
	$scope.IDNumberg = "";
	$scope.Sourceofwealthg = "";	
$scope.vmCustomerApplicationInfostep7OfficeAddress2h = "";
	$scope.vmCustomerApplicationInfostep7addressoff2h = "";
	$scope.IDNumberh = "";
$scope.vmCustomerApplicationInfostep7OfficeAddress2i = "";
	$scope.vmCustomerApplicationInfostep7addressoff2i = "";
	$scope.IDNumberi = "";	
$scope.vmCustomerApplicationInfostep7OfficeAddress2j = "";
	$scope.vmCustomerApplicationInfostep7addressoff2j = "";
	$scope.IDNumberj = "";
$scope.vmCustomerApplicationInfostep7OfficeAddress2k = "";
	$scope.vmCustomerApplicationInfostep7addressoff2k = "";
	$scope.IDNumberk = "";	
$scope.vmCustomerApplicationInfostep7OfficeAddress2l = "";
	$scope.vmCustomerApplicationInfostep7addressoff2l = "";
	//$scope.pinnumberl = "";
	$scope.Sourceofwealthl = "";	
	
  }
  $scope.showRelatedQues2 = function(){
  $scope.individualsetup = false;
  $scope.showrelatedMatchFlag2 = false;
	$scope.showRelatedQuesFlag2 = true; 
$scope.showRelatedQuesFlag1 = false;	
$scope.showRelatedQuesFlag3 = false;	
  }
   
  $scope.showRelatedQues3 = function(){
  $scope.individualsetup = false;
  $scope.showrelatedMatchFlag3 = false;
	$scope.showRelatedQuesFlag1 = false; 
$scope.showRelatedQuesFlag2 = false;	
$scope.showRelatedQuesFlag3 = true; 
  }
  
  $scope.showRelatedQues4 = function(){
  $scope.individualsetup = false;
  $scope.shownonrelatedMatchFlag1 = false;
	$scope.showRelatedQuesFlag6 = false; 
$scope.showRelatedQuesFlag5 = false;	
$scope.showRelatedQuesFlag4 = true; 
  }
  $scope.showRelatedQues5 = function(){
   $scope.individualsetup = false;
  $scope.shownonrelatedMatchFlag2 = false;
	$scope.showRelatedQuesFlag4 = false; 
$scope.showRelatedQuesFlag6 = false;	
$scope.showRelatedQuesFlag5 = true; 
  }
  $scope.showRelatedQues6 = function(){
   $scope.individualsetup = false;
  $scope.shownonrelatedMatchFlag3 = false;
	$scope.showRelatedQuesFlag4 = false; 
$scope.showRelatedQuesFlag5 = false;	
$scope.showRelatedQuesFlag6 = true; 
  }
  
  //$scope.selected = countryvalue.valueSelected;
		
	$scope.checkYes=function(value){
        if(value=="YES"){
            $scope.scrollTopFn('forms'); 
        }
    }
	$scope.relatedscrollTopFn = function(id) {
  debugger
    $location.hash(id);
    $anchorScroll();
  };
  var a=0;
  $scope.relatedadddetails = function(data){
  debugger
	if(a==0){
		$scope.addrelateddetails1 = true;
		a++;
		//$scope.tablevalepushdoc12 = null;
		$('#addrelatedindividual').val('');
		$scope.relatedval1 = data;
	}
	else if(a==1){
		$scope.addrelateddetails1 = true;
		$scope.addrelateddetails2 = true;
		a++;
		$scope.relatedval2 = data;
		//$scope.tablevalepushdoc12 =  null;
	}
	else if(a==2){
		$scope.addrelateddetails1 = true;
		$scope.addrelateddetails2 = true;
		$scope.addrelateddetails3 = true;
		a++;
		$scope.relatedval3 = data;
		//$scope.tablevalepushdoc12 =  null;
	}
	//$scope.tablevalepushdoc12 =  null;
	$('#addrelatedindividual').val('');
  }
  
  var b=0;
  $scope.relatedaddnondetails = function(data){
	if(b==0){
		$scope.addrelatednon1 = true;
		b++;
		$scope.nonrelatedval1 = data;
	}
	else if(b==1){
		$scope.addrelatednon1 = true;
		$scope.addrelatednon2 = true;
		b++;
		$scope.nonrelatedval2 = data;
	}
	else if(b==2){
		$scope.addrelatednon1 = true;
		$scope.addrelatednon2 = true;
		$scope.addrelatednon3 = true;
		b++;
		$scope.nonrelatedval3 = data;
	}
	//$scope.tablevalepushdoc12 = "";
	$('#addrelatednonindiv').val('');
  }
  //$scope.namescreeningtrigger={};
/*$scope.triggerclick = function(data){
debugger
$scope.namescreeningtrigger = true;
$("input[name='checkedname_ns']").each( function ($index) {
console.log("index" + $index)
$scope.namescreeningtrigger[$index]=true;
});

}	*/
$scope.namescreeningtrigger=false;
$scope.triggernameclick = function(){
	$scope.namescreeningtrigger=true;
	
}

$scope.namescreeningtrigger1=false;
$scope.triggernameclick1 = function(){
	$scope.namescreeningtrigger1=true;	
}

$scope.namescreeningtrigger2=false;
$scope.triggernameclick2 = function(){
	$scope.namescreeningtrigger2=true;	
}

$scope.namescreeningtrigger3=false;
$scope.triggernameclick3 = function(){
	$scope.namescreeningtrigger3=true;	
}

$scope.namescreeningtrigger4=false;
$scope.triggernameclick4 = function(){
	$scope.namescreeningtrigger4=true;	
}

$scope.namescreeningtrigger5=false;
$scope.triggernameclick5 = function(){
	$scope.namescreeningtrigger5=true;	
}

$scope.namescreeningtrigger6=false;
$scope.triggernameclick6 = function(){
	$scope.namescreeningtrigger6=true;	
}

$scope.namescreeningtrigger7=false;
$scope.triggernameclick7 = function(){
	$scope.namescreeningtrigger7=true;
	
}

$scope.namescreeningtrigger8=false;
$scope.triggernameclick8 = function(){
	$scope.namescreeningtrigger8=true;
	
}

$scope.namescreeningtrigger10=false;
$scope.triggernameclick10 = function(){
	$scope.namescreeningtrigger10=true;
	
}

$scope.namescreeningtrigger11=false;
$scope.triggernameclick11 = function(){
	$scope.namescreeningtrigger11=true;
	
}   

	// $scope.changeFontColor=function(MatchTerm2b_value){
	// 	alert(MatchTerm2b_value)
	// }
		$scope.beneficialFlag1 = false;
		$scope.beneficialFlag2 = false;
		$scope.beneficialFlag3 = false;
		$scope.beneficialLoadingFlag = false;
		$scope.beneficialLoadingFlag1 = false;
		$scope.beneficialLoadingFlag3 = false;
		$scope.beneficialFn1 = function(){
			$scope.beneficialLoadingFlag = true;
			$timeout(function(){
			$scope.beneficialLoadingFlag = false;	
			$scope.beneficialFlag1 = true;
			$mdDialog.show({
			  controller: ProhibitedController,
			  templateUrl: 'app/main/add-customer/views/manual/form/unwrappingRedirect.html',
			  parent: angular.element(document.body),
			  clickOutsideToClose:true
			})
			},10000);
		}
		$scope.beneficialFn2 = function(){
			$scope.beneficialLoadingFlag1 = true;
			$timeout(function(){
			$scope.beneficialLoadingFlag1 = false;	
			$scope.beneficialFlag2 = true;
			},3000);
		}
		$scope.beneficialFn3 = function(){
			$scope.beneficialLoadingFlag2 = true;
			$timeout(function(){
			$scope.beneficialLoadingFlag2 = false;	
			$scope.beneficialFlag3 = true;
			},3000);
		}
		
        
         
		$("#kitkat").show();
	
		  
	  if(localStorage.customerFlag == "manual"){
	   // $scope.CustomerApplicationInfstep3name="Nexus Bank Ltd";
	   // $scope.CustomerApplicationInfostep3aliasName="Nexus";
	   // $scope.CustomerApplicationInfostep3address1="New York";
	   // $scope.CustomerApplicationInfostep3address2="1385 Broadway, 19th Floor";
	   // $scope.CustomerApplicationInfostep3address3="New York, NY 10018";
	   // $scope.CustomerApplicationInfostep3pincodeinfo="10018";
	   // $scope.CustomerApplicationInfostep3regNumber="X290876J";
	   // $scope.CustomerApplicationInfostep4groupName="";
	   // $scope.CustomerApplicationInfostep6appId="5498726512";
	   // $scope.CustomerApplicationInfostep6appId1="5982545727";
	   // $scope.CustomerApplicationInfostep6appId2="5689512324";
	   // $scope.CustomerApplicationInfostep6appId3="5726854682";
	   // $scope.CustomerApplicationInfostep6sourcing="";
	   // $scope.vmCustomerApplicationInfostep7address="12 Oneal St #4";
	   // $scope.vmCustomerApplicationInfostep7address2="Greenville, SC 29601, USA";
       // $scope.vmCustomerApplicationInfostep7pincodeoff9="29601";
	   // $scope.cpmodel2="Henry Fielding";
	   // $scope.cpmodel3="Manager";
	   // $scope.cpmodel4="+61 2 9373 9600";
	   // $scope.vmCustomerApplicationInfostep7OfficeAddress2="3101 Hardy St";
	   // $scope.vmCustomerApplicationInfostep7addressoff2="Hattiesburg, MS 39401, USA";
	   // $scope.informationFormstep1businessName="Global Corporate";
	   // $scope.informationFormstep1TotalEmployee=1200;
	   // $scope.informationFormstep1industryName="Adobe Systems";
	   // $scope.ownershiptype = "PrivatelyOwned";
	   // $scope.entityType1 = "PrivateCompany";
	   // $scope.subentitytype = "CorrespondentBank";
	   // $scope.countryField = "Afghanistan";
	   // $scope.countryField1 = "Afghanistan";
	   // $scope.Countryofestabilishment = "Afghanistan";
	   // $scope.CustomerApplicationInfostep5Heldfield = "Afghanistan";
	   // $scope.CustomerApplicationInfostep5Heldfield1 = "AmericanSamoa";
	   // $scope.CustomerApplicationInfostep7pincode9 = "84839";
	   // $scope.remodel1 = "20K";
	   // $scope.remodel2 = "2015";
	   // $scope.remodel3 = "AED";
	   // $scope.specialisedFormstep1coresBankFlag = "yes";
	   // $scope.specialisedFormstep1leadRegulator = "John";
	   // $scope.enhancedFormstep1sourceoffunds = "Business";
	   // $scope.enhancedFormstep1sourceofwealth = "Industry";
	   // $scope.standardBForm2step2facta1 = "specified";
	   // $scope.standardBForm2step2TaxNumber = "2345678";
	   // $scope.standardBForm2step2RegNumber = "7464744";
	   // $scope.standardBForm2step2facta2 = "value1";
	   // $scope.standardBForm2step2facta3 = "value1";
	   // $scope.standardBForm2step2facta4 = "yes";
	   // $scope.standardBForm2step2facta6 = "no";
	   // $scope.standardBForm2step2facta7 = "yes";
	   // $scope.standardBForm2step2facta9 = "yes";
	   // $scope.standardBForm2step2facta10 = "no";
	   // $scope.standardBForm2step2facta11 = "yes";
	   // $scope.standardBForm4step4proValue11 = "yes";
	   // $scope.standardBForm4step4proValue12 = "yes";
	   // $scope.standardBForm4step4proValue21 = "yes";
	   // $scope.standardBForm4step4proValue22 = "yes";
	   // $scope.standardBForm4step4proValue31 = "yes";
	   // $scope.standardBForm4step4proValue32 = "yes";
	   // $scope.standardBForm4step4proValue41 = "yes";
	   // $scope.standardBForm4step4proValue42 = "yes";
	   // $scope.standardBForm4step4proValue51 = "yes";
	   // $scope.standardBForm4step4proValue52 = "yes";
	   // $scope.standardBForm4step4proValue61 = "yes";
	   // $scope.standardBForm4step4proValue62 = "yes";
	   // $scope.standardBForm4step4proValue71 = "yes";
	   // $scope.standardBForm4step4proValue72 = "yes";
	   // $scope.standardBForm4step4proValue81 = "yes";
	   // $scope.standardBForm4step4proValue82 = "yes";
	   // $scope.standardBForm4step4proValue91 = "yes";
	   // $scope.standardBForm4step4proValue92 = "yes";
	   // $scope.standardBForm4step4proValue101 = "yes";
	   // $scope.standardBForm4step4proValue102 = "yes";
	   // $scope.standardBForm4step4proValue111 = "yes";
	   // $scope.standardBForm4step4proValue112 = "yes";
	   // $scope.standardBForm4step4proValue121 = "yes";
	   // $scope.standardBForm4step4proValue122 = "yes";
	   // $scope.standardBForm4step4proValue131 = "yes";
	  
	   // $scope.standardBForm4step4proValue141 = "yes";
	   // $scope.standardBForm4step4proValue142 = "yes";
	   // $scope.standardBForm4step4proValue151 = "yes";
	   // $scope.standardBForm4step4proValue152 = "yes";
	   // $scope.informationFormstep2productRequired = "Currentaccount";
	   // $scope.informationFormstep2transactionAccount = "no";
	   // $scope.pamodel2 = "AE45N6";
	   // $scope.pamodel3 = "cheque";
	   // $scope.bamodel1 = "Business";
	   // $scope.bamodel2 = "20%";
	   // $scope.bamodel3 = "50K";
	   // $scope.bamodel4 = "30%";
	   // $scope.bamodel5 = "March";
	   // $scope.bamodel6 = "AmericanSamoa";
	   // $scope.bamodel7 = "AmericanSamoa";
	   // $scope.bamodel8 = "40%";
	   // $scope.CustomerApplicationInfostep6rmCode = "AR234D";
	   // $scope.standardBForm6step6rpname1 = "PrivatelyOwned";
	   // $scope.standardBForm6step6rpname2 = "Brother";
	   // $scope.standardBForm6step6rpname3 = "John";
	   // $scope.standardBForm6step6rpname4 = "Mathew";
	   // $scope.standardBForm6step6rpname5 = "Abraham";
	   // $scope.standardBForm6step6rpname6 = "Frank";
	   // $scope.standardBForm6step6rpname7 = "John";
	   // $scope.standardBForm6step6rpname10 = "376726";
	   // $scope.standardBForm6step6rpname11 = "PrivatelyOwned";
	   // $scope.standardBForm6step6rpname12 = "PrivateCompany";
	   // $scope.standardBForm6step6rpname13 = "CorrespondentBank";
	   // $scope.standardBForm6step6rpname14 = "Cousin";
	   // $scope.standardBForm6step6rpname15 = "John";
	   // $scope.standardBForm6step6rpname16 = "2342343";
	   // $scope.standardBForm7step7rpname1 = "Business";
	   // $scope.standardBForm7step7rpname2 = "Brother";
	   // $scope.standardBForm7step7rpname3 = "John";
	   // $scope.standardBForm7step7rpname4 = "Mathew";
	   // $scope.standardBForm7step7rpname5 = "Abraham";
	   // $scope.standardBForm7step7rpname6 = "Frank";
	   // $scope.standardBForm7step7rpname7 = "John";
	   // $scope.standardBForm7step7rpname8 = "US";
	   // $scope.standardBForm7step7rpname9 = "";
	   // $scope.standardBForm7step7rpname10 = "532544";
	   // $scope.standardBForm7step7rpname11 = "Business";
	   // $scope.standardBForm7step7rpname12 = "PrivatelyOwned";
	   // $scope.standardBForm7step7rpname13 = "PrivateCompany";
	   // $scope.standardBForm7step7rpname14 = "CorrespondentBank";
	   // $scope.standardBForm7step7rpname15 = "Cousin";
	   // $scope.standardBForm7step7rpname16 = "John";
	   // $scope.specialisedFormstep1RecognisedJurisdiction = "yes";
// $scope.specialisedFormstep1LicensedStatus = "yes";
// $scope.specialisedFormstep1nonLicensedStatus = "yes";
// $scope.specialisedFormstep1offShore = "yes";
// $scope.specialisedFormstep1totalAssets = "29-09-1995";
// $scope.specialisedFormstep1downstreamName = "yes";
// $scope.specialisedFormstep1countryReg = "yes";
// $scope.specialisedFormstep1InstitutionName = "Berklyn Pvt Ltd";
// $scope.specialisedFormstep1InstitutionLocation = "yes";
// $scope.specialisedFormstep1accountPurpose = "banking";
// $scope.specialisedFormstep1Wolfsberg1 = "no";
// $scope.specialisedFormstep1WolfsbergComment1 = "AML compliance program";
// $scope.specialisedFormstep1Wolfsberg2 = "no";
// $scope.specialisedFormstep1WolfsbergComment2 = "Regulatory compliance program";
// $scope.specialisedFormstep1Wolfsberg3 = "no";
// $scope.specialisedFormstep1WolfsbergComment3 = "Written policies documenting"; 
// $scope.specialisedFormstep1Wolfsberg4 = "no";
// $scope.specialisedFormstep1WolfsbergComment4 = "Government supervisors/regulators"; 
// $scope.specialisedFormstep1Wolfsberg5 = "no";
// $scope.specialisedFormstep1WolfsbergComment5 = "Policy prohibiting accounts"; 
// $scope.specialisedFormstep1Wolfsberg6 = "no";
// $scope.specialisedFormstep1WolfsbergComment6 = "Conduct transactions"; 
// $scope.specialisedFormstep1Wolfsberg7 = "no";
// $scope.specialisedFormstep1WolfsbergComment7 = "Covering relationships"; 
// $scope.specialisedFormstep1Wolfsberg8 = "no";
// $scope.specialisedFormstep1WolfsbergComment8 = "FI have record retention procedures"; 
// $scope.specialisedFormstep1Wolfsberg9 = "no";
// $scope.specialisedFormstep1WolfsbergComment9 = "AML policies and practices"; 
// $scope.specialisedFormstep1Wolfsberg10 = "no";
// $scope.specialisedFormstep1WolfsbergComment10 = "Risk-based assessment"; 
// $scope.specialisedFormstep1Wolfsberg11 = "no";
// $scope.specialisedFormstep1WolfsbergComment11 = "FI determine the appropriate level";
// $scope.specialisedFormstep1Wolfsberg12 = "no";
// $scope.specialisedFormstep1WolfsbergComment12 = "FI implemented processes"; 
// $scope.specialisedFormstep1Wolfsberg13 = "no";
// $scope.specialisedFormstep1WolfsbergComment13 = "customers business activities"; 
// $scope.specialisedFormstep1Wolfsberg14 = "no";
// $scope.specialisedFormstep1WolfsbergComment14 = "AML policies or practices";
// $scope.specialisedFormstep1Wolfsberg15 = "no";
// $scope.specialisedFormstep1WolfsbergComment15 = "customer information";
// $scope.specialisedFormstep1Wolfsberg16 = "no";
// $scope.specialisedFormstep1WolfsbergComment16 = "FI procedures";
// $scope.specialisedFormstep1Wolfsberg17 = "no";
// $scope.specialisedFormstep1WolfsbergComment17 = "Risk-based assessment";
// $scope.specialisedFormstep1Wolfsberg18 = "no";
// $scope.specialisedFormstep1WolfsbergComment18 = "Reportable Transactions";
// $scope.specialisedFormstep1Wolfsberg19 = "no";
// $scope.specialisedFormstep1WolfsbergComment19 = "Transactions structured";
// $scope.specialisedFormstep1Wolfsberg20 = "no";
// $scope.specialisedFormstep1WolfsbergComment20 = "FI screen customers";
// $scope.specialisedFormstep1Wolfsberg21 = "no";
// $scope.specialisedFormstep1WolfsbergComment21 = "FI have policies to reasonably";
// $scope.specialisedFormstep1Wolfsberg22 = "no";
// $scope.specialisedFormstep1WolfsbergComment22 = "Wolfsberg Transparency Principles"; 
// $scope.specialisedFormstep1Wolfsberg23 = "no";
// $scope.specialisedFormstep1WolfsbergComment23 = "Unusual and potentially suspicious activity"; 
// $scope.specialisedFormstep1Wolfsberg24 = "no";
// $scope.specialisedFormstep1WolfsbergComment24 = "Identification and reporting of transactions";
// $scope.specialisedFormstep1Wolfsberg25 = "no";
// $scope.specialisedFormstep1WolfsbergComment25 = "FI retain records of its training sessions";
// $scope.specialisedFormstep1Wolfsberg26 = "no";
// $scope.specialisedFormstep1WolfsbergComment26 = "FI communicate new AML related laws";
// $scope.specialisedFormstep1Wolfsberg27 = "no";
// $scope.specialisedFormstep1WolfsbergComment27 = "FI employ third parties";
// $scope.specialisedFormstep1Wolfsberg28 = "no";
// $scope.specialisedFormstep1WolfsbergComment28 = "Identification and reporting";
// $scope.specialisedFormstep1staffName = "Lincoln";
// $scope.specialisedFormstep1staffTitle = "Mr";
// $scope.specialisedFormstep1staffSignature = "sign";
// $scope.specialisedFormstep1staffDate = "25-06-1985";
// $scope.specialisedFormstep1corresSiteVisit = "yes";
// $scope.specialisedFormstep1AddressVisited = "Bombay";
// $scope.specialisedFormstep1metSenior = "Frank";
// $scope.specialisedFormstep1SeniorTitle = "Mr";
// $scope.specialisedFormstep1staffVisit = "Abraham";
// $scope.specialisedFormstep1staffTitle = "Mr";
// $scope.specialisedFormstep1visitObserve = "Clarified";
// $scope.specialisedFormstep1assessment = "proceed";
// $scope.specialisedFormstep1amlAssessment = "yes";


// $scope.dispensionval1 = "yes";
// $scope.dispensionval3 = "yes";
// $scope.dispensionval2 = "pending";
// $scope.dispensionval4 = "pending";
    
	}else{
	$scope.firstname = localStorage.name;
	$scope.lastname = localStorage.aliasName;
	$scope.regNumber = localStorage.regNo;
	$scope.ofcNumber = localStorage.ofcNo;	
// $timeout(function(){
	

// $scope.decisionForm2 = {
    // "step2": {
        // "firstname":localStorage.name,
        // "lastname": localStorage.aliasName,
        // "regNumber": localStorage.RegistrationNumber,
        // "ofcNumber": localStorage.OfficeContactNumber

    // }
    // }
// $scope.CustomerApplicationInfo = {
    // "step3": {
        // "name":"",
        // "aliasName": "",
        // "regNumber":"",
        // "address1": " ",
        // "address2": "",
        // "address3": "",
        // "pincodeinfo": "",
        // "SubCliententitytype": "",
        // "RiskRating": "",
        // "CountrieofDueDiligence": ""
    // },
	 // "step5": {
        // "Heldfield":"",
        // "Heldfield1": "",
        // "exchange":"",
        // "recognised": "",
        // "GovernmentOwnedfield": "",
        // "GovernmentOwnedfield1": "",
        // "pincodeinfo": "620000",
        // "SubCliententitytype": "",
        // "RiskRating": "",
        // "CountrieofDueDiligence": ""
    // },
	   // "step4": {
        // "groupName":""
// },
   // "step6": {
        // "appId":"",
        // "appId1":"",
        // "appId2":"",
        // "appId3":"",
        // "sourcing":"",
        // "csp":"Y",
        // "segment":"",
        // "rmCode":""

// },
 // "step7": {
        // "address":"",
        // "appId1":"",
        // "appId2":"",
        // "appId3":"",
        // "sourcing":"",
        // "csp":"",
        // "segment":"",
        // "rmCode":""

// }
    // }



// $scope.informationForm = {
    // "step1": {
        // "businessName":"",
        // "industryName":"",
        // "TotalEmployee":""
	// }
// }

// $scope.informationForm = {
    // "step2": {
        // "accountOpening":"",
// }
// }

// $scope.specialisedForm = {
    // "step1": {
        // "leadRegulator":"",
        // "RecognisedJurisdiction":"",
        // "nonLicensedStatus":"",
        // "field1":"",
        // "field2":"",
        // "agentProduct":"",
        // "agentPratices":"",
        // "agentConcernComment":"",
        // "principalName":"",
        // "principleEvidence":"",
        // "MSBQuestionComment1":"",
        // "MSBQuestionComment2":"",
        // "MSBQuestionComment3":"",
        // "MSBQuestionComment4":"",
        // "MSBQuestionComment5":"",
        // "MSBQuestionComment6":"",
        // "MSBQuestionComment7":"",
        // "MSBQuestionComment8":"",
        // "MSBQuestionComment9":"",
        // "MSBQuestionComment10":"",
        // "MSBQuestionComment11":"",
        // "MSBQuestionComment12":"",
        // "MSBQuestionComment13":"",
        // "MSBQuestionComment14":"",
        // "MSBQuestionComment15":"",
        // "MSBQuestionComment16":"",
        // "MSBQuestionComment17":"",
        // "MSBQuestionComment18":"",
        // "MSBQuestionComment19":"",
        // "amlQuestion":"",
        // "personMet":"",
        // "personDsg":"",
        // "AddressVisited":"",
        // "metSenior":"",
        // "SeniorTitle":"",
        // "staffTitle":"",
        // "visitObserve":"",
        // "leadRegulator1":"",
        // "RecognisedJurisdiction":"",
        // "nonLicensedStatus":"",
        // "totalAssets":"",
        // "InstitutionName":"",
        // "accountPurpose":"",
        // "WolfsbergComment1":"",
        // "WolfsbergComment2":"",
        // "WolfsbergComment3":"",
        // "WolfsbergComment4":"",
        // "WolfsbergComment5":"",
        // "WolfsbergComment6":"",
        // "WolfsbergComment7":"",
        // "WolfsbergComment8":"",
        // "WolfsbergComment9":"",
        // "WolfsbergComment10":"",
        // "WolfsbergComment11":"",
        // "WolfsbergComment12":"",
        // "WolfsbergComment13":"",
        // "WolfsbergComment14":"",
        // "WolfsbergComment15":"",
        // "WolfsbergComment16":"",
        // "WolfsbergComment17":"",
        // "WolfsbergComment18":"",
        // "WolfsbergComment19":"",
        // "WolfsbergComment20":"",
        // "WolfsbergComment21":"",
        // "WolfsbergComment22":"",
        // "WolfsbergComment24":"",
        // "WolfsbergComment25":"",
        // "WolfsbergComment26":"",
        // "WolfsbergComment27":"",
        // "WolfsbergComment28":"",
        // "staffName":"",
        // "staffTitle":"",
        // "staffSignature":"",
        // "AddressVisited":"",
        // "metSenior":"",
        // "SeniorTitle":"",
        // "staffVisit":"",
        // "staffTitle":"",
        // "visitObserve":"",
        // "leadRegulator":"",
        // "RecognisedJurisdiction":"",
        // "nonLicensedStatus":"",
        // "nonBankingComment1":"",
        // "nonBankingComment2":"",
        // "nonBankingComment3":"",
        // "nonBankingComment4":"",
        // "nonBankingComment5":"",
        // "nonBankingComment6":"",
        // "nonBankingComment7":"",
        // "nonBankingComment8":"",
        // "nonBankingComment9":"",
        // "nonBankingComment10":"",
        // "nonBankingComment11":"",
        // "nonBankingComment12":"",
        // "nonBankingComment13":"",
        // "nonBankingComment14":"",
        // "nonBankingComment15":"",
        // "nonBankingComment16":"",
        // "nonBankingComment17":"",
        // "nonBankingComment18":"",
        // "nonBankingComment19":"",
        // "personDesignation":"",
        // "AddressVisited":"",
        // "SeniorTitle":"",
        // "staffVisit":"",
        // "visitObserve":""
// }
// }

// $scope.enhancedForm = {
    // "step1": {
        // "sourceofwealth":""
// }
// }



// $scope.standardBForm2 = {
    // "step3": {
        // "others1":""
// }
// }



// $scope.standardBForm4 = {
    // "step4": {
        // "proValue11":"",
        // "proValue12":"",
        // "proValue152":"",
        // "proValue151":"",
        // "proValue142":"",
        // "proValue141":"",
        // "proValue132":"",
        // "proValue122":"",
        // "proValue121":"",
        // "proValue112":"",
        // "proValue111":"",
        // "proValue102":"",
        // "proValue101":""

// }
// }

// $scope.standardBForm2 = {
    // "step3": {
        // "others1":""
// }
// }
// },1000);
	}

	/** Unwrapping **/
$scope.validateClassFn = function(ev) {
       var greaterDataNo=0;
   $('.orgchart').find(".node").each(function(index) {
   var count = $(this).attr("class");
   var title = "node data-";
   var title1 = " focused";
   var slide = " slide";
   count = count.replace(title, "");
   count = count.replace(title1, "");
   count = count.replace(slide, "");
   if(count>greaterDataNo&&count!="node undefined firstnode"){
   greaterDataNo=count;
   }
   });
   for(var i=1;i<=greaterDataNo;i++){
   var currentinputvalue=0;
   $(".data-"+i).find("input.ioInput").each(function(index) {
   if (this.value != undefined&&this.value != ""&&this.value != " ") {
   currentinputvalue = currentinputvalue + parseInt(this.value);
   }
   });
   if(currentinputvalue<100){
   $mdDialog.show(
      $mdDialog.alert()
        .parent(angular.element(document.querySelector('#popupContainer')))
        .clickOutsideToClose(true)
        .title("Unwrapping not complete.")
        .ariaLabel('Alert Dialog Demo')
        .ok('Ok!')
        .targetEvent(ev)
    );
   return false;
   }
}
if(greaterDataNo>0){
 $mdDialog.show(
      $mdDialog.alert()
        .parent(angular.element(document.querySelector('#popupContainer')))
        .clickOutsideToClose(true)
        .title("Congratulations! You have successfully completed Unwrapping!!")
        .ariaLabel('Alert Dialog Demo')
        .ok('Ok')
        .targetEvent(ev)
    );
}

     };

$scope.resetFn = function(ev) {
    var $node = $('.orgchart').find('.node');
             if($node.length>2){
                  var confirm = $mdDialog.confirm()
          .title('Do you wish to Reset Unwrapping?')
          .ariaLabel('Lucky day')
          .targetEvent(ev)
          .ok('Ok')
          .cancel('Cancel');

    $mdDialog.show(confirm).then(function() {
      $('.orgchart').remove();
                    callChart();
    }, function() {
      return;
    });
             }
}

function checkCompletion(ev){
			var anyZero=false;
            $('.orgchart').find(".node").each(function(index) {
                    var count = $(this).attr("class");
                    var title = "node data-";
                    var title1 = " focused";
                    var slide = " slide";
                    count = count.replace(title, "");
                    count = count.replace(title1, "");
                    count = count.replace(slide, "");
                var currentNode=this;
                if(count!="node undefined firstnode"){
                if(($(this).find("input.ioInput").val().trim().length==0)){
                    anyZero=true;
                }
                }
                });
                   if(anyZero==false){
                       $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title("Congratulations! You have successfully completed Unwrapping!!")
                        .ariaLabel('Alert Dialog Demo')
                        .ok('Ok')
                        .targetEvent(ev)
                    );
                   }
                    // var greaterDataNo=0;
                    // $('.orgchart').find(".node").each(function(index) {
                    // var count = $(this).attr("class");
                    // var title = "node data-";
                    // var title1 = " focused";
                    // var slide = " slide";
                    // count = count.replace(title, "");
                    // count = count.replace(title1, "");
                    // count = count.replace(slide, "");
                    // if(count>greaterDataNo&&count!="node undefined firstnode"){
                    // greaterDataNo=count;
                    // }
                    // });
                    // for(var i=1;i<=greaterDataNo;i++){
                    // var currentinputvalue=0;
                    // $(".data-"+i).find("input.ioInput").each(function(index) {
                    // if (this.value != undefined&&this.value != ""&&this.value != " ") {
                    // currentinputvalue = currentinputvalue + parseInt(this.value);
                    // }
                    // });
                    // if(currentinputvalue<100){
                    // return false;
                    // }
                    // }
                    //  $mdDialog.show(
                    // $mdDialog.alert()
                    //     .parent(angular.element(document.querySelector('#popupContainer')))
                    //     .clickOutsideToClose(true)
                    //     .title("Congratulations! You have successfully completed Unwrapping!!")
                    //     .ariaLabel('Alert Dialog Demo')
                    //     .ok('Ok')
                    //     .targetEvent(ev)
                    // );
               }
			    setTimeout(function() {
			     callChart();
				 }, 10000);
   function callChart(){(function($) {
       $(function() {
           var datascource = {
               'name': 'Ball game'
           };
           var xVal = 10;
           var getId = function() {
               return (new Date().getTime()) * 1000 + Math.floor(Math.random() * 1001);
           };
           var oc = $('#chart-container').orgchart({
               'data': datascource,
               'createNode': function($node, data) {
                   $node[0].id = getId();
               }
           });
           $('.node').addClass("firstnode");
           setTimeout(function() {
               $('.node.firstnode').html('<div class="unwrap_con"><p class="unwrap_head">Nexus Bank Ltd</p><p class="unwrap_body">Public Ltd Company</p><p class="unwrap_share" id="getText1" contenteditable>100%</p> <img src="assets/tabIcon/Plus.png" class="redflag_cursor" alt="image" ng-click="unwrappingFn1()" /></div>')
           }, 100);
   
           oc.$chart
               .on('click', '.node', function() {
                   var $this = $(this);
                   $('#selected-node').val($this.find('.title').text()).data('node', $this);
               })
               .on('click', '.orgchart', function(event) {
                   if (!$(event.target).closest('.node').length) {
                       $('#selected-node').val('');
                   }
               });
               
               
           oc.$chart
               .on('click', '.firstnode', function() {
                    //$('.lines').css('display', 'block');
                   var $chartContainer = $('#chart-container');
                   var $this = $(this);
                   $('#selected-node').val($this.find('.title').text()).data('node', $this);
                   var $node = $this;
                   var nodeVals = [];
                   nodeVals.push("");
                   var hasChild = $node.parent().attr('colspan') > 0 ? true : false;
                   if (!hasChild) {
                       var rel = nodeVals.length > 1 ? '110' : '100';
                       oc.addChildren($node, {
                           'children': nodeVals.map(function(item) {
                               return {
                                   'name': item,
                                   'relationship': rel,
                                   'Id': getId()
                               };
                           })
                       }, $.extend({}, $chartContainer.find('.orgchart').data('options'), {
                           depth: 0
                       }), "data-1");
                   }
               });
                oc.$chart
                   .on('focus', 'select.data-list-input', function() {
                     $(this).siblings('input.data-list-input').focus();
                   });
                 
                 oc.$chart
                   .on('change', 'select.data-list-input', function() {
                     $(this).siblings('input.data-list-input').val($(this).val());
                   });
                 
                 oc.$chart
                   .on('change', 'input.data-list-input', function() {
                     $(this).siblings('select.data-list-input').val('');
                   });
   
               oc.$chart
             .on('change', '.node.focused .data-list-input', function() {
               var $node = $(this);
               if ($node.parents('.node').find('.cusName').val() != 'Gen Public' || $node.parents('.node').find('.cusName').val() != 'Privately held less than 10%' || $node.parents('.node').find('.cusName').val() != 'Govt Held') {
                       $node.parents('.node').find('.sharetype').val('')
                   }
                   if ($node.parents('.node').find('.changeType').val() == 'Gen Public' || $node.parents('.node').find('.changeType').val() == 'Privately held less than 10%' || $node.parents('.node').find('.changeType').val() == 'Govt Held') {
                       $node.parents('.node').find('.sharetype').val('N/A')
                   }
               });
			   
			   oc.$chart
               .on('click', '.node.focused input.ioInput[readonly="readonly"]', function(ev) {
				   $mdDialog.show(
							$mdDialog.alert()
								.parent(angular.element(document.querySelector('#popupContainer')))
								.clickOutsideToClose(true)
								.title("You cannot edit the entered value")
								.ariaLabel('Alert Dialog Demo')
								.ok('Ok')
								.targetEvent(ev)
							);
               });

           oc.$chart
               .on('change', '.node.focused input.ioInput', function(ev) {
					if(!($(this).val().trim().length>0&&$(this).val()>0)){
						$mdDialog.show(
							$mdDialog.alert()
								.parent(angular.element(document.querySelector('#popupContainer')))
								.clickOutsideToClose(true)
								.title("IO value cannot be zero")
								.ariaLabel('Alert Dialog Demo')
								.ok('Ok')
								.targetEvent(ev)
							);
					}
					else{
					$(this).attr('readonly', true);
                   var $chartContainer = $('#chart-container');
                   var $this = $(this);
                   var nodeVals = [];
   
                   nodeVals.push("");
                   $('#selected-node').val($this.find('.title').text()).data('node', $this);
                   var $node = $this;
                   var entityName;
                   $node.parents('.node').find('.listInput1').each(function(index) {
                   if($(this).val()!=""){
                   entityName=$(this).val();
                   $node.parents('.node').find('.cusName').val(entityName)
                   }
                   });
                   var parentEO;
                         if ($node.closest('.nodes').parent().find('tr:eq(0)').find('.eoInput').val()!= ""&&$node.closest('.nodes').parent().find('tr:eq(0)').find('.eoInput').val()!= undefined) {
                               var parentEO = $node.closest('.nodes').parent().find('tr:eq(0)').find('.eoInput').val();
                           }
                   else{
                   var parentEO=100;
                   }
                 
                           var currentEO = ($(this).parents('.node').find('.ioInput').val() * ((parentEO) / 100))
						   currentEO=Math.round(currentEO * 100) / 100
                           $node.parents('.node').find('.eoInput').val(currentEO)
                   
                   var conceptName = $node.parents('.node').find('.sharetype').find(":selected").val();
                   var nodeclassname = $node.parents('.node').attr("class");
                   var title = "node data-"
                   var title1 = " focused"
                   var slide = " slide"
                   nodeclassname = nodeclassname.replace(title, "");
                   nodeclassname = nodeclassname.replace(title1, "");
                   nodeclassname = nodeclassname.replace(slide, "");
                   var calculatedIO = 0;
                   calculatedIO=$(this).parents('.node').find('.ioInput').val();
                  $node.closest('table').parent().siblings().find('tr:eq(0)').each(function(index) { 
                       calculatedIO= parseInt(calculatedIO)+parseInt($(this).find("input.ioInput").val())
                   });
                   var nodeclassnameforchild = parseInt(nodeclassname) + 1;
                   if (calculatedIO <= 100) {
                       if (calculatedIO != 100) {
                       oc.addSiblings($node, "data-" + nodeclassname, {
                           'siblings': nodeVals.map(function(item) {
                               return {
                                   'name': item,
                                   'relationship': '110',
                                   'Id': getId()
                               };
                           })
                       });
                       }
                       if (conceptName != 'Individual' && (conceptName == 'Private Owned' || conceptName == 'Publicly Quoted' || conceptName == 'Govt Owned') && currentEO > xVal) {
                           var hasChild = $node.parent().attr('colspan') > 0 ? true : false;
                           if (!hasChild) {
                               var rel = nodeVals.length > 1 ? '110' : '100';
                               oc.addChildren($node, {
                                   'children': nodeVals.map(function(item) {
                                       return {
                                           'name': item,
                                           'relationship': rel,
                                           'Id': getId()
                                       };
                                   })
                               }, $.extend({}, $chartContainer.find('.orgchart').data('options'), {
                                   depth: 0
                               }), "data-" + nodeclassnameforchild);
                           }
                       }
   
                       calculatedIO = 10;
                   } else {
   		  $node.parents('.node').find('.ioInput').val("0");
   		  $node.parents('.node').find('.eoInput').val("0");
			 $(this).attr('readonly', false);
             $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title("Cumalative IO should not exceed 100%")
                        .ariaLabel('Alert Dialog Demo')
                        .ok('Ok')
                        .targetEvent(ev)
                    );
   		   return false;
   		  }
           checkCompletion($this);
					}
               });
   
           $('.orgchart').find('tr').removeClass('hidden').find('td').removeClass('hidden').find('.node').removeClass('slide-up slide-down slide-right slide-left');
           $('.orgchart').removeClass('view-state');
           $('#edit-panel').removeClass('view-state');
           $('input[name="chart-state"]').on('click', function() {
               $('.orgchart').toggleClass('view-state', this.value !== 'view');
               $('#edit-panel').toggleClass('view-state', this.value === 'view');
               if ($(this).val() === 'edit') {
                   $('.orgchart').find('tr').removeClass('hidden')
                       .find('td').removeClass('hidden')
                       .find('.node').removeClass('slide-up slide-down slide-right slide-left');
               } else {
                   $('#btn-reset').trigger('click');
               }
           });
           $('input[name="node-type"]').on('click', function() {
               var $this = $(this);
               if ($this.val() === 'parent') {
                   $('#edit-panel').addClass('edit-parent-node');
                   $('#new-nodelist').children(':gt(0)').remove();
               } else {
                   $('#edit-panel').removeClass('edit-parent-node');
               }
           });
       });
   })(jQuery);
   }
	/** Unwrapping **/	
		$scope.informationFormstep2accountOpening = "Correspondent Banking Services";
		$scope.CustomerApplicationInfostep6appId = "";
		
		$scope.data = {
			cb1: false,
			cb2: false,
			cb3: false
		  };
		  $scope.data1 = {
			etoggle: false,
			etoggle1: false,
			etoggle2: false,
			etoggle3: false,
			etoggle4: false,
			etoggle5: false,
			etoggle6: false,
			etoggle7: false,
			etoggle8: false,
			etoggle9: false,
			etoggle10: false,
			etoggle11: false,
			etoggle12: false,
			etoggle13: false,
			etoggle16: false,
			cb2: false,
			cb3: false
		  };
		  
		  $scope.prohibityToggleFn = function(data){
			  //alert(data);
			  if(data == "no"){
				 $mdDialog.show({
      controller: ProhibitedController,
      templateUrl: 'app/main/add-customer/views/manual/form/rejectform.html',
      parent: angular.element(document.body),
      clickOutsideToClose:true
    }) 
			  }
		  }
		  
 function ProhibitedController($scope, $mdDialog, $location) {
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  
  $scope.prohibityYesFn = function(){
	  $location.path('/dashboard');
	  $mdDialog.cancel();
  }
  
  $scope.redirectFn = function(){
	  msWizard.nextStep(6);
	  $scope.customerinfoFlag5 = 4;
	  $mdDialog.cancel();
  }
  }
  
  
  
    /* $scope.nameScreenPopFn = function(ev){
		debugger
			  alert(data);
				 $mdDialog.show({
      controller: namescreenController,
      templateUrl: 'app/main/add-customer/views/manual/form/NameScreenPopUp.html',
      parent: angular.element(document.body),
	  targetEvent: ev,
      clickOutsideToClose:true
    })
		  } */
 $scope.nameScreenPopFn = function(ev) {
    $mdDialog.show({
      controller: namescreenController,
      templateUrl: 'app/main/add-customer/views/manual/form/NameScreeningPopUp.html',
      parent: angular.element(document.body), 
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
		  
function namescreenController($scope, $mdDialog, $location, $rootScope,  $window) {
	
	 $scope.namepopUp = function () {
               $window.open("http://aml.xerago.com");
			   $rootScope.namescreeningtriggerpart =true;
			   $mdDialog.hide();
           }
		   
/* 	$scope.namepopUp = function(){   
		$rootScope.namescreeningtriggerpart =true; 
		 $mdDialog.hide();
  } */	
  
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  }; 
  } 
  
  $scope.nameScreenPopFn2 = function(ev) {
    $mdDialog.show({
      controller: namescreenController1,
      templateUrl: 'app/main/add-customer/views/manual/form/NameScreeningPopUp.html',
      parent: angular.element(document.body), 
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
  
  
 function namescreenController1($scope, $mdDialog, $location, $rootScope, $window) {
	$scope.namepopUp = function(){   
	 $window.open("http://aml.xerago.com");
			   $rootScope.namescreeningtriggerpartone =true;
			   $mdDialog.hide();
  }	
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  }; 
  }  
  
  
  $scope.nameScreenPopFn3 = function(ev) {
    $mdDialog.show({
      controller: namescreenController2,
      templateUrl: 'app/main/add-customer/views/manual/form/NameScreeningPopUp.html',
      parent: angular.element(document.body), 
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
  
  
 function namescreenController2($scope, $mdDialog, $location, $rootScope, $window) {
	$scope.namepopUp = function(){   
	 $window.open("http://aml.xerago.com");
			   $rootScope.namescreeningtriggerparttwo =true;
			   $mdDialog.hide();
  }	
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  }; 
  } 

  $scope.nameScreenPopFn4 = function(ev) {
    $mdDialog.show({
      controller: namescreenController3,
      templateUrl: 'app/main/add-customer/views/manual/form/NameScreeningPopUp.html',
      parent: angular.element(document.body), 
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
  
  
 function namescreenController3($scope, $mdDialog, $location, $rootScope, $window) {
	$scope.namepopUp = function(){   
	  $window.open("http://aml.xerago.com");
			   $rootScope.namescreeningtriggerpartthree =true;
			   $mdDialog.hide();
  }	
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  }; 
  }  
  
    $scope.nameScreenPopFn5 = function(ev) {
    $mdDialog.show({
      controller: namescreenController4,
      templateUrl: 'app/main/add-customer/views/manual/form/NameScreeningPopUp.html',
      parent: angular.element(document.body), 
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
  
  
 function namescreenController4($scope, $mdDialog, $location, $rootScope, $window) {
	$scope.namepopUp = function(){   
	 $window.open("http://aml.xerago.com");
			   $rootScope.namescreeningtriggerpartfour =true;
			   $mdDialog.hide();
  }	
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  }; 
  }
  
      $scope.nameScreenPopFn6 = function(ev) {
    $mdDialog.show({
      controller: namescreenController5,
      templateUrl: 'app/main/add-customer/views/manual/form/NameScreeningPopUp.html',
      parent: angular.element(document.body), 
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
  
  
 function namescreenController5($scope, $mdDialog, $location, $rootScope, $window) {
	$scope.namepopUp = function(){   
	  $window.open("http://aml.xerago.com");
			   $rootScope.namescreeningtriggerpartfive =true;
			   $mdDialog.hide();
  }	
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  }; 
  }
  
  
  
      $scope.nameScreenPopFn7 = function(ev) {
    $mdDialog.show({
      controller: namescreenController6,
      templateUrl: 'app/main/add-customer/views/manual/form/NameScreeningPopUp.html',
      parent: angular.element(document.body), 
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
  
  
 function namescreenController6($scope, $mdDialog, $location, $rootScope, $window) {
	$scope.namepopUp = function(){   
	    $window.open("http://aml.xerago.com");
		$rootScope.namescreeningtriggerpartsix =true; 
		 $mdDialog.hide();
  }	
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  }; 
  }
  
  
      $scope.nameScreenPopFn8 = function(ev) {
    $mdDialog.show({
      controller: namescreenController7,
      templateUrl: 'app/main/add-customer/views/manual/form/NameScreeningPopUp.html',
      parent: angular.element(document.body), 
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
  
  
 function namescreenController7($scope, $mdDialog, $location, $rootScope, $window) {
	$scope.namepopUp = function(){   
	    $window.open("http://aml.xerago.com");
		$rootScope.namescreeningtriggerpartseven =true; 
		 $mdDialog.hide();
  }	
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  }; 
  }	 
  
  
      $scope.nameScreenPopFn9 = function(ev) {
    $mdDialog.show({
      controller: namescreenController8,
      templateUrl: 'app/main/add-customer/views/manual/form/NameScreeningPopUp.html',
      parent: angular.element(document.body), 
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
  
  
 function namescreenController8($scope, $mdDialog, $location, $rootScope, $window) {
	$scope.namepopUp = function(){   
	   $window.open("http://aml.xerago.com");
		$rootScope.namescreeningtriggerparteight =true; 
		 $mdDialog.hide();
  }	
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  }; 
  }	  
  
   $scope.nameScreenPopFn10 = function(ev) {
    $mdDialog.show({
      controller: namescreenController9,
      templateUrl: 'app/main/add-customer/views/manual/form/NameScreeningPopUp.html',
      parent: angular.element(document.body), 
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
  
  
 function namescreenController9($scope, $mdDialog, $location, $rootScope, $window) {
	$scope.namepopUp = function(){   
	    $window.open("http://aml.xerago.com");
		$rootScope.namescreeningtriggerpartnine =true; 
		 $mdDialog.hide();
  }	
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  }; 
  }	  
  
     $scope.nameScreenPopFn11 = function(ev) {
    $mdDialog.show({
      controller: namescreenController10,
      templateUrl: 'app/main/add-customer/views/manual/form/NameScreeningPopUp.html',
      parent: angular.element(document.body), 
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
  
  
 function namescreenController10($scope, $mdDialog, $location, $rootScope, $window) {
	$scope.namepopUp = function(){   
	    $window.open("http://aml.xerago.com");
		$rootScope.namescreeningtriggerpartten =true; 
		 $mdDialog.hide();
  }	
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  }; 
  }	
  
    $scope.nameScreenPopFn12 = function(ev) {
    $mdDialog.show({
      controller: namescreenController11,
      templateUrl: 'app/main/add-customer/views/manual/form/NameScreeningPopUp.html',
      parent: angular.element(document.body), 
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
  
  
 function namescreenController11($scope, $mdDialog, $location, $rootScope, $window) {
	$scope.namepopUp = function(){   
	    $window.open("http://aml.xerago.com");
		$rootScope.namescreeningtriggerparteleven =true; 
		 $mdDialog.hide();
  }	
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  }; 
  }	
  
  
  
		
		
		$scope.items_country = [{id: 1, name: 'country'}];
		
		$scope.addItem = function(){
			$scope.items_country.push({id: $scope.items_country.length+1, name: 'country'});
		};
		
		$scope.deleteItem = function(i){
			$scope.items_country.splice(i, 1);
		};
		
		$scope.financialList = [];
		
		$scope.financialConFn = function(){
			$scope.financialList.push({id: $scope.financialList.length+1, field1: 'financial'+$scope.financialList.length+1, field2: 'location'+$scope.financialList.length+1, field3: 'purpose'+$scope.financialList.length+1});
		};
		
		$scope.financialConFn();
		
		$scope.primaryBookingAry1 = [];
		
		$scope.primaryBooking1 = function(){
			$scope.primaryBookingAry1.push({id: $scope.primaryBookingAry1.length+1, name: 'country'+$scope.primaryBookingAry1.length+1});
		};
		
		$scope.primaryBooking1();
		
		$scope.primaryBookingAry2 = [];
		
		$scope.primaryBooking2 = function(){
			if($scope.primaryBookingAry2.length == 10){
				return false;
			}
			$scope.primaryBookingAry2.push({id: $scope.primaryBookingAry2.length+1, name: 'country'+$scope.primaryBookingAry2.length+1});
		};
		$scope.deleteprimaryBooking2 = function(i){
				$scope.primaryBookingAry2.splice(i, 1);
		}
		
		$scope.primaryBooking2();
		
		
		$scope.countryAry = [{id: 1, name: 'country'}];
		
		$scope.addItem1 = function(){
			$scope.countryAry.push({id: $scope.countryAry.length+1, name: 'country'});
		};
		
		$scope.deleteItem1 = function(i){
			$scope.countryAry.splice(i, 1);
		};
		
		$scope.businessAry = [{id: 1, name: ''}];
		
		$scope.addBusiness = function(){
		/* $scope.countrydetails=true; */
			if($scope.businessAry.length == 10){
				return false;
			}
			$scope.businessAry.push({id: $scope.businessAry.length+1, name: ''});
		};
		
		$scope.removeinformation = function(i){
			$scope.businessAry.splice(i, 1);
		};
		$scope.deleteBusiness = function(i){
			$scope.businessAry.splice(i, 1);
		};
		
		$scope.contactPerson = [];
		
		
		$scope.addPerson = function(){
		if($scope.contactPerson.length == 5){
		return false;	
		}
			$scope.contactPerson.push({id: $scope.contactPerson.length + 1, name1 : "contact"+$scope.contactPerson.length + 1, name2 : "name"+$scope.contactPerson.length + 1, name3 : "designation"+$scope.contactPerson.length + 1, name4 : "phone"+$scope.contactPerson.length + 1, model1 : "", model2 : "", model3: "", model4 : ""});
		}
		$scope.addPerson();
		$scope.deletePerson = function(i){
			$scope.contactPerson.splice(i, 1);
		};
		
		
		$scope.revenueAry = [];
		
		$scope.addRevenue = function(){
			$scope.revenueAry.push({id: $scope.revenueAry.length+1, name1 : "annual"+$scope.revenueAry.length+1, name2 : "year"+$scope.revenueAry.length+1, name3 : "currency"+$scope.revenueAry.length+1, model1: "", model2: "", model3: ""});
		}
		$scope.addRevenue();
		$scope.deleteRevenue = function(i){
			$scope.revenueAry.splice(i, 1);
		};
	var vm = this;
	
$scope.nameclick = function(){
     //alert(123);
};
$scope.adversefn = function(){
$scope.adversemediasec = true;
}
$scope.adversefn1 = function(){
$scope.adversemediasec1 = true;
}
$scope.adversefn2 = function(){
$scope.adversemediasec2 = true;
}
$scope.adversefn3 = function(){
$scope.adversemediasec3 = true;
}
$scope.adversefn4 = function(){
$scope.adversemediasec4 = true;
}
	
	
vm.timeline = Timeline.data;
$scope.expectedanalyticsFlag = false;
$scope.Expectedanalytics = function(){
    $scope.expectedanalyticsFlag = true;
}

$scope.docIcon = function(){
    $("#fileUpload").trigger('click');
}

$scope.attacheddoc = function(){
    $("#fileUpload").trigger('click');
}

$scope.attacheddoc1 = function(){
    $("#fileUpload").trigger('click');
}

$scope.attacheddoc2 = function(){
    $("#fileUpload").trigger('click');
}

$scope.attacheddoc3 = function(){
    $("#fileUpload").trigger('click');
}

$scope.attacheddoc4 = function(){
    $("#fileUpload").trigger('click');
}

$scope.attacheddoc5 = function(){
    $("#fileUpload").trigger('click');
}

$scope.attacheddoc6 = function(){
    $("#fileUpload").trigger('click');
}

$scope.attacheddoc7 = function(){
    $("#fileUpload").trigger('click');
}

$scope.attacheddoc8 = function(){
    $("#fileUpload").trigger('click');
}

$scope.attacheddoc9 = function(){
    $("#fileUpload").trigger('click');
}

$scope.attacheddoc10 = function(){
    $("#fileUpload").trigger('click');
}

$scope.attacheddoc11 = function(){
    $("#fileUpload").trigger('click');
}

$scope.fileChose = function(){
    $(".flie_chosse").css('display','block');
}
 
	
	$scope.potentialList = function(data){
	if(data == 1){
	vm.potentials = Potential.data;	
	}else if(data == 2){
	vm.potentials = Potential2.data;	
	}else if(data == 3){
	vm.potentials = Potential3.data;	
	}
	}
	
	
	// vm.potentials = Potential1.data;
	// $scope.showPercentageFlag = false;
	// $scope.showPotentialMatchFlag1 = false;
	// $scope.potentialTableFn = function(){
		// vm.potentials = Potential.data;
		// $scope.showPercentageFlag = true;
		// $scope.showPotentialMatchFlag1 = true;
	// }
	vm.potentials = Potential1.data;
$scope.showPercentageFlag = false;
$scope.showPotentialMatchFlag = true;
$scope.showPotentialMatchFlag1 = false;
$scope.customerdedupeform = true;
$scope.showDedupeConFlag1 = false;
$scope.showDedupeConFlag2 = false;
$("#dedupe_popup").hide();
$scope.RequiredalertFlag = false;
$scope.PotentialalertFlag = false;
$scope.potentialTableFn = function(data){
	//debugger;
// if(data == "undefined" || data.customerName == "" || data.customerAliasName == "" || data.customerRegNo == "" || data.customerOfcNo == "" || data.customerName == "undefined" || data.customerAliasName == "undefined" || data.customerRegNo == "undefined" || data.customerOfcNo == "undefined"){
	// alert("Please enter the required fields");
	// return false;
// }

/* if(data == undefined || data.customerName == "" || data.customerAliasName == "" || data.customerRegNo == "" || data.customerOfcNo == "" || data.customerName == undefined || data.customerAliasName == undefined || data.customerRegNo == undefined || data.customerOfcNo == undefined){
	$scope.PotentialalertFlag = false;
	$scope.RequiredalertFlag = true;
	return false;
} */

/* if(data.customerName != "nexus bank" || data.customerAliasName != "nexas" || data.customerRegNo != "X7671" || data.customerOfcNo == "01123149892"){
$scope.RequiredalertFlag = false;
$scope.PotentialalertFlag = true;
	return false;

} */

if(data == undefined || data.customerName == "" || data.customerName == undefined){
	$scope.PotentialalertFlag = false;
	$scope.RequiredalertFlag = true;
	$scope.showPotentialMatchFlag1 = false;
	return false;
}
if(data.customerName != "nexus bank" && data.customerName != "china bank"){
$scope.RequiredalertFlag = false;
$scope.PotentialalertFlag = true;
$scope.showPotentialMatchFlag1 = false;
	return false;
} 
if(data.customerName == "china bank"){

$scope.PotentialalertFlag = false;
}

if(data.customerName == "nexus bank" || data.customerAliasName == "nexas" || data.customerRegNo == "X7671" || data.customerOfcNo == "01123149892" ){
$scope.dedupepopup();
$scope.PotentialalertFlag = false;
$scope.RequiredalertFlag = false;
	$scope.showDedupeConFlag1 = true;
$scope.showDedupeConFlag2 = false;
	
/* $scope.customerdedupeform = false; */
$scope.showPotentialMatchFlag = false;
/* $("#showLoader").show(); */
vm.potentials = Potential.data;
$scope.showPercentageFlag = true;
$scope.showPotentialMatchFlag1 = false;
$timeout(function(){
 $mdDialog.hide();
$("#showLoader").hide();            
$("#dedupe_popup").hide(); 
$scope.showPotentialMatchFlag1 = true;
},100);	
} else if(data.customerName == "china bank" || data.customerAliasName == "china" || data.customerRegNo == "X7654" || data.customerOfcNo == "01175532345" ){
$scope.dedupepopup();
	$scope.showDedupeConFlag1 = false;
$scope.showDedupeConFlag2 = true;
$scope.showPotentialMatchFlag = false;
$("#showLoader").show();
vm.potentials = Potential.data;
$scope.showPercentageFlag = true;
$scope.showPotentialMatchFlag1 = false;$scope.dedupepopup();
$scope.PotentialalertFlag = false;
$scope.RequiredalertFlag = false;
	$scope.showDedupeConFlag1 = true;
$scope.showDedupeConFlag2 = false;
	
/* $scope.customerdedupeform = false; */
$scope.showPotentialMatchFlag = false;
/* $("#showLoader").show(); */
vm.potentials = Potential.data;
$scope.showPercentageFlag = true;
$scope.showPotentialMatchFlag1 = false;
$timeout(function(){
 $mdDialog.hide();
$("#showLoader").hide();            
$("#dedupe_popup").hide(); 
$scope.showPotentialMatchFlag1 = true;
},10000);
$timeout(function(){
$mdDialog.hide();
$("#showLoader").hide();
$("#dedupe_popup").hide(); 
$scope.showPotentialMatchFlag1 = true;
},10000);
}


}

	$scope.checkboxval= [];
$scope.checkboxfn = function(data){
	debugger;
	$scope.checkboxval[data]= true;
}
$scope.checkboxval1= [];
$scope.checkboxfn1 = function(data){
	$scope.checkboxval1[data]= true;
}
$scope.checkboxval2= [];
$scope.checkboxfn2 = function(data){
	$scope.checkboxval2[data]= true;
}
$scope.checkboxval3= [];
$scope.checkboxfn3 = function(data){
	$scope.checkboxval3[data]= true;
}
$scope.checkboxval4= [];
$scope.checkboxfn4 = function(data){
	$scope.checkboxval4[data]= true;
}
$scope.checkboxval5= [];
$scope.checkboxfn5 = function(data){
	$scope.checkboxval5[data]= true;
}
$scope.checkboxval6= [];
$scope.checkboxfn6 = function(data){
	$scope.checkboxval6[data]= true;
}
$scope.checkboxval7= [];
$scope.checkboxfn7 = function(data){
	$scope.checkboxval7[data]= true;
}
$scope.checkboxval8= [];
$scope.checkboxfn8 = function(data){
	$scope.checkboxval8[data]= true;
}
$scope.checkboxval9= [];
$scope.checkboxfn9 = function(data){
	$scope.checkboxval9[data]= true;
}
$scope.checkboxval10= [];
$scope.checkboxfn10 = function(data){
	$scope.checkboxval10[data]= true;
}
$scope.checkboxval11= [];
$scope.checkboxfn11 = function(data){
	$scope.checkboxval11[data]= true;
}

$scope.idvdocconfigFlag = 13; 

$scope.fnidvconfiq = function(data){
$scope.idvdocconfigFlag = data; 
}

$scope.relatedTableFn = function(data){
$scope.dedupepopup();
$scope.showDedupeConFlag1 = true;
$scope.showrelatedMatchFlag1 = false;
$scope.shownonrelatedMatchFlag1 = false;
$scope.showDedupeConFlag2 = false;
$scope.showPotentialMatchFlag = false;
vm.potentials = Potential.data;
$scope.showPercentageFlag = true;
$scope.showPotentialMatchFlag1 = false;
$timeout(function(){
 $mdDialog.hide();
$("#showLoader").hide();            
$("#dedupe_popup").hide(); 
$scope.showrelatedMatchFlag1 = true;
$scope.showPotentialMatchFlag1 = true;
$scope.showrelatedMatchFlag3 = false;
$scope.showrelatedMatchFlag2 = false;
$scope.dedupebtnshow = true;
},10000);
}

$scope.relatedTableaddFn = function(data){
$scope.dedupepopup();
$scope.showDedupeConFlag1 = true;
$scope.shownewrelatedMatchFlag3 = false;
$scope.shownonrelatedMatchFlag1 = false;
$scope.showDedupeConFlag2 = false;
$scope.showPotentialMatchFlag = false;
vm.potentials = Potential.data;
$scope.showPercentageFlag = true;
$scope.showPotentialMatchFlag1 = false;
showaaddrelatedMatchFlag3 = true;
$timeout(function(){
 $mdDialog.hide();
$("#showLoader").hide();            
$("#dedupe_popup").hide(); 
$scope.shownewrelatedMatchFlag3 = true;

$scope.dedupebtnshow = true;
},10000);
}
$scope.relatedTableFn1 = function(data){
$scope.dedupepopup();
$scope.showDedupeConFlag1 = true;
$scope.showrelatedMatchFlag1 = false;
$scope.shownonrelatedMatchFlag1 = false;
$scope.showDedupeConFlag2 = false;
$scope.showPotentialMatchFlag = false;
vm.potentials = Potential.data;
$scope.showPercentageFlag = true;
$scope.showPotentialMatchFlag1 = false;
$timeout(function(){
 $mdDialog.hide();
$("#showLoader").hide();            
$("#dedupe_popup").hide(); 
$scope.showrelatedMatchFlag1 = true;
$scope.showPotentialMatchFlag2 = true;
$scope.showrelatedMatchFlag3 = false;
$scope.showrelatedMatchFlag1 = false;
$scope.dedupebtnshow = true;
},10000);
}
$scope.relatedTableFn2 = function(data){
$scope.dedupepopup();
$scope.showDedupeConFlag1 = true;
$scope.showrelatedMatchFlag1 = false;
$scope.shownonrelatedMatchFlag1 = false;
$scope.showDedupeConFlag2 = false;
$scope.showPotentialMatchFlag = false;
vm.potentials = Potential.data;
$scope.showPercentageFlag = true;
$scope.showPotentialMatchFlag1 = false;
$timeout(function(){
 $mdDialog.hide();
$("#showLoader").hide();            
$("#dedupe_popup").hide(); 
$scope.showrelatedMatchFlag1 = true;
$scope.showPotentialMatchFlag1 = true;
$scope.showrelatedMatchFlag3 = false;
$scope.showrelatedMatchFlag1 = false;
$scope.showrelatedMatchFlag2 = true;
$scope.dedupebtnshow = true;
},10000);
}
$scope.showrelatedMatchFlag3 = false;
$scope.relatedTableFn3 = function(data){
$scope.dedupepopup();
$scope.showDedupeConFlag1 = true;
$scope.showrelatedMatchFlag1 = false;
$scope.shownonrelatedMatchFlag1 = false;
$scope.showDedupeConFlag2 = false;
$scope.showPotentialMatchFlag = false;
vm.potentials = Potential.data;
$scope.showPercentageFlag = true;
$scope.showPotentialMatchFlag1 = false;
$timeout(function(){
 $mdDialog.hide();
$("#showLoader").hide();            
$("#dedupe_popup").hide(); 
$scope.showrelatedMatchFlag1 = false;
$scope.showrelatedMatchFlag2 = false;
$scope.showrelatedMatchFlag3 = true;
$scope.showPotentialMatchFlag3 = true;
$scope.dedupebtnshow = true;
},10000);
}
$scope.doccongignoninfdarray = [{name:"Company Registry Search",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Partnership Deed",value1:"Yes",value2:"Yes",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Business Reg Certificate",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Certified copy of Trust deed",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Charity Registration document",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"}];
 
  $scope.documentaddflag1 = false;
  $scope.documentadd = [];
  $scope.table1val = function(data){
	   if(data.length != 0){
  debugger
	$scope.documentadd.push({id:$scope.documentadd.length + 1,name:data})
	$scope.tablevalepush = ""; 
	$scope.documentaddflag1 = true;
	
  }
  }  

  $scope.doccongignoninfdarray1 = [{name:"Company Registry Search",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Partnership Deed",value1:"Yes",value2:"Yes",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Business Reg Certificate",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Certified copy of Trust deed",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Charity Registration document",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"}];
  $scope.documentaddflag2 = false;
  $scope.addcustomerdoc2 = [];
  $scope.table1val32 = function(data){ 
   if(data.length != 0){
  debugger
	$scope.addcustomerdoc2.push({id:$scope.addcustomerdoc2.length + 1,name:data})
	$scope.tablevalepush1 ="";
	$scope.documentaddflag2 = true;
  }
  }
  
  
    $scope.doccongignoninfdarray2 = [{name:"Company Registry Search",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Partnership Deed",value1:"Yes",value2:"Yes",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Business Reg Certificate",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Certified copy of Trust deed",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Charity Registration document",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"}];
  $scope.documentaddflag33 = false;
  $scope.addcustomerdoc33 = [];
  $scope.table1val33 = function(data){ 
   if(data.length != 0){
  debugger
	$scope.addcustomerdoc33.push({id:$scope.addcustomerdoc33.length + 1,name:data})
	$scope.tablevalepush25 ="";
	$scope.documentaddflag33 = true;
  }
  }
  
    $scope.doccongignoninfdarray3 = [{name:"Company Registry Search",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Partnership Deed",value1:"Yes",value2:"Yes",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Business Reg Certificate",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Certified copy of Trust deed",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Charity Registration document",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"}];
  $scope.documentaddflag44 = false;
  $scope.addcustomerdoc44 = [];
  $scope.table1val34 = function(data){
 if(data.length != 0){	  
  debugger
	$scope.addcustomerdoc44.push({id:$scope.addcustomerdoc44.length + 1,name:data})
	$scope.tablevalepush26 ="";
	$scope.documentaddflag44 = true;
  }
  }  

  
 $scope.tablestep16array_a = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}]; 
   $scope.documentaddflag3 = false;
  $scope.addcustomerdoc3 = [];
  $scope.table1val35 = function(data){ 
   if(data.length != 0){
  debugger
	$scope.addcustomerdoc3.push({id:$scope.addcustomerdoc3.length + 1,name:data})
	$scope.tablevalepush35 ="";
	$scope.documentaddflag3 = true;
  } 
  }
  
   $scope.tablestep16array_a1 = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}]; 
   $scope.documentaddflag3a = false;
  $scope.addcustomerdoc3a = [];
  $scope.table1val35a = function(data){
 if(data.length != 0){	  
  debugger
	$scope.addcustomerdoc3a.push({id:$scope.addcustomerdoc3a.length + 1,name:data})
	$scope.tablevalepush35a ="";
	$scope.documentaddflag3a = true;
  } 
  }
  
 $scope.tablestep16array_a2 = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}]; 
   $scope.documentaddflag3b = false;
  $scope.addcustomerdoc3b = [];
  $scope.table1val35b = function(data){ 
   if(data.length != 0){
  debugger
	$scope.addcustomerdoc3b.push({id:$scope.addcustomerdoc3b.length + 1,name:data})
	$scope.tablevalepush35b ="";
	$scope.documentaddflag3b = true;
  } 
  }  

 
  $scope.tablestep16array_b = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
     $scope.documentaddflag4b = false;
  $scope.addcustomerdoc4b = [];
  $scope.table1val36 = function(data){
 if(data.length != 0){	  
  debugger
	$scope.addcustomerdoc4b.push({id:$scope.addcustomerdoc4b.length + 1,name:data})
	$scope.tablevalepush36 ="";
	$scope.documentaddflag4b = true;
  }   
  }

  
    $scope.tablestep16array_b2 = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
     $scope.documentaddflag4c = false;
  $scope.addcustomerdoc4c = [];
  $scope.table1val36a = function(data){ 
   if(data.length != 0){
  debugger
	$scope.addcustomerdoc4c.push({id:$scope.addcustomerdoc4c.length + 1,name:data})
	$scope.tablevalepush36a ="";
	$scope.documentaddflag4c = true;
  } 
  }
  
  
   $scope.tablestep16array_c = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
      $scope.documentaddflag5 = false;
		$scope.addcustomerdoc5 = [];
		$scope.table1val37 = function(data){ 
		 if(data.length != 0){
		debugger
		$scope.addcustomerdoc5.push({id:$scope.addcustomerdoc5.length + 1,name:data})
		$scope.tablevalepush37 ="";
		$scope.documentaddflag5 = true;
	} 
		}
	  
   $scope.tablestep16array_c1 = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
      $scope.documentaddflag5a = false;
		$scope.addcustomerdoc5a = [];
		$scope.table1val37a = function(data){
		if(data.length != 0){			
		debugger
		$scope.addcustomerdoc5a.push({id:$scope.addcustomerdoc5a.length + 1,name:data})
		$scope.tablevalepush37a ="";
		$scope.documentaddflag5a = true;
	} 
		}
	
     $scope.tablestep16array_d = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
	       $scope.documentaddflag6 = false;
		$scope.addcustomerdoc6 = [];
		$scope.table1val38 = function(data){
		if(data.length != 0){			
		debugger
		$scope.addcustomerdoc6.push({id:$scope.addcustomerdoc6.length + 1,name:data})
		$scope.tablevalepush38 ="";
		$scope.documentaddflag6 = true;
	}
		}
	
	     $scope.tablestep16array_d1 = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
	       $scope.documentaddflag6a = false;
		$scope.addcustomerdoc6a = [];
		$scope.table1val38a = function(data){ 
		 if(data.length != 0){
		debugger
		$scope.addcustomerdoc6a.push({id:$scope.addcustomerdoc6a.length + 1,name:data})
		$scope.tablevalepush38a ="";
		$scope.documentaddflag6a = true;
	}
		}
	 
	 $scope.tablestep16array_e = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
	 	       $scope.documentaddflag7 = false;
		$scope.addcustomerdoc7 = [];
		$scope.table1val39 = function(data){ 
		 if(data.length != 0){
		debugger
		$scope.addcustomerdoc7.push({id:$scope.addcustomerdoc7.length + 1,name:data})
		$scope.tablevalepush39 ="";
		$scope.documentaddflag7 = true;
	}
		}
	
		 $scope.tablestep16array_e1 = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
	 	       $scope.documentaddflag7a = false;
		$scope.addcustomerdoc7a = [];
		$scope.table1val39a = function(data){
		if(data.length != 0){			
		debugger
		$scope.addcustomerdoc7a.push({id:$scope.addcustomerdoc7a.length + 1,name:data})
		$scope.tablevalepush39a ="";
		$scope.documentaddflag7a = true;
	}
		}
	 
	 $scope.tablestep16array_f = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
	  	       $scope.documentaddflag8 = false;
		$scope.addcustomerdoc8 = [];
		$scope.table1val40= function(data){ 
		 if(data.length != 0){
		debugger
		$scope.addcustomerdoc8.push({id:$scope.addcustomerdoc8.length + 1,name:data})
		$scope.tablevalepush40 ="";
		$scope.documentaddflag8 = true;
	}
		}
	
	 $scope.tablestep16array_f1 = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
	  	       $scope.documentaddflag8a = false;
		$scope.addcustomerdoc8a = [];
		$scope.table1val40a= function(data){ 
		 if(data.length != 0){
		debugger
		$scope.addcustomerdoc8a.push({id:$scope.addcustomerdoc8a.length + 1,name:data})
		$scope.tablevalepush40a ="";
		$scope.documentaddflag8a = true;
	}
		}
	
	$scope.doccongignoninfdarray_12 = [{name:"Company Registry Search",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Partnership Deed",value1:"Yes",value2:"Yes",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Business Reg Certificate",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Certified copy of Trust deed",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Charity Registration document",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"}];
  $scope.documentaddflag9 = false;
  $scope.addcustomerdoc9 = [];
  $scope.table1val41 = function(data){
	   if(data.length != 0){
  debugger
	$scope.addcustomerdoc9.push({id:$scope.addcustomerdoc9.length + 1,name:data})
	$scope.tablevalepush41 ="";
	$scope.documentaddflag9 = true;
  }
  }
  
  	$scope.doccongignoninfdarray_12a = [{name:"Company Registry Search",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Partnership Deed",value1:"Yes",value2:"Yes",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Business Reg Certificate",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Certified copy of Trust deed",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"},{name:"Charity Registration document",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes"}];
  $scope.documentaddflag9a = false;
  $scope.addcustomerdoc9a = [];
  $scope.table1val41a = function(data){
	   if(data.length != 0){
  debugger
	$scope.addcustomerdoc9a.push({id:$scope.addcustomerdoc9a.length + 1,name:data})
	$scope.tablevalepush41a ="";
	$scope.documentaddflag9a = true;
  }
  }
	 
	 $scope.tablestep16array_g = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
	 $scope.documentaddflag10 = false;
	  $scope.addcustomerdoc10 = [];
	  $scope.table1val42 = function(data){
		   if(data.length != 0){
	  debugger
		$scope.addcustomerdoc10.push({id:$scope.addcustomerdoc10.length + 1,name:data})
		$scope.tablevalepush42 ="";
		$scope.documentaddflag10 = true;
  }
	  }
 	 
	 $scope.tablestep16array_g1 = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
	 $scope.documentaddflag10a = false;
	  $scope.addcustomerdoc10a = [];
	  $scope.table1val42a = function(data){
		   if(data.length != 0){
	  debugger
		$scope.addcustomerdoc10a.push({id:$scope.addcustomerdoc10a.length + 1,name:data})
		$scope.tablevalepush42a ="";
		$scope.documentaddflag10a = true;
  } 
	  }
		  
	 $scope.tablestep16array_h = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
	  $scope.documentaddflag11 = false;
	  $scope.addcustomerdoc11 = [];
	  $scope.table1val43 = function(data){
		   if(data.length != 0){
	  debugger
		$scope.addcustomerdoc11.push({id:$scope.addcustomerdoc11.length + 1,name:data})
		$scope.tablevalepush43 ="";
		$scope.documentaddflag11 = true;
  }
	  }
  		  
	 $scope.tablestep16array_h1 = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
	  $scope.documentaddflag11a = false;
	  $scope.addcustomerdoc11a = [];
	  $scope.table1val43a = function(data){
		   if(data.length != 0){
	  debugger
		$scope.addcustomerdoc11a.push({id:$scope.addcustomerdoc11a.length + 1,name:data})
		$scope.tablevalepush43a ="";
		$scope.documentaddflag11a = true;
  }
	  }

	 $scope.tablestep16array_i = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
	 
	 	  $scope.documentaddflag12 = false;
	  $scope.addcustomerdoc12 = [];
	  $scope.table1val44 = function(data){
		   if(data.length != 0){
	  debugger
		$scope.addcustomerdoc12.push({id:$scope.addcustomerdoc12.length + 1,name:data})
		$scope.tablevalepush44 ="";
		$scope.documentaddflag12 = true;
  }
	  }
  
  	 $scope.tablestep16array_i1 = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes",value4:"Yes",value5:"No",value6:"Yes",value7:"Yes"}];
	 	  $scope.documentaddflag12a = false;
	  $scope.addcustomerdoc12a = [];
	  $scope.table1val44a = function(data){
		  if(data.length != 0){
	  debugger
		$scope.addcustomerdoc12a.push({id:$scope.addcustomerdoc12a.length + 1,name:data})
		$scope.tablevalepush44a ="";
		$scope.documentaddflag12a = true;
  }
	  }
	 
$scope.tablestep16array = [{name:"Passport",value1:"Yes",value2:"No",value3:"Yes"},{name:"Driving Licence",value1:"Yes",value2:"Yes",value3:"Yes"},{name:"National ID Card",value1:"Yes",value2:"No",value3:"Yes"},{name:"Electronic Data source",value1:"Yes",value2:"No",value3:"Yes"},{name:"Publicly available docs",value1:"Yes",value2:"No",value3:"Yes"}];  
$scope.addcustomerdoc1 = [];      
$scope.addcustomerdoc2 = [];
$scope.addcustomerdoc3 = [];
$scope.addcustomerdoc4 = [];
$scope.addcustomerdoc5 = [];
$scope.addcustomerdoc6 = [];
$scope.addcustomerdoc7 = [];
$scope.addcustomerdoc8 = [];
$scope.addcustomerdoc9 = [];
$scope.addcustomerdoc10 = [];
$scope.addcustomerdoc11 = [];
$scope.addcustomerdoc12 = [];
  $scope.table1val1 = function(data){
  debugger
	$scope.tablestep16array.push({id:$scope.tablestep16array.length + 1,name:data})
	$scope.tablestep16array.push({id:$scope.tablestep16array_a.length + 1,name:data})
	$scope.tablestep16array.push({id:$scope.tablestep16array_b.length + 1,name:data})
	$scope.tablestep16array.push({id:$scope.tablestep16array_c.length + 1,name:data})
	$scope.tablestep16array.push({id:$scope.tablestep16array_d.length + 1,name:data})
	$scope.tablestep16array.push({id:$scope.tablestep16array_e.length + 1,name:data})
	$scope.tablestep16array.push({id:$scope.tablestep16array_f.length + 1,name:data})
	$scope.tablestep16array.push({id:$scope.tablestep16array_g.length + 1,name:data})
	$scope.tablestep16array.push({id:$scope.tablestep16array_h.length + 1,name:data})
	$scope.tablestep16array.push({id:$scope.tablestep16array_i.length + 1,name:data})
	$scope.tablevalepushdoc3 ="";
  }
  

  $scope.tablestep17array = [{name:"Passport"},{name:"Driving Licence"},{name:"National ID Card"},{name:"Electronic Data source"},{name:"Publicly available docs"}];
  $scope.table1valdoc2 = function(data){
  debugger
	$scope.tablestep17array.push({id:$scope.tablestep17array.length + 1,name:data})
	$scope.tablevalepush2 ="";
  }
  
   $scope.tablestep18array = [{name:"Passport"},{name:"Driving Licence"},{name:"National ID Card"},{name:"Electronic Data source"},{name:"Publicly available docs"}];
   $scope.table1val18 = function(data){
  debugger
	$scope.tablestep18array.push({id:$scope.tablestep18array.length + 1,name:data})
	$scope.tablevalepush4 ="";
  }
  $scope.docadd1 = function(data){
  debugger
  
   $scope.documentaddflag1 = true;
   $scope.addcustomerdoc1.push({id:$scope.addcustomerdoc1.length + 1,name:data})
   $scope.tablevalepushdoc1 ="";
	} 
	 $scope.docadd2 = function(data){
  $scope.tablevalepushdoc2 ="";
   $scope.documentaddflag2 = true;
   $scope.addcustomerdoc2.push({id:$scope.addcustomerdoc2.length + 1,name:data})
	} 
	 $scope.docadd3 = function(data){
  $scope.tablevalepushdoc3 ="";
   $scope.documentaddflag3 = true;
   $scope.addcustomerdoc3.push({id:$scope.addcustomerdoc3.length + 1,name:data})
	} 
	 $scope.docadd4 = function(data){
  $scope.tablevalepushdoc4 ="";
   $scope.documentaddflag4 = true;
   $scope.addcustomerdoc4.push({id:$scope.addcustomerdoc4.length + 1,name:data})
	} 
	 $scope.docadd5 = function(data){
  $scope.tablevalepushdoc5 ="";
   $scope.documentaddflag5 = true;
   $scope.addcustomerdoc5.push({id:$scope.addcustomerdoc5.length + 1,name:data})
	} 
	 $scope.docadd6 = function(data){
  $scope.tablevalepushdoc6 ="";
   $scope.documentaddflag6 = true;
   $scope.addcustomerdoc6.push({id:$scope.addcustomerdoc6.length + 1,name:data})
	} 
	 $scope.docadd7 = function(data){
  $scope.tablevalepushdoc7 ="";
   $scope.documentaddflag7 = true;
   $scope.addcustomerdoc7.push({id:$scope.addcustomerdoc7.length + 1,name:data})
	} 
	 $scope.docadd8 = function(data){
  $scope.tablevalepushdoc8 ="";
   $scope.documentaddflag8 = true;
   $scope.addcustomerdoc8.push({id:$scope.addcustomerdoc8.length + 1,name:data})
	} 
	 $scope.docadd9 = function(data){
  $scope.tablevalepushdoc9 ="";
   $scope.documentaddflag9 = true;
   $scope.addcustomerdoc9.push({id:$scope.addcustomerdoc9.length + 1,name:data})
	} 
	 $scope.docadd10 = function(data){
  $scope.tablevalepushdoc10 ="";
   $scope.documentaddflag10 = true;
   $scope.addcustomerdoc10.push({id:$scope.addcustomerdoc10.length + 1,name:data})
	} 
	$scope.docadd11 = function(data){
  $scope.tablevalepushdoc11 ="";
   $scope.documentaddflag11 = true;
   $scope.addcustomerdoc11.push({id:$scope.addcustomerdoc11.length + 1,name:data})
	} 
	$scope.docadd12 = function(data){
  $scope.tablevalepushdoc12 ="";
   $scope.documentaddflag12 = true;
   $scope.addcustomerdoc12.push({id:$scope.addcustomerdoc12.length + 1,name:data})
	}




	
  //$scope.active_circle = 'val';
   $scope.selectedindex = -1;
	 $scope.getClass = function(item, indexval) {
		debugger
	 if($scope.selectedindex == indexval ){ 
		return "newcolour";
	 }
	 else
	 {
		return "newcol1";
	 }
/* debugger	 
       $scope.active_circle = $scope.active_circle == item?'':indexval; */
     }
	 $scope.pageNumber = 0;
    $scope.setPageNumber = function(index) {
	debugger
        $scope.pageNumber = index;
    }
	$scope.documentcontrollerFlag = 1;
	$scope.documentent = function(data){
		$scope.documentcontrollerFlag = data;
	}
	$scope.idvothersstandardFlag = 1;
	$scope.documentOthersFlag = function(data){     
		$scope.idvothersstandardFlag = data;
	}
  
 $scope.tablestep19array = [{name:"Passport"},{name:"Driving Licence"},{name:"National ID Card"},{name:"Electronic Data source"},{name:"Publicly available docs"}];
  $scope.table1valdoc1 = function(data){
  debugger
	$scope.tablestep19array.push({id:$scope.tablestep19array.length + 1,name:data})
	$scope.tablevalepush1 ="";
  } 
  $scope.tablestep20array = [{name:"Passport"},{name:"Driving Licence"},{name:"National ID Card"},{name:"Electronic Data source"},{name:"Publicly available docs"}];
  $scope.table1val20 = function(data){
  debugger
	$scope.tablestep20array.push({id:$scope.tablestep20array.length + 1,name:data})
	$scope.tablevalepush20 ="";
  }
  $scope.tablestep21array = [{name:"Passport"},{name:"Driving Licence"},{name:"National ID Card"},{name:"Electronic Data source"},{name:"Publicly available docs"}];
  $scope.table1val21 = function(data){
  debugger
	$scope.tablestep21array.push({id:$scope.tablestep21array.length + 1,name:data})
	$scope.tablevalepush21 ="";
  }
  
   $scope.tablestep8array = [{name:"Passport"},{name:"Driving Licence"},{name:"National ID Card"},{name:"Electronic Data source"},{name:"Publicly available docs"}];
  $scope.table1val8 = function(data){
  debugger
	$scope.tablestep8array.push({id:$scope.tablestep8array.length + 1,name:data})
	$scope.tablevalepush ="";
  } 
  
    $scope.tablestep9array = [{name:"Passport"},{name:"Driving Licence"},{name:"National ID Card"},{name:"Electronic Data source"},{name:"Publicly available docs"}];
  $scope.table1val9 = function(data){
  debugger
	$scope.tablestep9array.push({id:$scope.tablestep9array.length + 1,name:data})
	$scope.tablevalepush ="";
  } 
  
     $scope.tablestep10array = [{name:"Passport"},{name:"Driving Licence"},{name:"National ID Card"},{name:"Electronic Data source"},{name:"Publicly available docs"}];
  $scope.table1val10 = function(data){
  debugger
	$scope.tablestep10array.push({id:$scope.tablestep10array.length + 1,name:data})
	$scope.tablevalepush ="";
  }

$scope.potentialsecclose = function(){
$scope.customerinfodedupe = false;
$scope.customerdedupeform = true; 
$scope.customernewflag=false;
}
$scope.dedupepopup = function(){
 $("#dedupe_popup").hide();
}

$scope.generatedocfn = function(value){  
debugger  
if(value == undefined || value.ownershiptype == undefined || value.riskvalue == undefined || value.countryField == undefined || value.subentitytype== undefined  || value.entityType1 == undefined){   
$scope.alerttab = true;  
}
else 
$timeout(function(){
$scope.documentgenerateflag = true;
},1000);
}

$scope.ownershipFn = function(data){ 
	//$scope.entityValue1 = true;
	//$scope.subentitytype = false;
	
	localStorage.ownershipFlag = data;

	if(data == "PrivatelyOwned"){
$scope.entityradioValue = [{id: 1,name:"Private Company", type: "PrivateCompany"},{id: 2,name:"Partnership", type: "Partnership"},{id: 3,name:"Un Incorporated Business",type: "UnIncorporatedBusiness"}];	
	}
	else if(data == "PubliclyQuoted"){ 
	$scope.entityradioValue = [{id:1,name:"On Recognised SE",type: "OnRecognisedSE"},{id:2,name:"Not on Recognised SE",type: "NotOnRecognisedSE"}];	
	}
	else if(data == "GovernmentOwned"){  
	$scope.entityradioValue = [{id: 1,name:"Government", type: "Government"},{id: 2,name:"Public Sector Bodies",type: "PublicSectorBodies"},{id: 3,name:"Statutory Corporations", type: "StatutoryCorporations"},{id: 4,name:"State Owned Corporations",type: "StateOwnedCorporations"},{id: 5,name:"Central Banks",type: "CentralBanks"},{id: 6,name:"Supra Nationals and Dev Org",type: "SupraNationals"}];	
	}
	} 
	
	
	$scope.entityFn = function(data){
	//$scope.SubClientFlag = true;
	localStorage.entityFlag = data;
	if(data == "PrivateCompany"){
	$scope.subEntity = [{id: 1,name:"Regulated FI",value: "RegulatedFI"},{id: 2,name:"Established Entity",value: "EstablishedEntity"},{id: 3,name:"Correspondent Bank",value: "CorrespondentBank"},{id: 4,name:"Money Service Bureau",value: "MoneyServiceBureau"},{id:5,name:"Trust/ Foundations", value: "TrustFoundations"},{id: 6,name:"NGO/ Charities / Places of Worship", value: "NGO"},{id: 7,name:"Clubs and Societies",value: "ClubsAndSocieties"},{id: 8,name:"Other Private Companies",value: "OtherPrivateCompanies"}];	
	}else if(data == "Partnership"){
	$scope.subEntity = [{id: 1,name:"Established Entity",value: "EstablishedEntity"},{id: 3,name:"Other Partnerships", value: "OtherPartnerships"}];	
	}else if(data == "UnIncorporatedBusiness"){
	$scope.subEntity = [{id: 1,name:"Established Entity",value: "EstablishedEntity"},{id: 2,name:"Trust / Foundations", value: "TrustFoundations"},{id: 3,name:"NGO/ Charities / Places of Worship", "value": "NGOCharitiesPlacesOfWorship"},{id: 4,name:"Clubs and Societies",value: "ClubsAndSocieties"},{id: 5,name:"Other Un Inc Business",value: "UnIncBusiness"}];	
	}else if(data == "OnRecognisedSE"){
	$scope.subEntity = [{id: 1,name:"Regulated FI",value: "RegulatedFI"},{id: 2,name:"Correspondent Bank",value: "CorrespondentBank"},{id: 3,name:"Money Service Bureau", value: "MoneyServiceBureau"},{id: 4,name:"Trusts / Foundations",value: "TrustsFoundations"},{id: 5,name:"Widely Held (>50% held with Public)", value: "50HeldWithPublic"},{id: 6,name:"Not Widely held (< 50% held with Public)", value: "50HeldWithPublic"}];	
	}else if(data == "NotOnRecognisedSE"){
	$scope.subEntity = [{id: 1,name:"Regulated FI", value: "RegulatedFI"},{id: 2,name:"Correspondent Bank", value: "CorrespondentBank"},{id: 3,name:"Money Service Bureau", value: "MoneyServiceBureau"},{id: 4,name:"Trusts / Foundations", value: "TrustsFoundations"},{id: 5,name:"Publicly Quoted", value: "PubliclyQuoted"}];	
	}else if(data == "Government"){
	$scope.subEntity = [{id: 1,name:"Gov Ministries / Dept / Agencies", value: "GovMinistriesDeptAgencies"}];	
	}else if(data == "PublicSectorBodies"){
	$scope.subEntity = [{id: 1,name:"Public Sector Bodies", value: "PublicSectorBodies"}];	
	}else if(data == "StatutoryCorporations"){
	$scope.subEntity = [{id: 1,name:"Correspondent Bank", value: "CorrespondentBank"},{id: 2,name:"Money Service Bureau", value: "MoneyServiceBureau"},{id: 3,name:"Trust / Foundations", value: "TrustFoundations"},{id: 4,name:"Regulated FI",value: "RegulatedFI"},{id: 5,name:"Other Statutory Corporations",value: "OtherStatutoryCorporations"}];	
	}else if(data == "StateOwnedCorporations"){
	$scope.subEntity = [{id: 1,name:"Correspondent Bank",value: "CorrespondentBank"},{id: 2,name:"Trust / Foundations", value: "TrustFoundations"},{id: 3,name:"Other State owned Corporations",value: "OtherStateOwnedCorporations"}];	
	}else if(data == "CentralBanks"){
	$scope.subEntity = [{id: 1,name:"Central Banks", value: "CentralBanks"}];	
	}else if(data == "SupraNationals"){
	$scope.subEntity = [{id: 1,name:"Supra Nationals and Dev Org", value: "SupraNationals"}];	
	}	
	}

	
	vm.documents = Document.data;
	vm.prohibited = Prohibited.data;
	$scope.isic = ISIC.data;
	$scope.stockExchange = Stock.data;
	$scope.currency = Currency.data;		
			vm.dtOptions = {
            dom       : '<"top"f>rt<"bottom"<"left"<"length"l>><"right"<"info"i><"pagination"p>>>',
            pagingType: 'simple',
            autoWidth : false,
            responsive: false
        };
	
	$scope.CusIdentification = function(data){
	$scope.name = data.Name;
	$scope.aliasName = "John";
	$scope.ownership = "Private";
	$scope.entity = "Incorporation";
	$scope.Subentity = "Private";
	$scope.address = "3425 GOLFVIEW DR #111, EAGAN, MN 55123-1268.";
	$scope.address2 = data.address2;
	$scope.address3 = data.address3;
	$scope.address4 = data.address4;
	$scope.dateIncrop = "11/11/2016";
	$scope.countryIncrop = "USA";
	$scope.regNumber = data.RegNumber;
	
	$scope.groupName = "Gold";
	$scope.estabilishment = "USA";
	
	$scope.appId = "123";
	$scope.appId1 = "234";
	$scope.appId2 = "456";
	$scope.appId3 = "567";
	$scope.sourcing = "private";
	$scope.logging = "11/11/2016";
	$scope.csp = "Private Ltd";
	$scope.segment = "Trading";
	$scope.rmCode = "12345";
	$scope.visitDate = "18-11-16";
	
	$scope.ofcContact = "011-7553-2345";
	$scope.contactPerson = "John";
	$scope.contactDeg = "Senior";
	$scope.phoneNo = data.phone;
	}
	
	$("table tbody th").hover(function(event) {
  $(".drawer").show().appendTo($(this).find("td:first"));
}, function() {
  $(this).find(".drawer").hide();
});


$scope.sendApproval = function(){
$("#approval").trigger('click');
}

$scope.addLocation = function(){
var data = angular.element( document.querySelector( '#location' ) );
$("#locationClone").append(data.clone());
}
// $scope.addAdverse=function(){
// var data=angular.element(document.querySelector( '#addAdverse' ));
// $("#addAdverseClone").append(data.clone());
// }
$scope.addOffice =function()
{
var data=angular.element(document.querySelector( '#contact' ));
$("#contactclone").append(data.clone());
}
$scope.addcountry =function()
{
var data=angular.element(document.querySelector( '#countryadd' ));
$("#countryclone").append(data.clone());
}
$scope.addcountry2 =function()
{
var data=angular.element(document.querySelector( '#countryadd2' ));
$("#countryclone2").append(data.clone());
}
$scope.businessinfo=function()
{
var data=angular.element(document.querySelector( '#businessinfo' ));
$("#businessinfoclone").append(data.clone());
}

$scope.sentApprovalFlag = false;
$scope.sentApprovalFlag1 = false;
$scope.showTabImage = true;
$scope.showTabImage1 = false;
$scope.approveFn = function(){
$scope.showTabImage = false;
$scope.showTabImage1 = true;
}
$scope.approveFn1 = function(){
$scope.sentApprovalFlag1 = true;
}
$scope.showFamilyFlag = false;
$scope.showPublicFlag = false;
$scope.showPartyPepFlag=false;
$scope.flagRelated=false;
$scope.flagRelated2=false;
$scope.question1=false;
$scope.question2=false;
$scope.question3=false;
$scope.question4=false;
$scope.question5=false;
$scope.question6=false;
$scope.question7=false;
$scope.question8=false;
$scope.question9=false;
$scope.flagPartynon=false;
$scope.flagParty=false;
$scope.adversemedia1=false;
$scope.question10=false;
$scope.question11=false;
$scope.question12=false;
$scope.question13=false;
$scope.question14=false;
$scope.question15=false;
$scope.regulatoryflag2=false;
$scope.regulatoryflag=false;
$scope.flagcrime=false;
$scope.flagnotcrime=false;
$scope.tableshowflag=false;
$scope.empflagshow=false;
$scope.selectholder = function(data){
	$scope.showPartyPepFlag=false;
	
if(data == "PublicFunctionHolder"){
$scope.showPublicFlag = true;
$scope.showFamilyFlag = false;
$scope.pepCategory = [{rel : "Spouse"}, {rel : "Partner"}, {rel : "Child"}, {rel : "Spouse of Child"}, {rel : "Sibling"}, {rel : "Parent"}];
} else if(data == "ImmediateFamilyMember" || data == "closeassociate"){
$scope.showFamilyFlag = true;
$scope.showPublicFlag = false;
$scope.pepCategory = [{rel : "Advisor"}, {rel : "Consultant"}, {rel : "Law Firm"}, {rel : "Accountant"}, {rel : "Business Partner"}, {rel : "Other"}];
}
}


$scope.selectparty =function(data){
if(data == "yes")
{
$scope.showPartyPepFlag=true;
}
else if(data == "no")
{
$scope.showPartyPepFlag=false;
}
}
$scope.Relateparty =function(data){
if(data == "nonindividual")
{
$scope.flagRelated=true;
$scope.flagRelated2=false;
}
else if(data == "individual")
{
$scope.flagRelated2=true;
$scope.flagRelated=false;

}
 
}
$scope.adveremediaClass =function(data){
if(data == "Other")
{
$scope.question10=true;
}
else if(data == "sanctions" || data == "ML" || data == "Fraud" || data == "Bribery" || data == "company" || data == "internalcontrolfailures" || data == "regulatory")
{
$scope.question10=false;
}

}
$scope.Infrastructure =function(data){
if(data == "yes")
{
$scope.question1=true;
}
else if(data == "no")
{
$scope.question1=false;
}
}
$scope.buy=function(data){
if(data == "yes")
{
$scope.question2=true;
}
else if(data == "no")
{
$scope.question2=false;
}
}
$scope.resident =function(data){
if(data == "yes")
{
$scope.question3=true;
}
else if(data == "no")
{
$scope.question3=false;
}
}
$scope.governmentagency =function(data){
if(data == "yes")
{
$scope.question4=true;
}
else if(data == "no")
{
$scope.question4=false;
}
}
$scope.incorporated3 =function(data){
if(data == "yes")
{
$scope.question5=true;
}
else if(data == "no")
{
$scope.question5=false;
}
}
$scope.rough =function(data){
if(data == "yes")
{
$scope.question6=true;
}
else if(data == "no")
{
$scope.question6=false;
}
}
$scope.subscribe =function(data){
if(data == "yes")
{
$scope.question7=true;
}
else if(data == "no")
{
$scope.question7=false;
}
}
$scope.sanctionsrisk =function(data){
if(data == "yes")
{
$scope.question8=true;
}
else if(data == "no")
{
$scope.question8=false;
}
}
$scope.expandbusiness =function(data){
if(data == "yes")
{
$scope.question9=true;
}
else if(data == "no")
{
$scope.question9=false;
}
}
$scope.nonindiv =function(data){
if(data == "NonIndividual")
{
$scope.flagPartynon=true;
$scope.flagParty=false;
}
else if(data == "Individual")
{
$scope.flagParty=true;
$scope.flagPartynon=false;
}
}
$scope.adveremedia=function(data){
if(data == "yes")
{
$scope.adversemedia1=true;
}
else if(data == "no")
{
$scope.adversemedia1=false;
}
}
$scope.regulatory2 =function(data){
if(data == "yes")
{
$scope.regulatoryflag=true;
$scope.regulatoryflag2=false;
}
else if(data == "no")
{
$scope.regulatoryflag2=true;
$scope.regulatoryflag=false;
}
}
$scope.Typeofnegative =function(data)
{
if(data == "FinCrime")
{
$scope.flagcrime=true;
$scope.flagnotcrime=false;
}
else if(data == "NotFinCrime")
{
$scope.flagcrime=false;
$scope.flagnotcrime=true;
}
}
$scope.viewTable= function()
{
$scope.tableshowflag=true;
}
$scope.amlcef =function(data)
{
if(data == "yes"){$scope.question11=true;}
else if(data == "no"){$scope.question11=false;}
}
$scope.amlcefone =function(data)
{
if(data == "yes"){$scope.question12=true;}
else if(data == "no"){$scope.question12=false;}
}
$scope.amlceftwo =function(data)
{
if(data == "yes"){$scope.question13=true;}
else if(data == "no"){$scope.question13=false;}
}
$scope.amlcefthree =function(data)
{
if(data == "yes"){$scope.question14=true;}
else if(data == "no"){$scope.question14=false;}
}
$scope.amlceffour =function(data)
{
if(data == "yes"){$scope.question15=true;}
else if(data == "no"){$scope.question15=false;}
}
$scope.override =function(data)
{
if(data == "Empanel"){$scope.empflagshow=true;}
else if(data == "Reject"){$scope.empflagshow=false;}
}

// $scope.selectpublicref =function(data)
// {if(data == "yes"){$scope.showPartyPublicFlag=true;}
// else if(data == "no"){$scope.showPartyPublicFlag=false;}
// }



$scope.approvalBtn = function(){
$("#approvalDropDown").trigger('click');
}


$scope.emailNotification = function(){
$("#showEmailNotification").trigger('click');
}

$scope.modalNotification = function(){
$("#viewDialog").trigger('click');
}


$scope.openDialog = function(){
$("#undo").trigger('click');
}

$scope.watchListFlag = true;
$scope.googleListFlag = false;
$scope.nameScreening = function(data){
if(data == "watch"){
$scope.watchListFlag = true;
$scope.googleListFlag = false;
} else if(data == "google"){
$scope.watchListFlag = false;
$scope.googleListFlag = true;
}
}

$scope.datepickerFn = function(){
$timeout(function(){
$( ".datepicker" ).datepicker();
},500);
}
$scope.countrydetails = true;
$scope.removecontent = function(){
$scope.countrydetails = false;
}



$scope.disableProhibited1 = true;




// Screen 3 Start
	// Non Banking Financial Institution Start
	$scope.showNonLicenseFlag = false;
	$scope.nonLicense = false;
	$scope.licenseShow = function(data){
	if(data == "no"){
	$scope.showNonLicenseFlag = true;
	$scope.nonLicense = true;
	} else{
	$scope.showNonLicenseFlag = false;
	$scope.nonLicense = false;
	}
	}
	
	$scope.requiredComment1 = false;
	$scope.requiredComment2 = false;
	$scope.requiredComment3 = false;
	$scope.requiredComment4 = false;
	$scope.requiredComment5 = false;
	$scope.requiredComment6 = false;
	$scope.requiredComment7 = false;
	$scope.requiredComment8 = false;
	$scope.requiredComment9 = false;
	$scope.requiredComment10 = false;
	$scope.requiredComment11 = false;
	$scope.requiredComment12 = false;
	$scope.requiredComment13 = false;
	$scope.requiredComment14 = false;
	$scope.requiredComment15 = false;
	$scope.requiredComment16 = false;
	$scope.requiredComment17 = false;
	$scope.requiredComment18 = false;
	$scope.requiredComment19 = false;
	
	$scope.showBankingComment1 = false;
	$scope.showBankingComment2 = false;
	$scope.showBankingComment3 = false;
	$scope.showBankingComment4 = false;
	$scope.showBankingComment5 = false;
	$scope.showBankingComment6 = false;
	$scope.showBankingComment7 = false;
	$scope.showBankingComment8 = false;
	$scope.showBankingComment9 = false;
	$scope.showBankingComment10 = false;
	$scope.showBankingComment11 = false;
	$scope.showBankingComment12 = false;
	$scope.showBankingComment13 = false;
	$scope.showBankingComment14 = false;
	$scope.showBankingComment15 = false;
	$scope.showBankingComment16 = false;
	$scope.showBankingComment17 = false;
	$scope.showBankingComment18 = false;
	$scope.showBankingComment19 = false;
	
	$scope.amlQuestion = function(value, data){
	if(value == 1){
	if(data == "no"){
	$scope.showBankingComment1 = true;
	$scope.requiredComment1 = true;
	} else {
	$scope.showBankingComment1 = false;
	$scope.requiredComment1 = false;
	}
	} else if(value == 2){
	if(data == "no"){
	$scope.showBankingComment2 = true;
	$scope.requiredComment2 = true;
	} else {
	$scope.showBankingComment2 = false;
	$scope.requiredComment2 = false;
	}
	} else if(value == 3){
	if(data == "no"){
	$scope.showBankingComment3 = true;
	$scope.requiredComment3 = true;
	} else {
	$scope.showBankingComment3 = false;
	$scope.requiredComment3 = false;
	}
	} else if(value == 4){
	if(data == "no"){
	$scope.showBankingComment4 = true;
	$scope.requiredComment4 = true;
	} else {
	$scope.showBankingComment4 = false;
	$scope.requiredComment4 = false;
	}
	} else if(value == 5){
	if(data == "no"){
	$scope.showBankingComment5 = true;
	$scope.requiredComment5 = true;
	} else {
	$scope.showBankingComment5 = false;
	$scope.requiredComment5 = false;
	}
	} else if(value == 6){
	if(data == "no"){
	$scope.showBankingComment6 = true;
	$scope.requiredComment6 = true;
	} else {
	$scope.showBankingComment6 = false;
	$scope.requiredComment6 = false;
	}
	} else if(value == 7){
	if(data == "no"){
	$scope.showBankingComment7 = true;
	$scope.requiredComment7 = true;
	} else {
	$scope.showBankingComment7 = false;
	$scope.requiredComment7 = false;
	}
	} else if(value == 8){
	if(data == "no"){
	$scope.showBankingComment8 = true;
	$scope.requiredComment8 = true;
	} else {
	$scope.showBankingComment8 = false;
	$scope.requiredComment8 = false;
	}
	} else if(value == 9){
	if(data == "no"){
	$scope.showBankingComment9 = true;
	$scope.requiredComment9 = true;
	} else {
	$scope.showBankingComment9 = false;
	$scope.requiredComment9 = false;
	}
	} else if(value == 10){
	if(data == "no"){
	$scope.showBankingComment10 = true;
	$scope.requiredComment10 = true;
	} else {
	$scope.showBankingComment10 = false;
	$scope.requiredComment10 = false;
	}
	} else if(value == 11){
	if(data == "no"){
	$scope.showBankingComment11 = true;
	$scope.requiredComment11 = true;
	} else {
	$scope.showBankingComment11 = false;
	$scope.requiredComment11 = false;
	}
	} else if(value == 12){
	if(data == "no"){
	$scope.showBankingComment12 = true;
	$scope.requiredComment12 = true;
	} else {
	$scope.showBankingComment12 = false;
	$scope.requiredComment12 = false;
	}
	} else if(value == 13){
	if(data == "yes"){
	$scope.showBankingComment13 = true;
	$scope.requiredComment13 = true;
	} else {
	$scope.showBankingComment13 = false;
	$scope.requiredComment13 = false;
	}
	} else if(value == 14){
	if(data == "yes"){
	$scope.showBankingComment14 = true;
	$scope.requiredComment14 = true;
	} else {
	$scope.showBankingComment14 = false;
	$scope.requiredComment14 = false;
	}
	} else if(value == 15){
	if(data == "yes"){
	$scope.showBankingComment15 = true;
	$scope.requiredComment15 = true;
	} else {
	$scope.showBankingComment15 = false;
	$scope.requiredComment15 = false;
	}
	} else if(value == 16){
	if(data == "yes"){
	$scope.showBankingComment16 = true;
	$scope.requiredComment16 = true;
	} else {
	$scope.showBankingComment16 = false;
	$scope.requiredComment16 = false;
	}
	} else if(value == 17){
	if(data == "yes"){
	$scope.showBankingComment17 = true;
	$scope.requiredComment17 = true;
	} else {
	$scope.showBankingComment17 = false;
	$scope.requiredComment17 = false;
	}
	} else if(value == 18){
	if(data == "yes"){
	$scope.showBankingComment18 = true;
	$scope.requiredComment18 = true;
	} else {
	$scope.showBankingComment18 = false;
	$scope.requiredComment18 = false;
	}
	} else if(value == 19){
	if(data == "yes"){
	$scope.showBankingComment19 = true;
	$scope.requiredComment19 = true;
	} else {
	$scope.showBankingComment19 = false;
	$scope.requiredComment19 = false;
	}
	}
	}
	
	$scope.assessmentFn = function(data, invalid){
	if(data == "proceed"){
	if(invalid == true){
	alert("Please fill all the values");
	angular.element("[name='" + ClientForm.$name + "']").find('.required:visible:first').focus();
	return false;
	}
	alert("Proceed");
	} else {
	alert("data has been saved");
	}
	}
	
	// Non Banking Financial Institution End
	
	// Correspondent Bank Start
	$scope.showNonLicenseFlag1 = false;
	$scope.nonLicense1 = false;
	$scope.licenseShow1 = function(data){
	if(data == "no"){
	$scope.showNonLicenseFlag1 = true;
	$scope.nonLicense1 = true;
	} else{
	$scope.showNonLicenseFlag1 = false;
	$scope.nonLicense1 = false;
	}
	}
	
	$scope.showCountryReg = false;
	$scope.countryRegFlag = false;
	$scope.bankName = function(data){
	if(data == "yes"){
	$scope.showCountryReg = true;
	$scope.countryRegFlag = true;
	} else{
	$scope.showCountryReg = false;
	$scope.countryRegFlag = false;
	}
	}
	
	$scope.showAccountPurpose = false;
	$scope.accountPurposeFlag = false;
	$scope.InsLocation = function(data){
	if(data == "yes"){
	$scope.showAccountPurpose = true;
	$scope.accountPurposeFlag = true;
	} else{
	$scope.showAccountPurpose = false;
	$scope.accountPurposeFlag = false;
	}
	}
	
	
	$scope.showWolfsbergComment1 = false;
	$scope.showWolfsbergComment2 = false;
	$scope.showWolfsbergComment3 = false;
	$scope.showWolfsbergComment4 = false;
	$scope.showWolfsbergComment5 = false;
	$scope.showWolfsbergComment6 = false;
	$scope.showWolfsbergComment7 = false;
	$scope.showWolfsbergComment8 = false;
	$scope.showWolfsbergComment9 = false;
	$scope.showWolfsbergComment10 = false;
	$scope.showWolfsbergComment11 = false;
	$scope.showWolfsbergComment12 = false;
	$scope.showWolfsbergComment13 = false;
	$scope.showWolfsbergComment14 = false;
	$scope.showWolfsbergComment15 = false;
	$scope.showWolfsbergComment16 = false;
	$scope.showWolfsbergComment17 = false;
	$scope.showWolfsbergComment18 = false;
	$scope.showWolfsbergComment19 = false;
	$scope.showWolfsbergComment20 = false;
	$scope.showWolfsbergComment21 = false;
	$scope.showWolfsbergComment22 = false;
	$scope.showWolfsbergComment23 = false;
	$scope.showWolfsbergComment24 = false;
	$scope.showWolfsbergComment25 = false;
	$scope.showWolfsbergComment26 = false;
	$scope.showWolfsbergComment27 = false;
	$scope.showWolfsbergComment28 = false;
	
	$scope.requiredWolfsberg1 = false;
	$scope.requiredWolfsberg2 = false;
	$scope.requiredWolfsberg3 = false;
	$scope.requiredWolfsberg4 = false;
	$scope.requiredWolfsberg5 = false;
	$scope.requiredWolfsberg6 = false;
	$scope.requiredWolfsberg7 = false;
	$scope.requiredWolfsberg8 = false;
	$scope.requiredWolfsberg9 = false;
	$scope.requiredWolfsberg10 = false;
	$scope.requiredWolfsberg11 = false;
	$scope.requiredWolfsberg12 = false;
	$scope.requiredWolfsberg13 = false;
	$scope.requiredWolfsberg14 = false;
	$scope.requiredWolfsberg15 = false;
	$scope.requiredWolfsberg16 = false;
	$scope.requiredWolfsberg17 = false;
	$scope.requiredWolfsberg18 = false;
	$scope.requiredWolfsberg19 = false;
	$scope.requiredWolfsberg20 = false;
	$scope.requiredWolfsberg21 = false;
	$scope.requiredWolfsberg22 = false;
	$scope.requiredWolfsberg23 = false;
	$scope.requiredWolfsberg24 = false;
	$scope.requiredWolfsberg25 = false;
	$scope.requiredWolfsberg26 = false;
	$scope.requiredWolfsberg27 = false;
	$scope.requiredWolfsberg28 = false;
	
	$scope.showAMLTrainingDiv = false;
	$scope.requiredAMLTraining = false;
	
	$scope.WolfsbergQuestion = function(value, data){
	if(value == 1){
	if(data == "no"){
	$scope.showWolfsbergComment1 = true;
	$scope.requiredWolfsberg1 = true;
	} else {
	$scope.showWolfsbergComment1 = false;
	$scope.requiredWolfsberg1 = false;
	}
	} else if(value == 2){
	if(data == "no"){
	$scope.showWolfsbergComment2 = true;
	$scope.requiredWolfsberg2 = true;
	} else {
	$scope.showWolfsbergComment2 = false;
	$scope.requiredWolfsberg2 = false;
	}
	} else if(value == 3){
	if(data == "no"){
	$scope.showWolfsbergComment3 = true;
	$scope.requiredWolfsberg3 = true;
	} else {
	$scope.showWolfsbergComment3 = false;
	$scope.requiredWolfsberg3 = false;
	}
	} else if(value == 4){
	if(data == "no"){
	$scope.showWolfsbergComment4 = true;
	$scope.requiredWolfsberg4 = true;
	} else {
	$scope.showWolfsbergComment4 = false;
	$scope.requiredWolfsberg4 = false;
	}
	} else if(value == 5){
	if(data == "no"){
	$scope.showWolfsbergComment5 = true;
	$scope.requiredWolfsberg5 = true;
	} else {
	$scope.showWolfsbergComment5 = false;
	$scope.requiredWolfsberg5 = false;
	}
	} else if(value == 6){
	if(data == "no"){
	$scope.showWolfsbergComment6 = true;
	$scope.requiredWolfsberg6 = true;
	} else {
	$scope.showWolfsbergComment6 = false;
	$scope.requiredWolfsberg6 = false;
	}
	} else if(value == 7){
	if(data == "no"){
	$scope.showWolfsbergComment7 = true;
	$scope.requiredWolfsberg7 = true;
	} else {
	$scope.showWolfsbergComment7 = false;
	$scope.requiredWolfsberg7 = false;
	}
	} else if(value == 8){
	if(data == "no"){
	$scope.showWolfsbergComment8 = true;
	$scope.requiredWolfsberg8 = true;
	} else {
	$scope.showWolfsbergComment8 = false;
	$scope.requiredWolfsberg8 = false;
	}
	} else if(value == 9){
	if(data == "no"){
	$scope.showWolfsbergComment9 = true;
	$scope.requiredWolfsberg9 = true;
	} else {
	$scope.showWolfsbergComment9 = false;
	$scope.requiredWolfsberg9 = false;
	}
	} else if(value == 10){
	if(data == "no"){
	$scope.showWolfsbergComment10 = true;
	$scope.requiredWolfsberg10 = true;
	} else {
	$scope.showWolfsbergComment10 = false;
	$scope.requiredWolfsberg10 = false;
	}
	} else if(value == 11){
	if(data == "no"){
	$scope.showWolfsbergComment11 = true;
	$scope.requiredWolfsberg11 = true;
	} else {
	$scope.showWolfsbergComment11 = false;
	$scope.requiredWolfsberg11 = false;
	}
	} else if(value == 12){
	if(data == "no"){
	$scope.showWolfsbergComment12 = true;
	$scope.requiredWolfsberg12 = true;
	} else {
	$scope.showWolfsbergComment12 = false;
	$scope.requiredWolfsberg12 = false;
	}
	} else if(value == 13){
	if(data == "no"){
	$scope.showWolfsbergComment13 = true;
	$scope.requiredWolfsberg13 = true;
	} else {
	$scope.showWolfsbergComment13 = false;
	$scope.requiredWolfsberg13 = false;
	}
	} else if(value == 14){
	if(data == "no"){
	$scope.showWolfsbergComment14 = true;
	$scope.requiredWolfsberg14 = true;
	} else {
	$scope.showWolfsbergComment14 = false;
	$scope.requiredWolfsberg14 = false;
	}
	} else if(value == 15){
	if(data == "no"){
	$scope.showWolfsbergComment15 = true;
	$scope.requiredWolfsberg15 = true;
	} else {
	$scope.showWolfsbergComment15 = false;
	$scope.requiredWolfsberg15 = false;
	}
	} else if(value == 16){
	if(data == "no"){
	$scope.showWolfsbergComment16 = true;
	$scope.requiredWolfsberg16 = true;
	} else {
	$scope.showWolfsbergComment16 = false;
	$scope.requiredWolfsberg16 = false;
	}
	} else if(value == 17){
	if(data == "no"){
	$scope.showWolfsbergComment17 = true;
	$scope.requiredWolfsberg17 = true;
	} else {
	$scope.showWolfsbergComment17 = false;
	$scope.requiredWolfsberg17 = false;
	}
	} else if(value == 18){
	if(data == "no"){
	$scope.showWolfsbergComment18 = true;
	$scope.requiredWolfsberg18 = true;
	} else {
	$scope.showWolfsbergComment18 = false;
	$scope.requiredWolfsberg18 = false;
	}
	} else if(value == 19){
	if(data == "no"){
	$scope.showWolfsbergComment19 = true;
	$scope.requiredWolfsberg19 = true;
	} else {
	$scope.showWolfsbergComment19 = false;
	$scope.requiredWolfsberg19 = false;
	}
	} else if(value == 20){
	if(data == "no"){
	$scope.showWolfsbergComment20 = true;
	$scope.requiredWolfsberg20 = true;
	} else {
	$scope.showWolfsbergComment20 = false;
	$scope.requiredWolfsberg20 = false;
	}
	} else if(value == 21){
	if(data == "no"){
	$scope.showWolfsbergComment21 = true;
	$scope.requiredWolfsberg21 = true;
	} else {
	$scope.showWolfsbergComment21 = false;
	$scope.requiredWolfsberg21 = false;
	}
	} else if(value == 22){
	if(data == "no"){
	$scope.showWolfsbergComment22 = true;
	$scope.requiredWolfsberg22 = true;
	} else {
	$scope.showWolfsbergComment22 = false;
	$scope.requiredWolfsberg22 = false;
	}
	} else if(value == 23){
	if(data == "no"){
	$scope.showWolfsbergComment23 = true;
	$scope.requiredWolfsberg23 = true;
	} else {
	$scope.showWolfsbergComment23 = false;
	$scope.requiredWolfsberg23 = false;
	}
	} else if(value == 24){
	if(data == "no"){
	$scope.showWolfsbergComment24 = true;
	$scope.requiredWolfsberg24 = true;
	} else {
	$scope.showWolfsbergComment24 = false;
	$scope.requiredWolfsberg24 = false;
	}
	} else if(value == 25){
	if(data == "no"){
	$scope.showWolfsbergComment25 = true;
	$scope.requiredWolfsberg25 = true;
	} else {
	$scope.showWolfsbergComment25 = false;
	$scope.requiredWolfsberg25 = false;
	}
	} else if(value == 26){
	if(data == "no"){
	$scope.showWolfsbergComment26 = true;
	$scope.requiredWolfsberg26 = true;
	} else {
	$scope.showWolfsbergComment26 = false;
	$scope.requiredWolfsberg26 = false;
	}
	} else if(value == 27){
	if(data == "no"){
	$scope.showWolfsbergComment27 = true;
	$scope.requiredWolfsberg27 = true;
	} else {
	$scope.showWolfsbergComment27 = false;
	$scope.requiredWolfsberg27 = false;
	}
	} else if(value == 28){
	if(data == "no"){
	$scope.showWolfsbergComment28 = true;
	$scope.requiredWolfsberg28 = true;
	} else {
	$scope.showWolfsbergComment28 = false;
	$scope.requiredWolfsberg28 = false;
	}
	}
	
	if($scope.correspondent.Wolfsberg25 == "no" && $scope.correspondent.Wolfsberg26 == "no" && $scope.correspondent.Wolfsberg27 == "no"){
		$scope.showAMLTrainingDiv = true;
		$scope.requiredAMLTraining = true;
	} else{
		$scope.showAMLTrainingDiv = false;
		$scope.requiredAMLTraining = false;
	}
		}
	
	
	$scope.correspondentFn = function(data, invalid){
	if(data == "proceed"){
	if(invalid == true){
	alert("Please fill all the values");
	return false;
	}
	alert("Proceed");
	} else {
	alert("data has been saved");
	}
	
	}
	// Correspondent Bank End
	
	
	// Money Service Business Start
	$scope.showNonLicenseFlag2 = false;
	$scope.nonLicense2 = false;
	$scope.licenseShow2 = function(data){
	if(data == "no"){
	$scope.showNonLicenseFlag2 = true;
	$scope.nonLicense2 = true;
	} else{
	$scope.showNonLicenseFlag2 = false;
	$scope.nonLicense2 = false;
	}
	}
	
	$scope.checkCustomerFlag = false;
	$scope.requiredThreshold = false;
	$scope.checkCustomer = function(data){
	if(data == "yes"){
	$scope.checkCustomerFlag = true;
	$scope.requiredThreshold = true;
	} else{
	$scope.checkCustomerFlag = false;
	$scope.requiredThreshold = false;
	alert("You are not an MSB Customer. Please proceed with the next form");
	}
	}
	
	$scope.checkCustomerFlag1 = false;
	$scope.requiredRevenue = false;
	$scope.checkCustomer1 = function(data){
	if(data == "yes"){
	$scope.checkCustomerFlag1 = true;
	$scope.requiredRevenue = true;
	} else{
	$scope.checkCustomerFlag1 = false;
	$scope.requiredRevenue = false;
	alert("You are not an MSB Customer. Please proceed with the next form");
	}
	}
	
	$scope.checkCustomerFlag2 = false;
	$scope.requiredActivity = false;
	$scope.checkCustomer2 = function(data){
	if(data == "yes"){
	$scope.checkCustomerFlag2 = true;
	$scope.requiredActivity = true;
	} else{
	$scope.checkCustomerFlag2 = false;
	$scope.requiredActivity = false;
	alert("You are not an MSB Customer. Please proceed with the next form");
	}
	}
	
	$scope.checkCustomerFlag3 = false;
	$scope.requiredBusinessFields = false;
	$scope.checkCustomer3 = function(data){
	if(data == "yes"){
	$scope.checkCustomerFlag3 = true;
	$scope.requiredBusinessFields = true;
	} else{
	$scope.checkCustomerFlag3 = false;
	$scope.requiredBusinessFields = false;
	alert("You are not an MSB Customer. Please proceed with the next form");
	}
	}
	
	
	$scope.requiredType = false;
	$scope.showDropdownValue = false;
	$scope.showDropdownValue1 = false;
	$scope.showDropdownValue2 = false;
	$scope.customerTypes = function(data){
	if(data == "Walk-In"){
	$scope.requiredType = true;
	$scope.showDropdownValue = true;
	$scope.showDropdownValue1 = false;
	$scope.showDropdownValue2 = false;
	} else if(data == "Online"){
	$scope.requiredType = true;
	$scope.showDropdownValue = false;
	$scope.showDropdownValue1 = true;
	$scope.showDropdownValue2 = false;
	} else if(data == "Other"){
	$scope.requiredType = true;
	$scope.showDropdownValue = false;
	$scope.showDropdownValue1 = false;
	$scope.showDropdownValue2 = true;
	} else{
	$scope.requiredType = false;
	$scope.showDropdownValue = false;
	$scope.showDropdownValue1 = false;
	$scope.showDropdownValue2 = false;
	}
	}
	
	$scope.showOthersDiv = false;
	$scope.requiredOthersFields = false;
	$scope.typeCheck = function(data, value){
	if(value == "others"){
	$scope.showOthersDiv = true;
	$scope.requiredOthersFields = true;
	} else{
	$scope.showOthersDiv = false;
	$scope.requiredOthersFields = false;
	}
	}
	
	$scope.showPrincipalFlag = false;
	$scope.showAgentFlag = false;
	$scope.requiredAgentFields = false;
	$scope.requiredPrincipalFields = false;
	$scope.catagoryFn = function(data){
	if(data == "Principal"){
	$scope.showPrincipalFlag = true;
	$scope.showAgentFlag = false;
	$scope.requiredAgentFields = true;
	$scope.requiredPrincipalFields = false;
	} else {
	$scope.showAgentFlag = true;
	$scope.showPrincipalFlag = false;
	$scope.requiredAgentFields = false;
	$scope.requiredPrincipalFields = true;
	}
	}
	
	$scope.agentReviewCommentFlag = false;
	$scope.requiredAgentCommentFields = false;
	$scope.agentConcernCommentFlag = false;
	$scope.requiredAgentConcernFields = false;
	$scope.agentReviewFn = function(value, data){
	if(value == 1){
	if(data == "no"){
	$scope.agentReviewCommentFlag = true;
	$scope.requiredAgentCommentFields = true;
	} else {
	$scope.agentReviewCommentFlag = false;
	$scope.requiredAgentCommentFields = false;
	}
	} else if(value == 2){
	if(data == "yes"){
	$scope.agentConcernCommentFlag = true;
	$scope.requiredAgentConcernFields = true;
	} else {
	$scope.agentConcernCommentFlag = false;
	$scope.requiredAgentConcernFields = false;
	}
	}
	}
	
	$scope.showMSBComment1 = false;
	$scope.showMSBComment2 = false;
	$scope.showMSBComment3 = false;
	$scope.showMSBComment4 = false;
	$scope.showMSBComment5 = false;
	$scope.showMSBComment6 = false;
	$scope.showMSBComment7 = false;
	$scope.showMSBComment8 = false;
	$scope.showMSBComment9 = false;
	$scope.showMSBComment10 = false;
	$scope.showMSBComment11 = false;
	$scope.showMSBComment12 = false;
	$scope.showMSBComment13 = false;
	$scope.showMSBComment14 = false;
	$scope.showMSBComment15 = false;
	$scope.showMSBComment16 = false;
	$scope.showMSBComment17 = false;
	$scope.showMSBComment18 = false;
	$scope.showMSBComment19 = false;
	
	$scope.requiredMSBQuestion1 = false;
	$scope.requiredMSBQuestion2 = false;
	$scope.requiredMSBQuestion3 = false;
	$scope.requiredMSBQuestion4 = false;
	$scope.requiredMSBQuestion5 = false;
	$scope.requiredMSBQuestion6 = false;
	$scope.requiredMSBQuestion7 = false;
	$scope.requiredMSBQuestion8 = false;
	$scope.requiredMSBQuestion9 = false;
	$scope.requiredMSBQuestion10 = false;
	$scope.requiredMSBQuestion11 = false;
	$scope.requiredMSBQuestion12 = false;
	$scope.requiredMSBQuestion13 = false;
	$scope.requiredMSBQuestion14 = false;
	$scope.requiredMSBQuestion15 = false;
	$scope.requiredMSBQuestion16 = false;
	$scope.requiredMSBQuestion17 = false;
	$scope.requiredMSBQuestion18 = false;
	$scope.requiredMSBQuestion19 = false;
	
	$scope.MSBQuestionFn = function(value, data){
	if(value == 1){
	if(data == "no"){
	$scope.showMSBComment1 = true;
	$scope.requiredMSBQuestion1 = true;
	} else {
	$scope.showMSBComment1 = false;
	$scope.requiredMSBQuestion1 = false;
	}
	} else if(value == 2){
	if(data == "no"){
	$scope.showMSBComment2 = true;
	$scope.requiredMSBQuestion2 = true;
	} else {
	$scope.showMSBComment2 = false;
	$scope.requiredMSBQuestion2 = false;
	}
	} else if(value == 3){
	if(data == "no"){
	$scope.showMSBComment3 = true;
	$scope.requiredMSBQuestion3 = true;
	} else {
	$scope.showMSBComment3 = false;
	$scope.requiredMSBQuestion3 = false;
	}
	} else if(value == 4){
	if(data == "no"){
	$scope.showMSBComment4 = true;
	$scope.requiredMSBQuestion4 = true;
	} else {
	$scope.showMSBComment4 = false;
	$scope.requiredMSBQuestion4 = false;
	}
	} else if(value == 5){
	if(data == "no"){
	$scope.showMSBComment5 = true;
	$scope.requiredMSBQuestion5 = true;
	} else {
	$scope.showMSBComment5 = false;
	$scope.requiredMSBQuestion5 = false;
	}
	} else if(value == 6){
	if(data == "no"){
	$scope.showMSBComment6 = true;
	$scope.requiredMSBQuestion6 = true;
	} else {
	$scope.showMSBComment6 = false;
	$scope.requiredMSBQuestion6 = false;
	}
	} else if(value == 7){
	if(data == "no"){
	$scope.showMSBComment7 = true;
	$scope.requiredMSBQuestion7 = true;
	} else {
	$scope.showMSBComment7 = false;
	$scope.requiredMSBQuestion7 = false;
	}
	} else if(value == 8){
	if(data == "no"){
	$scope.showMSBComment8 = true;
	$scope.requiredMSBQuestion8 = true;
	} else {
	$scope.showMSBComment8 = false;
	$scope.requiredMSBQuestion8 = false;
	}
	} else if(value == 9){
	if(data == "no"){
	$scope.showMSBComment9 = true;
	$scope.requiredMSBQuestion9 = true;
	} else {
	$scope.showMSBComment9 = false;
	$scope.requiredMSBQuestion9 = false;
	}
	} else if(value == 10){
	if(data == "no"){
	$scope.showMSBComment10 = true;
	$scope.requiredMSBQuestion10 = true;
	} else {
	$scope.showMSBComment10 = false;
	$scope.requiredMSBQuestion10 = false;
	}
	} else if(value == 11){
	if(data == "no"){
	$scope.showMSBComment11 = true;
	$scope.requiredMSBQuestion11 = true;
	} else {
	$scope.showMSBComment11 = false;
	$scope.requiredMSBQuestion11 = false;
	}
	} else if(value == 12){
	if(data == "no"){
	$scope.showMSBComment12 = true;
	$scope.requiredMSBQuestion12 = true;
	} else {
	$scope.showMSBComment12 = false;
	$scope.requiredMSBQuestion12 = false;
	}
	} else if(value == 13){
	if(data == "yes"){
	$scope.showMSBComment13 = true;
	$scope.requiredMSBQuestion13 = true;
	} else {
	$scope.showMSBComment13 = false;
	$scope.requiredMSBQuestion13 = false;
	}
	} else if(value == 14){
	if(data == "yes"){
	$scope.showMSBComment14 = true;
	$scope.requiredMSBQuestion14 = true;
	} else {
	$scope.showMSBComment14 = false;
	$scope.requiredMSBQuestion14 = false;
	}
	} else if(value == 15){
	if(data == "yes"){
	$scope.showMSBComment15 = true;
	$scope.requiredMSBQuestion15 = true;
	} else {
	$scope.showMSBComment15 = false;
	$scope.requiredMSBQuestion15 = false;
	}
	} else if(value == 16){
	if(data == "yes"){
	$scope.showMSBComment16 = true;
	$scope.requiredMSBQuestion16 = true;
	} else {
	$scope.showMSBComment16 = false;
	$scope.requiredMSBQuestion16 = false;
	}
	} else if(value == 17){
	if(data == "yes"){
	$scope.showMSBComment17 = true;
	$scope.requiredMSBQuestion17 = true;
	} else {
	$scope.showMSBComment17 = false;
	$scope.requiredMSBQuestion17 = false;
	}
	} else if(value == 18){
	if(data == "yes"){
	$scope.showMSBComment18 = true;
	$scope.requiredMSBQuestion18 = true;
	} else {
	$scope.showMSBComment18 = false;
	$scope.requiredMSBQuestion18 = false;
	}
	} else if(value == 19){
	if(data == "yes"){
	$scope.showMSBComment19 = true;
	$scope.requiredMSBQuestion19 = true;
	} else {
	$scope.showMSBComment19 = false;
	$scope.requiredMSBQuestion19 = false;
	}
	}
	}
	
	
	$scope.MSBForm = function(data, invalid){
	if(data == "proceed"){
	if(invalid == true){
	alert("Please fill all the values");
	angular.element("[name='" + ClientForm.$name + "']").find('.required:visible:first').focus();
	return false;
	}
	alert("Proceed");
	} else {
	alert("data has been saved");
	}
	}
	
	
	// Money Service Business End
	// Screen 3 End
	
	$scope.showCorrespondentBank = false;
	$scope.showNonBankingFinancialInstitution = false;
	$scope.showMoneyServiceBusiness = false;
	$scope.showTrustFoundation = false;
	$scope.showNGOCharityPlaceofWorship = false;
	$scope.showClubSociety = false;
	$scope.specializedFn = function(data){
	if(data == 1){
	$scope.showCorrespondentBank = true;
	$scope.showNonBankingFinancialInstitution = false;
	$scope.showMoneyServiceBusiness = false;
	$scope.showTrustFoundation = false;
	$scope.showNGOCharityPlaceofWorship = false;
	$scope.showClubSociety = false;
	}else if(data == 2){
	$scope.showCorrespondentBank = false;
	$scope.showNonBankingFinancialInstitution = true;
	$scope.showMoneyServiceBusiness = false;
	$scope.showTrustFoundation = false;
	$scope.showNGOCharityPlaceofWorship = false;
	$scope.showClubSociety = false;
	}else if(data == 3){
	$scope.showCorrespondentBank = false;
	$scope.showNonBankingFinancialInstitution = false;
	$scope.showMoneyServiceBusiness = true;
	$scope.showTrustFoundation = false;
	$scope.showNGOCharityPlaceofWorship = false;
	$scope.showClubSociety = false;
	}else if(data == 4){
	$scope.showCorrespondentBank = false;
	$scope.showNonBankingFinancialInstitution = false;
	$scope.showMoneyServiceBusiness = false;
	$scope.showTrustFoundation = true;
	$scope.showNGOCharityPlaceofWorship = false;
	$scope.showClubSociety = false;
	}else if(data == 5){
	$scope.showCorrespondentBank = false;
	$scope.showNonBankingFinancialInstitution = false;
	$scope.showMoneyServiceBusiness = false;
	$scope.showTrustFoundation = false;
	$scope.showNGOCharityPlaceofWorship = true;
	$scope.showClubSociety = false;
	}else if(data == 6){
	$scope.showCorrespondentBank = false;
	$scope.showNonBankingFinancialInstitution = false;
	$scope.showMoneyServiceBusiness = false;
	$scope.showTrustFoundation = false;
	$scope.showNGOCharityPlaceofWorship = false;
	$scope.showClubSociety = true;	
	}
		
	}
	
	$scope.showModeDropdown = false;
	$scope.modelDropdownRequired = false;
	$scope.expectedanalyticsFlag = false;
	$scope.transactionFn = function(data){
	if(data == "yes"){
	$scope.showModeDropdown = true;	
	$scope.modelDropdownRequired = true;
	$scope.expectedanalyticsFlag = true;
	}else{
	$scope.showModeDropdown = false;
    $scope.modelDropdownRequired = false;	
	$scope.expectedanalyticsFlag = false;
	}
	}
	
	
	$scope.productInfoAry = [];
	
	$scope.addProductInfo = function(){
	$scope.productInfoAry.push({id : $scope.productInfoAry.length+1, model1 : "", model2 : "", model3 : "", name1 : "location"+$scope.productInfoAry.length+1, name2 : "rmcode"+$scope.productInfoAry.length+1, name3 : "mode"+$scope.productInfoAry.length+1})	
	}
	
	$scope.removeAddProductInfo = function(i){
			$scope.productInfoAry.splice(i, 1);
		};
	
	$scope.addProductInfo();
	
	$scope.showBookingLocation = false;
	$scope.showBookingLocation1 = false;
	$scope.showBookingLocation2 = false;
	$scope.bookingLocationRequired = false;
	$scope.bookingLocation1Required = false;
	$scope.bookingLocation2Required = false;
	$scope.bookingAry =[];
	$scope.bookingAry1 =[];
	$scope.bookingAry2 =[];
	$scope.modeFn = function(data){
	if(data == "cheque"){
	$scope.showBookingLocation = true;
	$scope.showBookingLocation1 = false;
	$scope.showBookingLocation2 = false;
    $scope.bookingLocationRequired = true;	
	$scope.addBooking = function(){
	$scope.bookingAry.push({id : $scope.bookingAry.length+1 , model1 : "", model2 : "", model3 : "", model4 : "", model5 : "", model6 : "", model7 : "", name1 : "major"+$scope.bookingAry.length+1, name2 : "avgFreq"+$scope.bookingAry.length+1, name3 : "avgValue"+$scope.bookingAry.length+1, name4 : "percentageValue"+$scope.bookingAry.length+1, name5 : "expMonth"+$scope.bookingAry.length+1, name6 : "fromCoun"+$scope.bookingAry.length+1, name7 : "toCoun"+$scope.bookingAry.length+1});
	}
	$scope.addBooking();
	}else if(data == "cash"){
	$scope.showBookingLocation = false;
	$scope.showBookingLocation1 = true;
	$scope.showBookingLocation2 = false;
    $scope.bookingLocation1Required = true;	
	$scope.addBooking1 = function(){
	$scope.bookingAry1.push({id : $scope.bookingAry1.length+1 , model1 : "", model2 : "", model3 : "", model4 : "", model5 : "", model6 : "", model7 : "", name1 : "major"+$scope.bookingAry1.length+1, name2 : "avgFreq"+$scope.bookingAry1.length+1, name3 : "avgValue"+$scope.bookingAry1.length+1, name4 : "percentageValue"+$scope.bookingAry1.length+1, name5 : "expMonth"+$scope.bookingAry1.length+1, name6 : "fromCoun"+$scope.bookingAry1.length+1, name7 : "toCoun"+$scope.bookingAry1.length+1});
	}
	$scope.addBooking1();	
	}if(data == "transfer"){
	$scope.showBookingLocation = false;
	$scope.showBookingLocation1 = false;
	$scope.showBookingLocation2 = true;
	$scope.bookingLocation2Required = true;
	$scope.addBooking2 = function(){
	$scope.bookingAry2.push({id : $scope.bookingAry2.length+1 , model1 : "", model2 : "", model3 : "", model4 : "", model5 : "", model6 : "", model7 : "", name1 : "major"+$scope.bookingAry2.length+1, name2 : "avgFreq"+$scope.bookingAry2.length+1, name3 : "avgValue"+$scope.bookingAry2.length+1, name4 : "percentageValue"+$scope.bookingAry2.length+1, name5 : "expMonth"+$scope.bookingAry2.length+1, name6 : "fromCoun"+$scope.bookingAry2.length+1, name7 : "toCoun"+$scope.bookingAry2.length+1});
	}
	$scope.addBooking2();
	}
	}
	
	if($scope.pamodel3 == "cheque"){
		   $scope.modeFn($scope.pamodel3);
	   }
	// Prohibited Entity Assessment
	$scope.prohibited12Required = false;
	$scope.prohibitedFn11 = function(data){
	if(data == "yes"){
	$scope.prohibited12Required = true;	
	}else {
	$scope.prohibited12Required = false;
	}
	}
	
	$scope.prohibited22Required = false;
	$scope.prohibitedFn21 = function(data){
	if(data == "yes"){
	$scope.prohibited22Required = true;	
	}else {
	$scope.prohibited22Required = false;
	}
	}
	
	$scope.prohibited32Required = false;
	$scope.prohibitedFn31 = function(data){
	if(data == "yes"){
	$scope.prohibited32Required = true;	
	}else {
	$scope.prohibited32Required = false;
	}
	}
	
	$scope.prohibited42Required = false;
	$scope.prohibitedFn41 = function(data){
	if(data == "yes"){
	$scope.prohibited42Required = true;	
	}else {
	$scope.prohibited42Required = false;
	}
	}
	
	$scope.prohibited52Required = false;
	$scope.prohibitedFn51 = function(data){
	if(data == "yes"){
	$scope.prohibited52Required = true;	
	}else {
	$scope.prohibited52Required = false;
	}
	}
	
	$scope.prohibited62Required = false;
	$scope.prohibitedFn61 = function(data){
	if(data == "yes"){
	$scope.prohibited62Required = true;	
	}else {
	$scope.prohibited62Required = false;
	}
	}
	
	$scope.prohibited72Required = false;
	$scope.prohibitedFn71 = function(data){
	if(data == "yes"){
	$scope.prohibited72Required = true;	
	}else {
	$scope.prohibited72Required = false;
	}
	}
	
	$scope.prohibited82Required = false;
	$scope.prohibitedFn81 = function(data){
	if(data == "yes"){
	$scope.prohibited82Required = true;	
	}else {
	$scope.prohibited82Required = false;
	}
	}
	
	$scope.prohibited92Required = false;
	$scope.prohibitedFn91 = function(data){
	if(data == "yes"){
	$scope.prohibited92Required = true;	
	}else {
	$scope.prohibited92Required = false;
	}
	}
	
	$scope.prohibited102Required = false;
	$scope.prohibitedFn101 = function(data){
	if(data == "yes"){
	$scope.prohibited102Required = true;	
	}else {
	$scope.prohibited102Required = false;
	}
	}
	
	$scope.prohibited112Required = false;
	$scope.prohibitedFn111 = function(data){
	if(data == "yes"){
	$scope.prohibited112Required = true;	
	}else {
	$scope.prohibited112Required = false;
	}
	}
	
	$scope.prohibited122Required = false;
	$scope.prohibitedFn121 = function(data){
	if(data == "yes"){
	$scope.prohibited122Required = true;	
	}else {
	$scope.prohibited122Required = false;
	}
	}
	
	$scope.prohibited132Required = false;
	$scope.prohibitedFn131 = function(data){
	if(data == "yes"){
	$scope.prohibited132Required = true;	
	}else {
	$scope.prohibited132Required = false;
	}
	}
	
	$scope.prohibited142Required = false;
	$scope.prohibitedFn141 = function(data){
	if(data == "yes"){
	$scope.prohibited142Required = true;	
	}else {
	$scope.prohibited142Required = false;
	}
	}
	
	$scope.prohibited152Required = false;
	$scope.prohibitedFn151 = function(data){
	if(data == "yes"){
	$scope.prohibited152Required = true;	
	}else {
	$scope.prohibited152Required = false;
	}
	}
	
	
	
	$scope.showPrivateFlag = false;
	$scope.showPublicFlag = false;
	$scope.showGovernmentFlag = false;
	
	$scope.ownership1 = [{"name":"Privately Owned", "data": "PrivatelyOwned"},{"name":"Publicly Quoted", "data": "PubliclyQuoted"},{"name":"Government Owned", "data": "GovernmentOwned"}];
	
	
	
	$scope.ownershipFn = function(data){
		//debugger;
	if(data == "PrivatelyOwned"){
	$scope.showPrivateFlag = true;
	$scope.showPublicFlag = false;
	$scope.showGovernmentFlag = false;
	$timeout(function(){
	$scope.entityValue1 = [{"name":"Private Company", "type": "PrivateCompany"},{"name":"Partnership", "type": "Partnership"},{"name":"Un Incorporated Business", "type": "UnIncorporatedBusiness"}];
    },1000);	
	}else if(data == "PubliclyQuoted"){
	$scope.showPrivateFlag = false;
	$scope.showPublicFlag = true;
	$scope.showGovernmentFlag = false;
	$timeout(function(){
	$scope.entityValue1 = [{"name":"On Recognised SE", "type": "OnRecognisedSE"},{"name":"Not on Recognised SE", "type": "NotOnRecognisedSE"}];	
	},1000);
	}else if(data == "GovernmentOwned"){
	$scope.showPrivateFlag = false;
	$scope.showPublicFlag = false;
	$scope.showGovernmentFlag = true;
	$timeout(function(){
	$scope.entityValue1 = [{"name":"Government", "type": "Government"},{"name":"Public Sector Bodies", "type": "PublicSectorBodies"},{"name":"Statutory Corporations", "type": "StatutoryCorporations"},{"name":"State Owned Corporations", "type": "StateOwnedCorporations"},{"name":"Majority Owned Sub of State Owned Corp", "type": "MajorityOwned"},{"name":"Central Banks", "type": "CentralBanks"},{"name":"Supra Nationals and Dev Org", "type": "SupraNationals"}];
},1000);	
	}
	}
	
	if($scope.ownershiptype){
	  $scope.ownershipFn($scope.ownershiptype);	
	}
	
	$scope.content = true;
	$scope.entityFn = function(data){
		//debugger;
	if(data == "PrivateCompany"){
	$scope.subEntity = [{id: 1,name:"Regulated FI",value: "RegulatedFI"},{id: 2,name:"Established Entity",value: "EstablishedEntity"},{id: 3,name:"Correspondent Bank",value: "CorrespondentBank"},{id: 4,name:"Money Service Bureau",value: "MoneyServiceBureau"},{id:5,name:"Trust/ Foundations", value: "TrustFoundations"},{id: 6,name:"NGO/ Charities / Places of Worship", value: "NGO"},{id: 7,name:"Clubs and Societies",value: "ClubsAndSocieties"},{id: 8,name:"Other Private Companies",value: "OtherPrivateCompanies"}];	
	}else if(data == "Partnership"){
	$scope.subEntity = [{id: 1,name:"Established Entity",value: "EstablishedEntity"},{id: 3,name:"Other Partnerships", value: "OtherPartnerships"}];	
	}else if(data == "UnIncorporatedBusiness"){
	$scope.subEntity = [{id: 1,name:"Established Entity",value: "EstablishedEntity"},{id: 2,name:"Trust / Foundations", value: "TrustFoundations"},{id: 3,name:"NGO/ Charities / Places of Worship", "value": "NGOCharitiesPlacesOfWorship"},{id: 4,name:"Clubs and Societies",value: "ClubsAndSocieties"},{id: 5,name:"Other Un Inc Business",value: "UnIncBusiness"}];	
	}else if(data == "OnRecognisedSE"){
	$scope.subEntity = [{id: 1,name:"Regulated FI",value: "RegulatedFI"},{id: 2,name:"Correspondent Bank",value: "CorrespondentBank"},{id: 3,name:"Money Service Bureau", value: "MoneyServiceBureau"},{id: 4,name:"Trusts / Foundations",value: "TrustsFoundations"},{id: 5,name:"Widely Held (>50% held with Public)", value: "50HeldWithPublic"},{id: 6,name:"Not Widely held (< 50% held with Public)", value: "50HeldWithPublic"}];	
	}else if(data == "NotOnRecognisedSE"){
	$scope.subEntity = [{id: 1,name:"Regulated FI", value: "RegulatedFI"},{id: 2,name:"Correspondent Bank", value: "CorrespondentBank"},{id: 3,name:"Money Service Bureau", value: "MoneyServiceBureau"},{id: 4,name:"Trusts / Foundations", value: "TrustsFoundations"},{id: 5,name:"Publicly Quoted", value: "PubliclyQuoted"}];	
	}else if(data == "Government"){
	$scope.subEntity = [{id: 1,name:"Gov Ministries / Dept / Agencies", value: "GovMinistriesDeptAgencies"}];	
	}else if(data == "PublicSectorBodies"){
	$scope.subEntity = [{id: 1,name:"Public Sector Bodies", value: "PublicSectorBodies"}];	
	}else if(data == "StatutoryCorporations"){
	$scope.subEntity = [{id: 1,name:"Correspondent Bank", value: "CorrespondentBank"},{id: 2,name:"Money Service Bureau", value: "MoneyServiceBureau"},{id: 3,name:"Trust / Foundations", value: "TrustFoundations"},{id: 4,name:"Regulated FI",value: "RegulatedFI"},{id: 5,name:"Other Statutory Corporations",value: "OtherStatutoryCorporations"}];	
	}else if(data == "StateOwnedCorporations"){
	$scope.subEntity = [{id: 1,name:"Correspondent Bank",value: "CorrespondentBank"},{id: 2,name:"Trust / Foundations", value: "TrustFoundations"},{id: 3,name:"Other State owned Corporations",value: "OtherStateOwnedCorporations"}];	
	}else if(data == "CentralBanks"){
	$scope.subEntity = [{id: 1,name:"Central Banks", value: "CentralBanks"}];	
	}else if(data == "SupraNationals"){
	$scope.subEntity = [{id: 1,name:"Supra Nationals and Dev Org", value: "SupraNationals"}];	
	}
	}
	
	if($scope.entityType1){
	  $scope.entityFn($scope.entityType1);	
	}
	
	$scope.subEntityFn = function(data){
		$scope.entitySpecificFlag = data;
	}
	
	if($scope.subentitytype){
	  $scope.subEntityFn($scope.subentitytype);	
	}
	

	$timeout(function(){
	$scope.countryDropdown = Country.data;
	},2000);
	$scope.countryFieldFn = function(data){
	  $scope.countryValue = Country.data;
	  for (var i in $scope.countryValue){
	    if($scope.countryValue[i].Value == data){
		$scope.riskValue = $scope.countryValue[i].Risk;
		}
	  }	
	}
	
	//$scope.selecteddropdown = $scope.countryDropdown[1];
	
	$scope.countryFieldFn1 = function(data){
	  $scope.countryValue = Country.data;
	  for (var i in $scope.countryValue){
	    if($scope.countryValue[i].Value == data){
		$scope.riskValue1 = $scope.countryValue[i].Risk;
		}
	  }	
	}
	
	$scope.countryFieldFn2 = function(data){
	  $scope.countryValue = Country.data;
	  for (var i in $scope.countryValue){
	    if($scope.countryValue[i].Value == data){
		$scope.riskValue2 = $scope.countryValue[i].Risk;
		}
	  }	
	}
	
	$scope.countryFieldFn3 = function(data){
	  $scope.countryValue = Country.data;
	  for (var i in $scope.countryValue){
	    if($scope.countryValue[i].Value == data){
		$scope.riskValue3 = $scope.countryValue[i].Risk;
		}
	  }	
	}
	
	$scope.countryFieldFn4 = function(data){
	  $scope.countryValue = Country.data;
	  for (var i in $scope.countryValue){
	    if($scope.countryValue[i].Value == data){
		$scope.riskValue4 = $scope.countryValue[i].Risk;
		}
	  }	
	}
	
	$timeout(function(){
	$scope.yearsList = [{"year":"2017"}, {"year":"2016"}, {"year":"2015"}, {"year":"2014"}, {"year":"2013"}, {"year":"2012"}, {"year":"2011"}, {"year":"2010"}, {"year":"2009"}, {"year":"2008"}, {"year":"2007"}, {"year":"2006"}, {"year":"2005"}, {"year":"2004"}, {"year":"2003"}, {"year":"2002"}, {"year":"2001"}, {"year":"2000"}];
	},2000);
	
	
	$scope.IncropDoc = [{"name":"Customer Declaration", "value": "CustomerDeclaration"}, {"name":"Customer Website", "value": "CustomerWebsite"}, {"name":"Incorporation Docs", "value": "IncorporationDocs"}, {"name":"Listing Docs", "value": "ListingDocs"}, {"name":"Public Docs", "value": "PublicDocs"}, {"name":"Public Website", "value": "PublicWebsite"},{"name": "Others", "value": "Others"}];
	
	
	$scope.incropDocFn = function(data){
	if(data == "CustomerDeclaration"){
		$timeout(function(){
	$scope.specifyDoc = [{"name" : "Customer Dec_Contact Details", "value": "CustomerDec_ContactDetails"}];
	},1000);
	} else if(data == "CustomerWebsite"){
		$timeout(function(){
	$scope.specifyDoc = [{"name" : "Off_Add_Company Website", "value": "Off_Add_CompanyWebsite"}];
    },1000);	
	} else if(data == "IncorporationDocs"){
		$timeout(function(){
	$scope.specifyDoc = [{"name" : "Certificate of Inc", "value": "CertificateofInc"}, {"name" : "Certificate of Parent Inc", "value": "CertificateofParentInc"}, {"name" : "Business Reg", "value": "BusinessReg"}, {"name" : "Business Reg Doc", "value": "BusinessRegDoc"}];	
	},1000);
	} else if(data == "ListingDocs"){
		$timeout(function(){
	$scope.specifyDoc = [{"name" : "Listing Reg doc", "value": "ListingRegdoc"}];	
	},1000);
	} else if(data == "PublicDocs"){
		$timeout(function(){
	$scope.specifyDoc = [{"name" : "Company Search Report", "value": "CompanySearchReport"}, {"name" : "Gov Website", "value": "GovWebsite"}];	
	},1000);
	} else if(data == "PublicWebsite"){
		$timeout(function(){
	$scope.specifyDoc = [{"name" : "Alias N_Pub Website", "value": "AliasN_PubWebsite"}];	
	},1000);
	} else if(data == "Others"){
		
	}
	}
	
	$scope.specifyDocFn = function(data){	
	}
	
	
	$scope.monthsDropdown = [{Name: "January"}, {Name: "February"}, {Name: "March"}, {Name: "April"}, {Name: "May"}, {Name: "June"}, {Name: "July"}, {Name: "August"}, {Name: "September"}, {Name: "October"}, {Name: "November"}, {Name: "December"}];
	
	
	$scope.nameScreening = [{id : 1, name: "Customer" , legalName :"John"}, {id : 2, name: "Beneficial Owner" , legalName :"Frank"}, {id : 3, name: "Beneficial Owner" , legalName :"Jason"}];
	
	
	$timeout(function(){
	$scope.relatedParty = [{id : 1, person : "Related Party - Individual", party : "Individual", name : "one"}, {id : 2, person : "Related Party - NonIndividual", party : "NonIndividual", name : "two"}];
	},2000);
	
	$scope.downstreamCountry = [];
		
		$scope.downstreamConFn = function(){
			if($scope.downstreamCountry.length == 10){
				return false;
			}
			$scope.downstreamCountry.push({id: $scope.downstreamCountry.length+1, name: 'country'+$scope.downstreamCountry.length+1});
		};
		
		$scope.downstreamConFn();
	

	
	
	// $scope.PepList = [{id : 1, name : "John", pep : "Yes", count : "one"}, {id : 2, name : "Jason", pep : "No", count : "two"}, {id : 3, name : "Frank", pep : "Yes", count : "three"}];
	

	$scope.sanctionsList = [{id : 1, name: "John", type : "Individual", addRisk : "Yes", count : "one"}/* , {id : 2, name: "Frank", type : "NonIndividual", addRisk : "No", count : "two"} */];

	$scope.PepList = [{id : 1, name : "John", pep : "Yes", count : "one"}];

	$scope.adverseList = [{id : 1, name : "John", type : "Individual", adverseRisk : "yes", count : "one"}];
	
	// $scope.adverseRiskAry = [];
	
	// $scope.addAdverse = function(){
	// $scope.adverseRiskAry.push({id : $scope.adverseRiskAry.length+1, model1 : "mandatoryForm3.step3[al.count + '20']", model2 : "mandatoryForm3.step3[al.count + '21']", name1 : "al.count + '20'"+$scope.productInfoAry.length+1, name2 : "al.count + '21'"+$scope.productInfoAry.length+1})	
	// }
	
	// $scope.addAdverse();
	
	
	$scope.riskAssessment = [{id : 1, name : "John", type : "Individual", adverseRisk : "yes", count : "one"}, {id : 2, name : "John", type : "NonIndividual", adverseRisk : "no", count : "two"}];
	
	
	
	
	$scope.generateDocFlag = false;
	$scope.generateDoclistFlag = false;
	$scope.generateDoclistFlag = true;
	$scope.generateDoc = function(){
	$scope.generateDocFlag = true;
	$scope.generateDoclistFlag = true;
    $scope.showDocumentFlag1 = true;	
	}
	
	$scope.showDocumentFlag1 = false;
	$scope.showDocumentFlag2 = false;
	$scope.showDocumentFlag3 = false;
	$scope.showDocumentFlag4 = false;
	
    $scope.showDocFn1 = function(){
	if($scope.generateDocFlag == true){
	$scope.showDocumentFlag1 = true;
	$scope.showDocumentFlag2 = false;
	$scope.showDocumentFlag3 = false;
	$scope.showDocumentFlag4 = false;	
	}
	}
	
	$scope.showDocFn2 = function(){
	if($scope.generateDocFlag == true){
	$scope.showDocumentFlag1 = false;
	$scope.showDocumentFlag2 = true;
	$scope.showDocumentFlag3 = false;
	$scope.showDocumentFlag4 = false;	
	}
	}
	
	$scope.showDocFn3 = function(){
	if($scope.generateDocFlag == true){
	$scope.showDocumentFlag1 = false;
	$scope.showDocumentFlag2 = false;
	$scope.showDocumentFlag3 = true;
	$scope.showDocumentFlag4 = false;	
	}
	}
	
	$scope.showDocFn4 = function(){
	if($scope.generateDocFlag == true){
	$scope.showDocumentFlag1 = false;
	$scope.showDocumentFlag2 = false;
	$scope.showDocumentFlag3 = false;
	$scope.showDocumentFlag4 = true;	
	}
	}
	$scope.graph_cancel = function(){
	$scope.graphsecFlag = false;
	}
	


$scope.decisionForm2customername = "Nexus Bank";
$scope.decisionForm2Ownershiptype = "Privately Owned";
$scope.decisionForm2EntityType = "Private Company";
$scope.decisionForm2SubCliententitytype = "Regulated FI";
$scope.decisionForm2RiskRating = "High";
$scope.decisionForm2CountrieofDueDiligence = "US";


$('.hideSideNavBtn4').show();
$('.hideSideNavBtn5').show(); 
$('.hideSideNavBtn6').show(); 

$timeout(function(){
		if(localStorage.sidenavShowFlag == "redFlag"){
		$('.hideSideNavBtn1').show();
		$('.hideSideNavBtn2').hide();
		$('.hideSideNavBtn3').hide();		
		}else if(localStorage.sidenavShowFlag == "periodic"){
		$('.hideSideNavBtn1').hide();
		$('.hideSideNavBtn2').show();
		$('.hideSideNavBtn3').hide();
		}else if(localStorage.sidenavShowFlag == "trigger"){
		$('.hideSideNavBtn1').hide();
		$('.hideSideNavBtn2').hide();
		$('.hideSideNavBtn3').show();	
		}
		},2000);
		

$scope.showDefaultImage1 = false;	
$scope.showSelectedImage1 = true;
$scope.showDefaultImage2 = true;	
$scope.showSelectedImage2 = false;	
$scope.showDefaultImage3 = true;	
$scope.showSelectedImage3 = false;
$scope.showDefaultImage4 = true;	
$scope.showSelectedImage4 = false;
$scope.showDefaultImage5 = true;	
$scope.showSelectedImage5 = false;
$scope.showDefaultImage6 = true;	
$scope.showSelectedImage6 = false;
$scope.showDefaultImage7 = true;	
$scope.showSelectedImage7 = false;
$scope.showDefaultImage8 = true;	
$scope.showSelectedImage8 = false;
$('#showSelectedTxt1').addClass('menu_icon_color');	
$scope.menuIconFn1 = function(){
localStorage.tabvalue = "Customer Information Program";
$scope.namescreen_tablesec = false;
$scope.dedube_tablesec = false;
$scope.menumaskflag = false;
	/* $('#showSelectedTxt1').addClass('menu_icon_color');
	$('#showSelectedTxt2').removeClass('menu_icon_color');
	$('#showSelectedTxt3').removeClass('menu_icon_color');
	$('#showSelectedTxt4').removeClass('menu_icon_color');
	$('#showSelectedTxt5').removeClass('menu_icon_color');
	$('#showSelectedTxt6').removeClass('menu_icon_color');
	$('#showSelectedTxt7').removeClass('menu_icon_color');
	$('#showSelectedTxt8').removeClass('menu_icon_color');
$scope.showDefaultImage1 = false;	
$scope.showSelectedImage1 = true;
$scope.showDefaultImage2 = true;	
$scope.showSelectedImage2 = false;	
$scope.showDefaultImage3 = true;	
$scope.showSelectedImage3 = false;
$scope.showDefaultImage4 = true;	
$scope.showSelectedImage4 = false;
$scope.showDefaultImage5 = true;	
$scope.showSelectedImage5 = false;
$scope.showDefaultImage6 = true;	
$scope.showSelectedImage6 = false;
$scope.showDefaultImage7 = true;	
$scope.showSelectedImage7 = false;
$scope.showDefaultImage8 = true;	
$scope.showSelectedImage8 = false; */
}
$scope.menuIconFn2 = function(){

localStorage.tabvalue = "Standard Due Diligence - A";
$scope.namescreen_tablesec = false;
$scope.dedube_tablesec = false;
	/* $('#showSelectedTxt1').removeClass('menu_icon_color');
	$('#showSelectedTxt2').addClass('menu_icon_color');
	$('#showSelectedTxt3').removeClass('menu_icon_color');
	$('#showSelectedTxt4').removeClass('menu_icon_color');
	$('#showSelectedTxt5').removeClass('menu_icon_color');
	$('#showSelectedTxt6').removeClass('menu_icon_color');
	$('#showSelectedTxt7').removeClass('menu_icon_color');
	$('#showSelectedTxt8').removeClass('menu_icon_color');
$scope.showDefaultImage1 = true;	
$scope.showSelectedImage1 = false;
$scope.showDefaultImage2 = false;	
$scope.showSelectedImage2 = true;	
$scope.showDefaultImage3 = true;	
$scope.showSelectedImage3 = false;
$scope.showDefaultImage4 = true;	
$scope.showSelectedImage4 = false;
$scope.showDefaultImage5 = true;	
$scope.showSelectedImage5 = false;
$scope.showDefaultImage6 = true;	
$scope.showSelectedImage6 = false;
$scope.showDefaultImage7 = true;	
$scope.showSelectedImage7 = false;
$scope.showDefaultImage8 = true;	
$scope.showSelectedImage8 = false;	 */
}
$scope.menuIconFn3 = function(){
localStorage.tabvalue = "Specialised Due Diligence";
$scope.namescreen_tablesec = false;
$scope.dedube_tablesec = false;
		/* $('#showSelectedTxt1').removeClass('menu_icon_color');
	$('#showSelectedTxt2').removeClass('menu_icon_color');
	$('#showSelectedTxt3').addClass('menu_icon_color');
	$('#showSelectedTxt4').removeClass('menu_icon_color');
	$('#showSelectedTxt5').removeClass('menu_icon_color');
	$('#showSelectedTxt6').removeClass('menu_icon_color');
	$('#showSelectedTxt7').removeClass('menu_icon_color');
	$('#showSelectedTxt8').removeClass('menu_icon_color');
$scope.showDefaultImage1 = true;	
$scope.showSelectedImage1 = false;
$scope.showDefaultImage2 = true;	
$scope.showSelectedImage2 = false;	
$scope.showDefaultImage3 = false;	
$scope.showSelectedImage3 = true;
$scope.showDefaultImage4 = true;	
$scope.showSelectedImage4 = false;
$scope.showDefaultImage5 = true;	
$scope.showSelectedImage5 = false;
$scope.showDefaultImage6 = true;	
$scope.showSelectedImage6 = false;
$scope.showDefaultImage7 = true;	
$scope.showSelectedImage7 = false;
$scope.showDefaultImage8 = true;	
$scope.showSelectedImage8 = false;	 */
}
$scope.menuIconFn4 = function(){
localStorage.tabvalue = "Local Due Diligence";
$scope.namescreen_tablesec = false;
$scope.dedube_tablesec = false;
		/* $('#showSelectedTxt1').removeClass('menu_icon_color');
	$('#showSelectedTxt2').removeClass('menu_icon_color');
	$('#showSelectedTxt3').removeClass('menu_icon_color');
	$('#showSelectedTxt4').addClass('menu_icon_color');
	$('#showSelectedTxt5').removeClass('menu_icon_color');
	$('#showSelectedTxt6').removeClass('menu_icon_color');
	$('#showSelectedTxt7').removeClass('menu_icon_color');
	$('#showSelectedTxt8').removeClass('menu_icon_color');
$scope.showDefaultImage1 = true;	
$scope.showSelectedImage1 = false;
$scope.showDefaultImage2 = true;	
$scope.showSelectedImage2 = false;	
$scope.showDefaultImage3 = true;	
$scope.showSelectedImage3 = false;
$scope.showDefaultImage4 = false;	
$scope.showSelectedImage4 = true;
$scope.showDefaultImage5 = true;	
$scope.showSelectedImage5 = false;
$scope.showDefaultImage6 = true;	
$scope.showSelectedImage6 = false;
$scope.showDefaultImage7 = true;	
$scope.showSelectedImage7 = false;
$scope.showDefaultImage8 = true;	
$scope.showSelectedImage8 = false;	 */
}
$scope.menuIconFn5 = function(){
localStorage.tabvalue = "Enhanced Due Diligence";
$scope.namescreen_tablesec = false;
$scope.dedube_tablesec = false;
		/* $('#showSelectedTxt1').removeClass('menu_icon_color');
	$('#showSelectedTxt2').removeClass('menu_icon_color');
	$('#showSelectedTxt3').removeClass('menu_icon_color');
	$('#showSelectedTxt4').removeClass('menu_icon_color');
	$('#showSelectedTxt5').addClass('menu_icon_color');
	$('#showSelectedTxt6').removeClass('menu_icon_color');
	$('#showSelectedTxt7').removeClass('menu_icon_color');
	$('#showSelectedTxt8').removeClass('menu_icon_color');
$scope.showDefaultImage1 = true;	
$scope.showSelectedImage1 = false;
$scope.showDefaultImage2 = true;	
$scope.showSelectedImage2 = false;	
$scope.showDefaultImage3 = true;	
$scope.showSelectedImage3 = false;
$scope.showDefaultImage4 = true;	
$scope.showSelectedImage4 = false;
$scope.showDefaultImage5 = false;	
$scope.showSelectedImage5 = true;
$scope.showDefaultImage6 = true;	
$scope.showSelectedImage6 = false;
$scope.showDefaultImage7 = true;	
$scope.showSelectedImage7 = false;
$scope.showDefaultImage8 = true;	
$scope.showSelectedImage8 = false;	 */
}
$scope.menuIconFn6 = function(){
localStorage.tabvalue = "Standard Due Diligence - B";
$scope.namescreen_tablesec = false;
$scope.dedube_tablesec = false;
		/* $('#showSelectedTxt1').removeClass('menu_icon_color');
	$('#showSelectedTxt2').removeClass('menu_icon_color');
	$('#showSelectedTxt3').removeClass('menu_icon_color');
	$('#showSelectedTxt4').removeClass('menu_icon_color');
	$('#showSelectedTxt5').removeClass('menu_icon_color');
	$('#showSelectedTxt6').addClass('menu_icon_color');
	$('#showSelectedTxt7').removeClass('menu_icon_color');
	$('#showSelectedTxt8').removeClass('menu_icon_color');
$scope.showDefaultImage1 = true;	
$scope.showSelectedImage1 = false;
$scope.showDefaultImage2 = true;	
$scope.showSelectedImage2 = false;	
$scope.showDefaultImage3 = true;	
$scope.showSelectedImage3 = false;
$scope.showDefaultImage4 = true;	
$scope.showSelectedImage4 = false;
$scope.showDefaultImage5 = true;	
$scope.showSelectedImage5 = false;
$scope.showDefaultImage6 = false;	
$scope.showSelectedImage6 = true;
$scope.showDefaultImage7 = true;	
$scope.showSelectedImage7 = false;
$scope.showDefaultImage8 = true;	
$scope.showSelectedImage8 = false;	 */
}
$scope.menuIconFn7 = function(){
localStorage.tabvalue = "Mandatory Due diligence";
$scope.namescreen_tablesec = false;
$scope.dedube_tablesec = false;
		/* $('#showSelectedTxt1').removeClass('menu_icon_color');
	$('#showSelectedTxt2').removeClass('menu_icon_color');
	$('#showSelectedTxt3').removeClass('menu_icon_color');
	$('#showSelectedTxt4').removeClass('menu_icon_color');
	$('#showSelectedTxt5').removeClass('menu_icon_color');
	$('#showSelectedTxt6').removeClass('menu_icon_color');
	$('#showSelectedTxt7').addClass('menu_icon_color');
	$('#showSelectedTxt8').removeClass('menu_icon_color');
$scope.showDefaultImage1 = true;	
$scope.showSelectedImage1 = false;
$scope.showDefaultImage2 = true;	
$scope.showSelectedImage2 = false;	
$scope.showDefaultImage3 = true;	
$scope.showSelectedImage3 = false;
$scope.showDefaultImage4 = true;	
$scope.showSelectedImage4 = false;
$scope.showDefaultImage5 = true;	
$scope.showSelectedImage5 = false;
$scope.showDefaultImage6 = true;	
$scope.showSelectedImage6 = false;
$scope.showDefaultImage7 = false;	
$scope.showSelectedImage7 = true;
$scope.showDefaultImage8 = true;	
$scope.showSelectedImage8 = false;	 */
}
$scope.menuIconFn8 = function(){
localStorage.tabvalue = "Decisioning";
$scope.namescreen_tablesec = false;
$scope.dedube_tablesec = false;
		/* $('#showSelectedTxt1').removeClass('menu_icon_color');
	$('#showSelectedTxt2').removeClass('menu_icon_color');
	$('#showSelectedTxt3').removeClass('menu_icon_color');
	$('#showSelectedTxt4').removeClass('menu_icon_color');
	$('#showSelectedTxt5').removeClass('menu_icon_color');
	$('#showSelectedTxt6').removeClass('menu_icon_color');
	$('#showSelectedTxt7').removeClass('menu_icon_color');
	$('#showSelectedTxt8').addClass('menu_icon_color');
$scope.showDefaultImage1 = true;	
$scope.showSelectedImage1 = false;
$scope.showDefaultImage2 = true;	
$scope.showSelectedImage2 = false;	
$scope.showDefaultImage3 = true;	
$scope.showSelectedImage3 = false;
$scope.showDefaultImage4 = true;	
$scope.showSelectedImage4 = false;
$scope.showDefaultImage5 = true;	
$scope.showSelectedImage5 = false;
$scope.showDefaultImage6 = true;	
$scope.showSelectedImage6 = false;
$scope.showDefaultImage7 = true;	
$scope.showSelectedImage7 = false;
$scope.showDefaultImage8 = false;	
$scope.showSelectedImage8 = true;	 */
}
$scope.showtableMatch=[];
$scope.tableMatchData=[];

$scope.dataMatch = function(data, status){
debugger;
$scope.showtableMatch[data] = true;
if(status == "yes"){
	$scope.tableMatchData[data]="Match";
}
else if(status == "no"){

	$scope.tableMatchData[data]="No Match"
}
}

$scope.changeOnNegative=function(MatchTerm2b_value){;
	$scope.applyRedBG=false;
if(MatchTerm2b_value=="Onboard"){
	$scope.applyRedBG=true;
}
}
// $scope.potentialMatch = function(data, status){
	// $scope.CustomerApplicationInfostep6appId = "125647";
// if(data == 1 && status == false){
      // $scope.CustomerApplicationInfstep3name = "Frank";
	  // $scope.CustomerApplicationInfostep3aliasName = "Dennis";
	  // $scope.CustomerApplicationInfostep3address1 = "4505 S. Maryland Parkway";
	  // $scope.countryField = "Las Vegas";
	  // $scope.CustomerApplicationInfostep3pincodeinfo = "89101";
	  // $scope.Dateofincorporation = "24-May-1980";
	  // $scope.CustomerApplicationInfostep3regNumber = "534543";
// }else if(data == 2  && status == false){	
	  // $scope.CustomerApplicationInfstep3name = "John";
	  // $scope.CustomerApplicationInfostep3aliasName = "Carter";
	  // $scope.CustomerApplicationInfostep3address1 = "4505 S. Maryland Parkway";
	  // $scope.countryField = "US";
	  // $scope.CustomerApplicationInfostep3pincodeinfo = "89101";
	  // $scope.Dateofincorporation = "24-May-1980";
	  // $scope.CustomerApplicationInfostep3regNumber = "534543";
// }else if(data == 3  && status == false){
	  // $scope.CustomerApplicationInfstep3name = "Jason";
	  // $scope.CustomerApplicationInfostep3aliasName = "Vin";
	  // $scope.CustomerApplicationInfostep3address1 = "4505 S. Maryland Parkway";
	  // $scope.countryField = "Singapore";
	  // $scope.CustomerApplicationInfostep3pincodeinfo = "89101";
	  // $scope.Dateofincorporation = "24-May-1980";
	  // $scope.CustomerApplicationInfostep3regNumber = "534543";
	  
	
// }else if(status == true){
	  // $scope.CustomerApplicationInfostep6appId = "";
      // $scope.CustomerApplicationInfstep3name = "";
	  // $scope.CustomerApplicationInfostep3aliasName = "";
	  // $scope.CustomerApplicationInfostep3address1 = "";
	  // $scope.countryField = "";
	  // $scope.CustomerApplicationInfostep3pincodeinfo = "";
	  // $scope.Dateofincorporation = "";
	  // $scope.CustomerApplicationInfostep3regNumber = "";	
// }
// }

$scope.showProductInfoGraph = false;
$scope.showProductGraph = function(){
	$scope.showProductInfoGraph = true;
}
$scope.customerinfotable = function(){
	$scope.customerinfodedupe = true;
	$scope.customernewflag=true;
	$("#dedupe_popup").hide();
}
$scope.relatedinfotable = function(){
	$scope.relatedinfodedupe = true;
	$scope.relatednewflag=true;
	$("#dedupe_popup").hide();
}

$scope.relatednonindtable = function(){
	
	$scope.relatedinfodedupe = true;
	$scope.relatednewflag=true;
	$("#dedupe_popup").hide();
}
$scope.relatednondedupe = function(){
$scope.dedupepopup();
$scope.showDedupeConFlag1 = true;
$scope.showrelatedMatchFlag1 = false;
$scope.shownonrelatedMatchFlag1 = false;
$scope.showDedupeConFlag2 = false;
$scope.showPotentialMatchFlag = false;
vm.potentials = Potential.data;
$scope.showPercentageFlag = true;
$scope.showPotentialMatchFlag1 = false;
$timeout(function(){
 $mdDialog.hide();
$("#showLoader").hide();            
$("#dedupe_popup").hide(); 
$scope.dedupebtnshow = true;

$scope.shownonrelatedMatchFlag1 = true;
$scope.shownonrelatedMatchFlag2 = false;
$scope.shownonrelatedMatchFlag3 = false;
},10000);
}
$scope.relatednondedupe1 = function(){
$scope.dedupepopup();
$scope.showDedupeConFlag1 = true;
$scope.showrelatedMatchFlag1 = false;
$scope.shownonrelatedMatchFlag1 = false;
$scope.showDedupeConFlag2 = false;
$scope.showPotentialMatchFlag = false;
vm.potentials = Potential.data;
$scope.showPercentageFlag = true;
$scope.showPotentialMatchFlag1 = false;
$timeout(function(){
 $mdDialog.hide();
$("#showLoader").hide();            
$("#dedupe_popup").hide(); 
$scope.dedupebtnshow = true;

$scope.shownonrelatedMatchFlag2 = true;
$scope.shownonrelatedMatchFlag1 = false;
$scope.shownonrelatedMatchFlag3 = false;
},10000);
}
$scope.relatednondedupe2 = function(){
$scope.dedupepopup();
$scope.showDedupeConFlag1 = true;
$scope.showrelatedMatchFlag1 = false;
$scope.shownonrelatedMatchFlag1 = false;
$scope.showDedupeConFlag2 = false;
$scope.showPotentialMatchFlag = false;
vm.potentials = Potential.data;
$scope.showPercentageFlag = true;
$scope.showPotentialMatchFlag1 = false;
$timeout(function(){
 $mdDialog.hide();
$("#showLoader").hide();            
$("#dedupe_popup").hide(); 
$scope.dedupebtnshow = true;

$scope.shownonrelatedMatchFlag3 = true;
$scope.shownonrelatedMatchFlag1 = false;
$scope.shownonrelatedMatchFlag2 = false;
},10000);
}


$scope.showPopover=false;
$scope.showPopover1=false;

 /* $scope.popover = {
        title: 'Title',
        message: 'Message'
    };  */
   

// $scope.customerinfoFlag = 1; 
// $scope.fncus = function(data){
// $scope.customerinfoFlag = data; 
// $scope.scrollTopFn();
// }
$scope.showdedupe_table=function(data){
debugger
$scope.tableName = data.CusId;
$scope.tableName1 = data.CusName;
$scope.tableName2 = data.Cusalias;
$scope.tableownership = data.Ownershiptype;
$scope.tableentity = data.EntityType;
$scope.tablesubclient = data.SubCliententitytype;
$scope.tablesegment = data.BusinessSegment;
$scope.tablereg = data.Registeredaddress;
$scope.tableCountry = data.Country;
$scope.tablePin = data.PINCode;
$scope.tableIncorp = data.Dateofincorporation;
$scope.tableRegnumb = data.RegistrationNumber;
$scope.tableOfficecontact = data.OfficeContactNumbers;
$scope.tableCip = data.CountryofIncorporation;
$scope.tableBookingloc = data.PrimaryBookingLocation;
$scope.tableAddBookingloc = data.AdditionalBookingLocation;
$scope.tablePeriodic = data.Dateofperiodic;
$scope.tableFilestatus = data.Filestatus;
/* $scope.tableName = data.CusName;
  $scope.isic = ISIC.data;  */
$scope.menumaskflag = true;
$scope.dedube_tablesec=true;
}
$scope.showdedupe_table1=function(data){
debugger
//$scope.vmCustomerApplicationInfostep7OfficeAddress2 = "value";
$scope.tableheadval = data.tablehead;
$scope.tableName = data.CusId;
$scope.tableName1 = data.CusName;
$scope.tableName2 = data.Cusalias;
$scope.tableownership = data.Ownershiptype;
$scope.tableentity = data.EntityType;
$scope.tablesubclient = data.SubCliententitytype;
$scope.tablesegment = data.BusinessSegment;
$scope.tablereg = data.Registeredaddress;
$scope.tableCountry = data.Country;
$scope.tablePin = data.PINCode;
$scope.tableIncorp = data.Dateofincorporation;
$scope.tableRegnumb = data.RegistrationNumber;
$scope.tableOfficecontact = data.OfficeContactNumbers;
$scope.tableCip = data.CountryofIncorporation;
$scope.tableBookingloc = data.PrimaryBookingLocation;
$scope.tableAddBookingloc = data.AdditionalBookingLocation;
$scope.tablePeriodic = data.Dateofperiodic;
$scope.tableFilestatus = data.Filestatus;
$scope.relregnumb = data.RegisteredIDNumber;
/* $scope.tableName = data.CusName;
  $scope.isic = ISIC.data;  */
  $scope.dedube_tablesec1=true;
  $scope.dedube_tablesec2=false;
  if(data.Regnumb == "X2121" || data.Regnumb == "X7521" || data.Regnumb == "7272B"){    
  debugger
  $scope.menumaskflag = true;
$scope.dedube_tablesec1=false;
$scope.dedube_tablesec2=true;
  }
$scope.menumaskflag = true;


}

$scope.showdedupe_table2=function(data){
$scope.tableheadval = data.tablehead;
$scope.tableName = data.CusId;
$scope.tableName1 = data.CusName;
$scope.tableName2 = data.Cusalias;
$scope.tableownership = data.Ownershiptype;
$scope.tableentity = data.EntityType;
$scope.tablesubclient = data.SubCliententitytype;
$scope.tablesegment = data.BusinessSegment;
$scope.tablereg = data.Registeredaddress;
$scope.tableCountry = data.Country;
$scope.tablePin = data.PINCode;  
$scope.tableIncorp = data.Dateofincorporation;
$scope.tableRegnumb = data.RegistrationNumber;
$scope.tableOfficecontact = data.OfficeContactNumbers;
$scope.tableCip = data.CountryofIncorporation;
$scope.tableBookingloc = data.PrimaryBookingLocation;
$scope.tableAddBookingloc = data.AdditionalBookingLocation;
$scope.tablePeriodic = data.Dateofperiodic;
$scope.tableFilestatus = data.Filestatus;
$scope.dedube_tablesec1=true;
$scope.dedube_tablesec2=false;
  if(data.Regnumb == "X2121" || data.Regnumb == "X7521" || data.Regnumb == "7272B"){    
  $scope.menumaskflag = true;
$scope.dedube_tablesec1=false;
$scope.dedube_tablesec2=true;
  }
$scope.menumaskflag = true;

$scope.tableResolutionComment = data.ResolutionComment;

}

$scope.dedube_tablesec1=false;
$scope.namescreen_tablesec=false;
$scope.dedube_tablesec=false;
$scope.dedube_tablesec2=false;
		 
$scope.showAssessmentDet=function(data){
debugger;

$scope.tableNamescreenid = data.id;
$scope.tableNamescreen = data.BankName;
$scope.tableName2 = data.Match;
$scope.tableownership = data.MatchTerm1;
$scope.tableentity = data.MatchTerm2;
$scope.tablesubclient = data.MatchTerm3;
$scope.tablesegment = data.BusinessSegment;
$scope.tablereg = data.Registeredaddress;
$scope.tableCountry = data.Country;
$scope.tablePin = data.PINCode;
$scope.tableIncorp = data.Dateofincorporation;
$scope.tableRegnumb = data.RegistrationNumber;
$scope.tableOfficecontact = data.OfficeContactNumbers;
$scope.tableCip = data.CountryofIncorporation;
$scope.tableBookingloc = data.PrimaryBookingLocation;
$scope.tableAddBookingloc = data.AdditionalBookingLocation;
$scope.tablePeriodic = data.Dateofperiodic;
$scope.tableFilestatus = data.Filestatus;
$scope.tableMatch= data.Match;
$scope.tableIndex= data.index;
// $scope.tablesegment = data.BusinessSegment;
// $scope.tablereg = data.Registeredaddress;
// $scope.tableCountry = data.Country;
// $scope.tablePin = data.PINCode;
// $scope.tableIncorp = data.Dateofincorporation;
// $scope.tableRegnumb = data.RegistrationNumber;
// $scope.tableOfficecontact = data.OfficeContactNumbers;
// $scope.tableCip = data.CountryofIncorporation;
// $scope.tableBookingloc = data.PrimaryBookingLocation;
// $scope.tableAddBookingloc = data.AdditionalBookingLocation;
// $scope.tablePeriodic = data.Dateofperiodic;
// $scope.tableFilestatus = data.Filestatus;

/* $scope.tableName = data.CusName;
  $scope.isic = ISIC.data;  */
$scope.menumaskflag = true;
$scope.namescreen_tablesec=true;
$scope.namescreening_match=false;

}
 $scope.max = 5;
  $scope.selectedIndex = 0;
  $scope.nextTab = function() {
  debugger
   var index = ($scope.selectedIndex == $scope.max) ? 0 : $scope.selectedIndex + 1;
    $scope.selectedIndex = index;

  };
  $scope.scrollTopFn = function(id) {
    $location.hash(id);
    $anchorScroll();
  };
$scope.nextconfigTab = function(){
	$location.path('/dashboard');
}
  $scope.answer = 3; 
  //$scope.score = 0;
   $scope.selectedindexval = -1;
 
        $scope.isGrey = [];
		$scope.isGrey1 = [];
		$scope.isGrey2= [];
		$scope.isGrey3= [];
		$scope.isGrey4= [];
		$scope.isGrey5= [];
		$scope.isGrey6= [];
		$scope.isGrey7= [];
		$scope.isGrey8= [];
		$scope.isGrey9= [];
		$scope.isGrey10= [];
		$scope.isGrey11= [];
		$scope.isGrey12= [];
		$scope.isGrey13= [];
		$scope.isGrey14= [];
		$scope.isGrey15= [];
		$scope.isGrey16= [];
		$scope.isGrey17= [];
		$scope.isGrey18= [];
		$scope.isGrey19= [];
		$scope.isGrey20= [];
		$scope.isGrey21= [];
		$scope.isGrey22= [];
		$scope.isGrey23= [];
		$scope.isGrey24= [];
		$scope.isGrey25= [];
		$scope.isGrey26= [];
		$scope.isGrey27= [];
		$scope.isGrey28= [];
		$scope.isGrey29= [];  
		$scope.isGrey30= [];
		$scope.isGrey31= [];
		$scope.isGrey32= [];
		$scope.isGrey33= [];
		$scope.isGrey34= [];
		$scope.isGrey35= [];
		$scope.isGrey36= [];
		$scope.isGrey1a = [];
		$scope.isGrey2a= [];
		$scope.isGrey3a= [];
		$scope.isGrey4a= [];
		$scope.isGrey5a= [];
		$scope.isGrey6a= [];
		$scope.isGrey7a= [];
		$scope.isGrey8a= [];
		$scope.isGrey9a= [];
		$scope.isGrey10a= [];
		$scope.isGrey11a= [];
		$scope.isGrey12a= [];
		$scope.isGrey13a= [];
		$scope.isGrey14a= [];
		$scope.isGrey15a= [];
		$scope.isGrey16a= [];
		$scope.isGrey17a= [];
		$scope.isGrey18a= [];
		$scope.isGrey19a= [];
		$scope.isGrey20a= [];
		$scope.isGrey21a= [];
		$scope.isGrey22a= [];
		$scope.isGrey23a= [];
		$scope.isGrey24a= [];
		$scope.isGrey25a= [];
		$scope.isGrey26a= [];
		$scope.isGrey27a= [];
		$scope.isGrey28a= [];
		$scope.isGrey29a= [];  
		$scope.isGrey30a= [];
		$scope.isGrey31a= [];
		$scope.isGrey32a= [];
		$scope.isGrey33a= [];
		$scope.isGrey34a= [];
		$scope.isGrey35a= [];
		$scope.isGrey36a= [];
		$scope.isGrey6b= [];
        $scope.toggleClass = function (id) {$scope.isGrey[id] = $scope.isGrey[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass1 = function (id) {$scope.isGrey1[id] = $scope.isGrey1[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass2 = function (id) {$scope.isGrey2[id] = $scope.isGrey2[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass3 = function (id) {$scope.isGrey3[id] = $scope.isGrey3[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
       $scope.toggleClass4 = function (id) {$scope.isGrey4[id] = $scope.isGrey4[id]=='doc_greentickicon'?'':'doc_greentickicon'};
        $scope.toggleClass5 = function (id) {$scope.isGrey5[id] = $scope.isGrey5[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass6 = function (id) {$scope.isGrey6[id] = $scope.isGrey6[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass7 = function (id) {$scope.isGrey7[id] = $scope.isGrey7[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass8 = function (id) {$scope.isGrey8[id] = $scope.isGrey8[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass9 = function (id) {$scope.isGrey9[id] = $scope.isGrey9[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass10 = function (id) {$scope.isGrey10[id] = $scope.isGrey10[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass11 = function (id) {$scope.isGrey11[id] = $scope.isGrey11[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass12 = function (id) {$scope.isGrey12[id] = $scope.isGrey12[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass13 = function (id) {$scope.isGrey13[id] = $scope.isGrey13[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass14 = function (id) {$scope.isGrey14[id] = $scope.isGrey14[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass15 = function (id) {$scope.isGrey15[id] = $scope.isGrey15[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass16 = function (id) {$scope.isGrey16[id] = $scope.isGrey16[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass17 = function (id) {$scope.isGrey17[id] = $scope.isGrey17[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass18 = function (id) {$scope.isGrey18[id] = $scope.isGrey18[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass19 = function (id) {$scope.isGrey19[id] = $scope.isGrey19[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass20 = function (id) {$scope.isGrey20[id] = $scope.isGrey20[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass21 = function (id) {$scope.isGrey21[id] = $scope.isGrey21[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass22 = function (id) {$scope.isGrey22[id] = $scope.isGrey22[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass23 = function (id) {$scope.isGrey23[id] = $scope.isGrey23[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass24 = function (id) {$scope.isGrey24[id] = $scope.isGrey24[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass25 = function (id) {$scope.isGrey25[id] = $scope.isGrey25[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass26 = function (id) {$scope.isGrey26[id] = $scope.isGrey26[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass27 = function (id) {$scope.isGrey27[id] = $scope.isGrey27[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass28 = function (id) {$scope.isGrey28[id] = $scope.isGrey28[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass29 = function (id) {$scope.isGrey29[id] = $scope.isGrey29[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass30 = function (id) {$scope.isGrey30[id] = $scope.isGrey30[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass31 = function (id) {$scope.isGrey31[id] = $scope.isGrey31[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass32 = function (id) {$scope.isGrey32[id] = $scope.isGrey32[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass33 = function (id) {$scope.isGrey33[id] = $scope.isGrey33[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass34 = function (id) {$scope.isGrey34[id] = $scope.isGrey34[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass35 = function (id) {$scope.isGrey35[id] = $scope.isGrey35[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass36 = function (id) {$scope.isGrey36[id] = $scope.isGrey36[id]=='doc_greentickicon'?'':'doc_greentickicon'; };

		$scope.toggleClassa = function (id) {$scope.isGreya[id] = $scope.isGreya[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
		$scope.toggleClass1a = function (id) {$scope.isGrey1a[id] = $scope.isGrey1a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass2a = function (id) {$scope.isGrey2a[id] = $scope.isGrey2a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass3a = function (id) {$scope.isGrey3a[id] = $scope.isGrey3a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
		 $scope.toggleClass4a = function (id,val) {$scope.isGrey4a[id] = $scope.isGrey4a[id]=='doc_greentickicon'?'':'doc_greentickicon'};
        $scope.toggleClass5a = function (id) {$scope.isGrey5a[id] = $scope.isGrey5a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass6a = function (id) {$scope.isGrey6a[id] = $scope.isGrey6a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
		$scope.toggleClass7a = function (id) {$scope.isGrey7a[id] = $scope.isGrey7[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass8a = function (id) {$scope.isGrey8a[id] = $scope.isGrey8[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass9a = function (id) {$scope.isGrey9a[id] = $scope.isGrey9[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass10a = function (id) {$scope.isGrey10a[id] = $scope.isGrey10a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass11a = function (id) {$scope.isGrey11a[id] = $scope.isGrey11a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass12a = function (id) {$scope.isGrey12a[id] = $scope.isGrey12a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass13a = function (id) {$scope.isGrey13a[id] = $scope.isGrey13a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass14a = function (id) {$scope.isGrey14a[id] = $scope.isGrey14a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass15a = function (id) {$scope.isGrey15a[id] = $scope.isGrey15a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass16a = function (id) {$scope.isGrey16a[id] = $scope.isGrey16a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass17a = function (id) {$scope.isGrey17a[id] = $scope.isGrey17a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass18a = function (id) {$scope.isGrey18a[id] = $scope.isGrey18a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass19a = function (id) {$scope.isGrey19a[id] = $scope.isGrey19a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass20a = function (id) {$scope.isGrey20a[id] = $scope.isGrey20a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass21a = function (id) {$scope.isGrey21a[id] = $scope.isGrey21a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass22a = function (id) {$scope.isGrey22a[id] = $scope.isGrey22a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass23a = function (id) {$scope.isGrey23a[id] = $scope.isGrey23a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass24a = function (id) {$scope.isGrey24a[id] = $scope.isGrey24a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass25a = function (id) {$scope.isGrey25a[id] = $scope.isGrey25a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass26a = function (id) {$scope.isGrey26a[id] = $scope.isGrey26a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass27a = function (id) {$scope.isGrey27a[id] = $scope.isGrey27a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass28a = function (id) {$scope.isGrey28a[id] = $scope.isGrey28a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass29a = function (id) {$scope.isGrey29a[id] = $scope.isGrey29a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass30a = function (id) {$scope.isGrey30a[id] = $scope.isGrey30a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass31a = function (id) {$scope.isGrey31a[id] = $scope.isGrey31a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass32a = function (id) {$scope.isGrey32a[id] = $scope.isGrey32a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass33a = function (id) {$scope.isGrey33a[id] = $scope.isGrey33a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass34a = function (id) {$scope.isGrey34a[id] = $scope.isGrey34a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass35a = function (id) {$scope.isGrey35a[id] = $scope.isGrey35a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
        $scope.toggleClass36a = function (id) {$scope.isGrey36a[id] = $scope.isGrey36a[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
		$scope.toggleClass6b = function (id) {$scope.isGrey6b[id] = $scope.isGrey6b[id]=='doc_greentickicon'?'':'doc_greentickicon'; };
$scope.selectedPeeps = []; 
$scope.verified_details=function(id){
 /* $scope.selected = item;  */
 var list = this;
  if(list.selectedPeeps[id]) {
      list.selectedPeeps[id] = true;
    } else {
      list.selectedPeeps[id] = true;
    }   
/* var myEl = angular.element( document.querySelector( '.divID' ) );
     myEl.addClass('red');     */
}
$scope.isActive = function(item) {
	       return $scope.selected === item;
	};

$scope.customerinfoFlag1 = 1; 
$scope.fncus1 = function(data){
$scope.customerinfoFlag1 = data; 
}
$scope.customerinfoFlag2 = 1; 
$scope.fncus2 = function(data){
$scope.customerinfoFlag2 = data; 
}
$scope.customerinfoFlag3 = 1; 
$scope.fncus3 = function(data){
$scope.customerinfoFlag3 = data; 
}
$scope.customerinfoFlag4 = 1; 
$scope.fncus4 = function(data){
$scope.customerinfoFlag4 = data; 
}
$scope.customerinfoFlag5 = 1; 
$scope.fncus5 = function(data){
$scope.customerinfoFlag5 = data;

}
$scope.customerinfoFlag6 = 2; 
$scope.fncus6 = function(data){
$scope.customerinfoFlag6 = data; 
}
$scope.customerinfoFlag7 = 1; 
$scope.fncus7 = function(data){
$scope.customerinfoFlag7 = data; 
}
$scope.customerinfostandardFlag = 1; 
$scope.fnstandard = function(data){
$scope.customerinfostandardFlag = data; 
}
$scope.customerinfostandardFlag1 = 1; 
$scope.fnstandard1 = function(data){
$scope.customerinfostandardFlag1 = data; 
}
$scope.EntityFlag = 1; 
$scope.fnentity1 = function(data){
$scope.EntityFlag = data; 
}

$scope.customerSpdFlag = 1; 
$scope.fnspd1 = function(data){
$scope.customerSpdFlag = data; 
}
$scope.assesmentmediaflag = false;
$scope.adversesubmitfn =function(){
$scope.assesmentmediaflag = true;
}
$scope.assesmentmediaflag1 = false;
$scope.adversesubmitfn1 =function(){
$scope.assesmentmediaflag1 = true;
}
$scope.assesmentmediaflag2 = false;
$scope.adversesubmitfn2 =function(){
$scope.assesmentmediaflag2 = true;
}
$scope.assesmentmediaflag3 = false;
$scope.adversesubmitfn3 =function(){
$scope.assesmentmediaflag3 = true;
}
$scope.assesmentmediaflag4 = false;
$scope.adversesubmitfn4 =function(){
$scope.assesmentmediaflag4 = true;
}
/* $scope.customerSpdFlag = 1; 
$scope.fnspd1 = function(data){
$scope.customerSpdFlag = data; 
} */


/* $scope.slideIndex = 1;


$scope.plusSlides = function(n)  {
  $scope.showSlides($scope.slideIndex += n);
}
$scope.currentSlide = function(n)  {
  $scope.showSlides($scope.slideIndex = n);
}


$scope.showSlides = function(n)  {
//debugger;
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {$scope.slideIndex = 1} 
  if (n < 1) {$scope.slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none"; 
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[$scope.slideIndex-1].style.display = "block"; 
  dots[$scope.slideIndex-1].className += " active";
}

$scope.showSlides($scope.slideIndex);  */

	
$scope.showdedupeDialog = function(ev) {

    $mdDialog.show({
      controller: DialogController,
      templateUrl: 'app/main/add-customer/views/manual/form/unwrappingpopup.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 $scope.showdedupeDialog1 = function(ev) {
    $mdDialog.show({
      controller: DialogController,
      templateUrl: 'app/main/add-customer/views/manual/form/unwrappingpopup1.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 $scope.showdedupeDialog2 = function(ev) {
    $mdDialog.show({
      controller: DialogController,
      templateUrl: 'app/main/add-customer/views/manual/form/unwrappingpopup2.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 
	 $scope.potentialTableFn1 = function(ev) {
		$mdDialog.show({
		  controller: PotentialController,
		  templateUrl: 'app/main/add-customer/views/manual/form/dedupeResults.html',
		  parent: angular.element(document.body),
		  targetEvent: ev,
		  clickOutsideToClose:true
		})
		vm.potentials = Potential.data;
		
		$scope.showPotentialMatchFlag1 = true;
		 };
		 
		  $scope.showaddcustomerpotential = function(ev,value) {
    $mdDialog.show({
      controller: DialogController,
      templateUrl: 'app/main/add-customer/views/manual/form/addcustomerpotential.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 $scope.graph_generate = function(ev,value) {
    $mdDialog.show({
      controller: DialogController,
      templateUrl: 'app/main/add-customer/views/manual/form/generate_graph.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 
	  $scope.notesInfo = function(ev,value) {
    $mdDialog.show({
      controller: notesController,
      templateUrl: 'app/main/add-customer/views/manual/form/notespage.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 $scope.dedupepopup = function(ev,value) {
    $mdDialog.show({
      controller: DialogController,
      templateUrl: 'app/main/add-customer/views/manual/form/dedupepopup.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:false
    })
     };

	$scope.fatcaquestionfn = function(ev,value) {
    $mdDialog.show({
      controller: fatcafirstController,
      templateUrl: 'app/main/add-customer/views/manual/form/fatcapopup1.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 $scope.fatcaquestionfn1 = function(ev,value) {
    $mdDialog.show({
      controller: fatcasecondController,
      templateUrl: 'app/main/add-customer/views/manual/form/fatcapopup2.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
   $scope.fatcaquestionfn2 = function(ev,value) {
    $mdDialog.show({
      controller: fatcathirdController,
      templateUrl: 'app/main/add-customer/views/manual/form/fatcapopup3.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 $scope.fatcaquestionfn3 = function(ev,value) {
    $mdDialog.show({
      controller: fatcafourthController,
      templateUrl: 'app/main/add-customer/views/manual/form/fatcapopup4.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
  
  function DialogController($scope, $mdDialog) {
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  }
  function fatcafourthController($scope, $mdDialog) {
  $scope.fatcasubmit = function(){
if(($scope.standardBForm2step2facta10 == "" || $scope.standardBForm2step2facta10 == undefined) && ($scope.standardBForm2step2GIIN == "" || $scope.standardBForm2step2GIIN == undefined) && ($scope.standardBForm2step2facta11 == "" || $scope.standardBForm2step2facta11 == undefined)){
$scope.progressvalue = 0;
}
else if(($scope.standardBForm2step2facta10 != "" || $scope.standardBForm2step2facta10 != undefined) && ($scope.standardBForm2step2GIIN == "" || $scope.standardBForm2step2GIIN == undefined) && ($scope.standardBForm2step2facta11 == "" || $scope.standardBForm2step2facta11 == undefined)){
$scope.progressvalue = 33;
}
else if(($scope.standardBForm2step2facta10 == "" || $scope.standardBForm2step2facta10 == undefined) && ($scope.standardBForm2step2GIIN != "" || $scope.standardBForm2step2GIIN != undefined) && ($scope.standardBForm2step2facta11 == "" || $scope.standardBForm2step2facta11 == undefined)){
$scope.progressvalue = 33;
}
else if(($scope.standardBForm2step2facta10 == "" || $scope.standardBForm2step2facta10 == undefined ) && ($scope.standardBForm2step2GIIN == "" || $scope.standardBForm2step2GIIN == undefined) && ($scope.standardBForm2step2facta11 != "" || $scope.standardBForm2step2facta11 != undefined)){
$scope.progressvalue = 33;
}
else if(($scope.standardBForm2step2facta10 != "" || $scope.standardBForm2step2facta10 != undefined) && ($scope.standardBForm2step2GIIN != "" || $scope.standardBForm2step2GIIN != undefined) && ($scope.standardBForm2step2facta11 == "" || $scope.standardBForm2step2facta11 == undefined)){
$scope.progressvalue = 66
}
else if(($scope.standardBForm2step2facta10 != "" || $scope.standardBForm2step2facta10 != undefined) && ($scope.standardBForm2step2GIIN == "" || $scope.standardBForm2step2GIIN == undefined) && ($scope.standardBForm2step2facta11 != "" || $scope.standardBForm2step2facta11 != undefined)){
$scope.progressvalue = 66
}
else if(($scope.standardBForm2step2facta10 != "" || $scope.standardBForm2step2facta10 != undefined ) && ($scope.standardBForm2step2GIIN != "" || $scope.standardBForm2step2GIIN != undefined) && ($scope.standardBForm2step2facta11 == "" || $scope.standardBForm2step2facta11 == undefined)){
$scope.progressvalue = 66
}
else if(($scope.standardBForm2step2facta10 != "" || $scope.standardBForm2step2facta10 != undefined) && ($scope.standardBForm2step2GIIN != "" || $scope.standardBForm2step2GIIN != undefined )&& ($scope.standardBForm2step2facta11 != "" || $scope.standardBForm2step2facta11 != undefined)){
$scope.progressvalue = 100
}
}
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  }
  
  
  function fatcathirdController($scope, $mdDialog) {
  $scope.fatca3submit = function(){
if(($scope.standardBForm2step2facta4 == "" || $scope.standardBForm2step2facta4 == undefined) && ($scope.standardBForm2step2facta5 == "" || $scope.standardBForm2step2facta5 == undefined) && ($scope.standardBForm2step2facta6 == "" || $scope.standardBForm2step2facta6 == undefined) && ($scope.standardBForm2step2facta7 == "" || $scope.standardBForm2step2facta7 == undefined) && ($scope.standardBForm2step2facta9 == "" || $scope.standardBForm2step2facta9 == undefined)){
$scope.progressvalue = 0;
}
else if(($scope.standardBForm2step2facta4 != "" || $scope.standardBForm2step2facta4 != undefined) && ($scope.standardBForm2step2facta5 == "" || $scope.standardBForm2step2facta5 == undefined) && ($scope.standardBForm2step2facta6 == "" || $scope.standardBForm2step2facta6 == undefined) && ($scope.standardBForm2step2facta7 == "" || $scope.standardBForm2step2facta7 == undefined) && ($scope.standardBForm2step2facta9 == "" || $scope.standardBForm2step2facta9 == undefined)){
$scope.progressvalue = 20;
}
else if(($scope.standardBForm2step2facta4 == "" || $scope.standardBForm2step2facta4 == undefined) && ($scope.standardBForm2step2facta5 != "" || $scope.standardBForm2step2facta5 != undefined) && ($scope.standardBForm2step2facta6 == "" || $scope.standardBForm2step2facta6 == undefined) && ($scope.standardBForm2step2facta7 == "" || $scope.standardBForm2step2facta7 == undefined) && ($scope.standardBForm2step2facta9 == "" || $scope.standardBForm2step2facta9 == undefined)){
$scope.progressvalue = 20;
}
else if(($scope.standardBForm2step2facta4 == "" || $scope.standardBForm2step2facta4 == undefined ) && ($scope.standardBForm2step2facta5 == "" || $scope.standardBForm2step2facta5 == undefined) && ($scope.standardBForm2step2facta6 != "" || $scope.standardBForm2step2facta6 != undefined) && ($scope.standardBForm2step2facta7 == "" || $scope.standardBForm2step2facta7 == undefined) && ($scope.standardBForm2step2facta9 == "" || $scope.standardBForm2step2facta9 == undefined)){
$scope.progressvalue = 20;
}
else if(($scope.standardBForm2step2facta4 == "" || $scope.standardBForm2step2facta4 == undefined ) && ($scope.standardBForm2step2facta5 == "" || $scope.standardBForm2step2facta5 == undefined) && ($scope.standardBForm2step2facta6 == "" || $scope.standardBForm2step2facta6 == undefined) && ($scope.standardBForm2step2facta7 != "" || $scope.standardBForm2step2facta7 != undefined) && ($scope.standardBForm2step2facta9 == "" || $scope.standardBForm2step2facta9 == undefined)){
$scope.progressvalue = 20;
}
else if(($scope.standardBForm2step2facta4 == "" || $scope.standardBForm2step2facta4 == undefined ) && ($scope.standardBForm2step2facta5 == "" || $scope.standardBForm2step2facta5 == undefined) && ($scope.standardBForm2step2facta6 == "" || $scope.standardBForm2step2facta6 == undefined) && ($scope.standardBForm2step2facta7 == "" || $scope.standardBForm2step2facta7 == undefined) && ($scope.standardBForm2step2facta9 != "" || $scope.standardBForm2step2facta9 != undefined)){
$scope.progressvalue = 20;
}
else if(($scope.standardBForm2step2facta4 != "" || $scope.standardBForm2step2facta4 != undefined) && ($scope.standardBForm2step2facta5 != "" || $scope.standardBForm2step2facta5 != undefined) && ($scope.standardBForm2step2facta6 == "" || $scope.standardBForm2step2facta6 == undefined) && ($scope.standardBForm2step2facta7 == "" || $scope.standardBForm2step2facta7 == undefined) && ($scope.standardBForm2step2facta9 == "" || $scope.standardBForm2step2facta9 == undefined)){
$scope.progressvalue = 40;
}
else if(($scope.standardBForm2step2facta4 == "" || $scope.standardBForm2step2facta4 == undefined) && ($scope.standardBForm2step2facta5 != "" || $scope.standardBForm2step2facta5 != undefined) && ($scope.standardBForm2step2facta6 != "" || $scope.standardBForm2step2facta6 != undefined) && ($scope.standardBForm2step2facta7 == "" || $scope.standardBForm2step2facta7 == undefined) && ($scope.standardBForm2step2facta9 == "" || $scope.standardBForm2step2facta9 == undefined)){
$scope.progressvalue = 40;
}
else if(($scope.standardBForm2step2facta4 == "" || $scope.standardBForm2step2facta4 == undefined) && ($scope.standardBForm2step2facta5 == "" || $scope.standardBForm2step2facta5 == undefined) && ($scope.standardBForm2step2facta6 != "" || $scope.standardBForm2step2facta6 != undefined) && ($scope.standardBForm2step2facta7 != "" || $scope.standardBForm2step2facta7 != undefined) && ($scope.standardBForm2step2facta9 == "" || $scope.standardBForm2step2facta9 == undefined)){
$scope.progressvalue = 40;
}
else if(($scope.standardBForm2step2facta4 == "" || $scope.standardBForm2step2facta4 == undefined ) && ($scope.standardBForm2step2facta5 == "" || $scope.standardBForm2step2facta5 == undefined) && ($scope.standardBForm2step2facta6 == "" || $scope.standardBForm2step2facta6 == undefined) && ($scope.standardBForm2step2facta7 != "" || $scope.standardBForm2step2facta7 != undefined) && ($scope.standardBForm2step2facta9 != "" || $scope.standardBForm2step2facta9 != undefined)){
$scope.progressvalue = 40;
}
else if(($scope.standardBForm2step2facta4 != "" || $scope.standardBForm2step2facta4 != undefined ) && ($scope.standardBForm2step2facta5 != "" || $scope.standardBForm2step2facta5 != undefined) && ($scope.standardBForm2step2facta6 != "" || $scope.standardBForm2step2facta6 != undefined) && ($scope.standardBForm2step2facta7 == "" || $scope.standardBForm2step2facta7 == undefined) && ($scope.standardBForm2step2facta9 == "" || $scope.standardBForm2step2facta9 == undefined)){
$scope.progressvalue = 60;
}
else if(($scope.standardBForm2step2facta4 == "" || $scope.standardBForm2step2facta4 == undefined ) && ($scope.standardBForm2step2facta5 != "" || $scope.standardBForm2step2facta5 != undefined) && ($scope.standardBForm2step2facta6 != "" || $scope.standardBForm2step2facta6 != undefined) && ($scope.standardBForm2step2facta7 != "" || $scope.standardBForm2step2facta7 != undefined) && ($scope.standardBForm2step2facta9 == "" || $scope.standardBForm2step2facta9 == undefined)){
$scope.progressvalue = 60;
}
else if(($scope.standardBForm2step2facta4 == "" || $scope.standardBForm2step2facta4 == undefined ) && ($scope.standardBForm2step2facta5 == "" || $scope.standardBForm2step2facta5 == undefined) && ($scope.standardBForm2step2facta6 == "" || $scope.standardBForm2step2facta6 != undefined) && ($scope.standardBForm2step2facta7 != "" || $scope.standardBForm2step2facta7 != undefined) && ($scope.standardBForm2step2facta9 != "" || $scope.standardBForm2step2facta9 != undefined)){
$scope.progressvalue = 60;
}
else if(($scope.standardBForm2step2facta4 != "" || $scope.standardBForm2step2facta4 != undefined ) && ($scope.standardBForm2step2facta5 != "" || $scope.standardBForm2step2facta5 != undefined) && ($scope.standardBForm2step2facta6 != "" || $scope.standardBForm2step2facta6 != undefined) && ($scope.standardBForm2step2facta7 != "" || $scope.standardBForm2step2facta7 != undefined) && ($scope.standardBForm2step2facta9 != "" || $scope.standardBForm2step2facta9 != undefined)){
$scope.progressvalue = 100
}
}
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  }
  
   function fatcasecondController($scope, $mdDialog) {
  $scope.fatca2submit = function(){
if(($scope.standardBForm2step2facta2 == "" || $scope.standardBForm2step2facta2 == undefined) && ($scope.standardBForm2step2facta3 == "" || $scope.standardBForm2step2facta3 == undefined) && ($scope.standardBForm2step2RegNumber == "" || $scope.standardBForm2step2RegNumber == undefined)){
$scope.progressvalue = 0;
}
else if(($scope.standardBForm2step2facta2 != "" || $scope.standardBForm2step2facta2 != undefined) && ($scope.standardBForm2step2facta3 == "" || $scope.standardBForm2step2facta3 == undefined) && ($scope.standardBForm2step2RegNumber == "" || $scope.standardBForm2step2RegNumber == undefined)){
$scope.progressvalue = 33;
}
else if(($scope.standardBForm2step2facta2 == "" || $scope.standardBForm2step2facta2 == undefined) && ($scope.standardBForm2step2facta3 != "" || $scope.standardBForm2step2facta3 != undefined) && ($scope.standardBForm2step2RegNumber == "" || $scope.standardBForm2step2RegNumber == undefined)){
$scope.progressvalue = 33;
}
else if(($scope.standardBForm2step2facta2 == "" || $scope.standardBForm2step2facta2 == undefined ) && ($scope.standardBForm2step2facta3 == "" || $scope.standardBForm2step2facta3 == undefined) && ($scope.standardBForm2step2RegNumber != "" || $scope.standardBForm2step2RegNumber != undefined)){
$scope.progressvalue = 33;
}
else if(($scope.standardBForm2step2facta2 != "" || $scope.standardBForm2step2facta2 != undefined) && ($scope.standardBForm2step2facta3 != "" || $scope.standardBForm2step2facta3 != undefined) && ($scope.standardBForm2step2RegNumber == "" || $scope.standardBForm2step2RegNumber == undefined)){
$scope.progressvalue = 66;
}
else if(($scope.standardBForm2step2facta2 != "" || $scope.standardBForm2step2facta2 != undefined) && ($scope.standardBForm2step2facta3 == "" || $scope.standardBForm2step2facta3 == undefined) && ($scope.standardBForm2step2RegNumber != "" || $scope.standardBForm2step2RegNumber != undefined)){
$scope.progressvalue = 66;
}
else if(($scope.standardBForm2step2facta2 != "" || $scope.standardBForm2step2facta2 != undefined ) && ($scope.standardBForm2step2facta3 != "" || $scope.standardBForm2step2facta3 != undefined) && ($scope.standardBForm2step2RegNumber == "" || $scope.standardBForm2step2RegNumber == undefined)){
$scope.progressvalue = 66;
}
else if(($scope.standardBForm2step2facta2 != "" || $scope.standardBForm2step2facta2 != undefined) && ($scope.standardBForm2step2facta3 != "" || $scope.standardBForm2step2facta3 != undefined )&& ($scope.standardBForm2step2RegNumber != "" || $scope.standardBForm2step2RegNumber != undefined)){
$scope.progressvalue = 100;
}
}
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  }
  
  function fatcafirstController($scope, $mdDialog) {
  $scope.fatca1submit = function(){
if($scope.standardBForm2step2facta1 == "" || $scope.standardBForm2step2facta1 == undefined){
$scope.progressvalue = 0;
}

else if($scope.standardBForm2step2facta1 != "" || $scope.standardBForm2step2facta1 != undefined){
$scope.progressvalue = 100;
}
}
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  }
  
  $scope.questionarie1fn = function(ev,value) {
    $mdDialog.show({
      controller: questionariefirstController,
      templateUrl: 'app/main/add-customer/views/manual/form/questionariepopup.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 $scope.questionarie2fn = function(ev,value) {
    $mdDialog.show({
      controller: questionariefirstController,
      templateUrl: 'app/main/add-customer/views/manual/form/questionariepopup1.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 $scope.questionarie3fn = function(ev,value) {
    $mdDialog.show({
      controller: questionariefirstController,
      templateUrl: 'app/main/add-customer/views/manual/form/questionariepopup2.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 $scope.questionarie4fn = function(ev,value) {
    $mdDialog.show({
      controller: questionariefirstController,
      templateUrl: 'app/main/add-customer/views/manual/form/questionariepopup3.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 $scope.questionarie5fn = function(ev,value) {
    $mdDialog.show({
      controller: questionariefirstController,
      templateUrl: 'app/main/add-customer/views/manual/form/questionariepopup4.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 $scope.questionarie6fn = function(ev,value) {
	 //$scope.sitevisit();
    $mdDialog.show({
      controller: questionariefiveController,
      templateUrl: 'app/main/add-customer/views/manual/form/questionariepopup5.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
 	

	 
	function questionariefirstController($scope, $mdDialog) { 
	  
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  }

  function questionariefiveController($scope, $mdDialog) { 
	  
	  //$scope.sitevisit();
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
   $scope.sitevisit = function(){
	alert("123")
	debugger;
	$scope.Sitevisitcontent = true;  
  }

	 $scope.clickedRadio=function(){
	debugger;
	$rootScope.Sitevisitcontent=true;  
	//	$scope.Sitevisitcontent = true;  
//$scope.sitevisit();
  }
  }
//   $scope.sitevisit = function(){
// 	alert("123")
// 	debugger;
// 	$scope.Sitevisitcontent = true;  
//   }
 
  
  function notesController($scope, $mdDialog) {
  $scope.notestitle = localStorage.tabvalue;
	  var vm = this;
	  $scope.taToolbar = [
            ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'pre', 'quote', 'bold', 'italics', 'underline', 'strikeThrough', 'ul', 'ol', 'redo', 'undo', 'clear'],
            ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent', 'html', 'insertImage', 'insertLink', 'insertVideo', 'wordcount', 'charcount']
        ];
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  $scope.notespage = true;
$scope.savepopup = function(){
$mdDialog.cancel();
}
  }
 $scope.NoteSecFlag = true; 
$scope.mandatoryForm1step1plcount = "John";
$scope.showUnwrappingmraFlag1 = false;	  
$scope.showUnwrappingpublicFlag3 = false;	  
$scope.showUnwrappingchinaFlag2 = false;
$scope.showUnwrappingFlag4 = false;	  
$scope.showUnwrappingFlag5 = false;
$scope.unwrappingFn1 = function(){
$scope.showUnwrappingmraFlag1 = true;

}

$scope.graph_generate1 = function(){

$scope.graphsecFlag=true;
}
$scope.unwrappingFn2 = function(){
$scope.showUnwrappingchinaFlag2 = true;

}
$scope.unwrappingFn3 = function(){
$scope.showUnwrappingpublicFlag3 = true;
$scope.showUnwrappingFlag4 = true;
}
$scope.unwrappingFn4 = function(){
$scope.showUnwrappingFlag5 = true;
}
$scope.unwrappingFn5 = function(){
$scope.showUnwrappingFlag6 = true;
$scope.showUnwrappingFlag7 = true;
}
$scope.unwrappingFn6 = function(){
$scope.showUnwrappingFlag8 = true;
}
$scope.menumaskflag = false;
$scope.closefn = function(){
debugger
$scope.menumaskflag = false;
$scope.dedube_tablesec = false;
$scope.dedube_tablesec1 = false;
$scope.dedube_tablesec2 = false;
$scope.namescreen_tablesec = false;
}
$scope.unwrapvalue = function(unwrapbox1){
if(unwrapbox1 == undefined){
return false;
}
if(!unwrapbox1.name || !unwrapbox1.sharetype || !unwrapbox1.share)
{
return false;
}
else{$scope.unwrappingFn2();
}
return false;
}
$scope.unwrapvalue1 = function(unwrapbox2){
if(unwrapbox2 == undefined){
return false;
}
if(!unwrapbox2.name || !unwrapbox2.bankname || !unwrapbox2.share)
{

return false;
}
else{

$scope.unwrappingFn3();
}
return false;
}
$scope.unwrapvalue2 = function(unwrapbox3,unwrapbox4){

if(unwrapbox3 == undefined || unwrapbox4 == undefined){
return false;
}
if(!unwrapbox3.sector || !unwrapbox3.share || !unwrapbox4.name || !unwrapbox4.sharetype || !unwrapbox4.share)
{

return false;
}
else{

$scope.unwrappingFn4();
}
return false;
}
$scope.unwrapvalue3 = function(unwrapbox5){
if(unwrapbox5 == undefined){
return false;
}
if(!unwrapbox5.name || !unwrapbox5.sharetype || !unwrapbox5.share)
{
return false;
}
else{
$scope.unwrappingFn5();
}
return false;
}
$scope.unwrapvalue4 = function(unwrapbox6,unwrapbox7){
if(unwrapbox6 == undefined || unwrapbox7 == undefined){
return false;
}
if(!unwrapbox6.name || !unwrapbox6.sharetype || !unwrapbox6.share || !unwrapbox7.name || !unwrapbox7.sharetype || !unwrapbox7.share)
{
return false;
}
else{
$scope.unwrappingFn6();
}
return false;
}
$scope.unwrapvalue5 = function(unwrapbox8){
if(unwrapbox8 == undefined){
return false;
}
if(!unwrapbox8.name || !unwrapbox8.sharetype || !unwrapbox8.share)
{
return false;
}
else{
$scope.unwrappingFn6();
}
return false;
}
   

$scope.customerinfoFlag = 1; 
$scope.fncus = function(data){
	/* alert($("div").scrollTop());
	alert($("body").scrollTop());
	$("body").scrollTop() */
$scope.customerinfoFlag = data; 
}
$scope.customerinfosubFlag6 = 1; 
$scope.fncussub6 = function(data){
$scope.customerinfosubFlag6 = data; 
}
$scope.customerinfosub1Flag6 = 2; 
$scope.fncussub1_6 = function(data){
$scope.customerinfosub1Flag6 = data; 
}

$scope.customerinfosub2Flag6 = 1; 
$scope.fncussub2_6 = function(data){
$scope.customerinfosub2Flag6 = data; 
}

$scope.customerinfosub3Flag6 = 1; 
$scope.fncussub3_6 = function(data){
$scope.customerinfosub3Flag6 = data; 
}

/* $scope.customerinfoFlag1 = 1; 
$scope.fncussub6 = function(data){
$scope.customerinfoFlag1 = data; 
}
 */
$scope.addcustomertable = function(){
$scope.addcustomerdedupe = "true";
$scope.newcustomerflag = "true";
$scope.showaddrelatedMatchFlag3 = "false";

}

$scope.relatedPartyindividual = [{value1:"First Name",value2:"Middle Name",value3:"Last Name",value4:"Alias Name",value5:"Date of Birth",value6:"Nationality",value7:"ID Number "}]
$scope.relatedPartynonindividual = [{value1:"Legal Name",value2:"Date of Incorporation",value3:"Registered / Unique Identification No issued by Gov Entity"}]
    function findInputText(){
		var selObj = false;
		$("div.speech-in .inputVoiceText").each(function(){
			console.log($(this));
			if ((($.trim($(this).val()).length == 0 || $(this).hasClass("allow"))) && selObj == false){ 
				selObj = $(this);
				if ($(this).hasClass("allow")){
					$(this).removeClass("allow");
				}
			}
		});
		return selObj;
    }

    function startDictation(obj) {
		var getSelObj = (obj) ? obj : findInputText(); 
		if (getSelObj){
			if (window.hasOwnProperty('webkitSpeechRecognition')) {
			  var recognition = new webkitSpeechRecognition();
			  $scope.speechReg = recognition;
			  recognition.continuous = false;
			  recognition.interimResults = false;
			  recognition.lang = "en-IN";
			  recognition.start();
			  //clearItems();
			  //jQuery(getSelObj).parents("md-input-container").addClass("input");
			  //$("#start_button").removeClass("micOff").addClass("micOn");
			  recognition.onresult = function(e) {
					var userVoiceInput = e.results[0][0].transcript;
					if (!obj){
						$(getSelObj).focus().val(userVoiceInput).css("color","#000");
						$(getSelObj).parents("md-input-container").addClass("md-input-focused");
						recognition.stop();
						startDictation();
					}else{
						if (userVoiceInput == "dedupe"){
							$(obj).click();
							$scope.potentialTableFn();
							recognition.stop();
							PageAction();
						}else{
							startDictation($(".btn_dedupe"));
						}
					}
					//$(getSelObj).parents("md-input-container").removeClass("md-input-focused");	
					
			  };
			  recognition.onerror = function(e) {
				recognition.stop();
			  }
			}
		}else{
			startDictation($(".btn_dedupe"));
			return false;
		}
	}
	
	function stopDictation(obj) {
		//debugger;
		var recognition = new webkitSpeechRecognition();
	    recognition.abort();
		//recognition.stop();
	}
$scope.speechReg;
	function PageAction(){

		if (window.hasOwnProperty('webkitSpeechRecognition')) {
			var recognition = new webkitSpeechRecognition();
			$scope.speechReg = recognition;
			recognition.continuous = false;
			recognition.interimResults = false;
			recognition.lang = "en-IN";
			recognition.start();

			recognition.onresult = function(e) {
			var voiceInput = e.results[0][0].transcript;
			console.log(voiceInput);
			if(voiceInput == "open chat"){
				if ($("#quick-panel").hasClass("_md-closed") == true){
					$(".menu-icon").click();
				} 
				$(".chat-window").click(); 
				recognition.stop();
				PageAction();
			}else if(voiceInput == "open announcements" || voiceInput == "open announcement"){
				if ($("#quick-panel").hasClass("_md-closed") == true){
					$(".menu-icon").click();
				} 
				$(".ann-window").click(); 
				recognition.stop();
				PageAction();
			}else if(voiceInput == "close"){
				if ($("#quick-panel").hasClass("_md-closed") == false){
					$("._md-sidenav-backdrop").click();
				} 
				recognition.stop();
			}else{
				PageAction();
			}
			};
			recognition.onerror = function(e) {
				recognition.stop();
			}

		}
	}

	$(".mic-icon").click(function(){
		//startDictation();
	   if(localStorage.voiceIcon == true){
		   startDictation();
	   }else{
		   stopDictation();
	   }
	   
	});  

	
	$scope.unwrappingDiv1 = false;
    $scope.unwrappingFn1 = function(){
		$scope.unwrappingDiv1 = true;
		$('#parent0 td').addClass('noSibling');
		//$scope.drawLines("name","id",0,0)
	}
	
	$scope.unwrappingDiv2 = false;
	$scope.unwrappingFn2 = function(data){
	if(data.Name == undefined || data.Sharetype == undefined || data.Share == undefined || data.Name == "" || data.Sharetype == "" || data.Share == ""){
			return false;
		}else{
			$scope.unwrappingDiv2 = true;
		}
	}
	
	$scope.unwrappingFn3 = function(data){
		////debugger;
	if(data.name == undefined || data.sharetype == undefined || data.share == undefined || data.name == "" || data.sharetype == "" || data.share == "" || data.unwrappingIO2 == "" ||data.unwrappingIO2 == undefined){
			return false;
		}
		else{
			$scope.unwrappingDiv3 = true;
		}
	}	

	$scope.unwrappingFn4 = function(data){
		//debugger;
	if(data.name == undefined || data.sharetype == undefined || data.share == undefined || data.name == "" || data.sharetype == "" || data.share == "" || data.unwrappingIO3 == "" ||data.unwrappingIO3 == undefined){
			return false;
		}
		else{
			$scope.unwrappingDiv4 = true;
		}
	}
$scope.unwrappingFn5 = function(data){
		//debugger;
	if(data.name == undefined || data.sharetype == undefined || data.share == undefined || data.name == "" || data.sharetype == "" || data.share == "" || data.unwrappingIO4 == "" ||data.unwrappingIO4 == undefined){
			return false;
		}
		else{
			$scope.unwrappingFn4();
		}
	}		
	$scope.unwrappingFn6 = function(data){
		//debugger;
	if(data.name == undefined || data.sharetype == undefined || data.share == undefined || data.name == "" || data.sharetype == "" || data.share == "" || data.unwrappingIO5 == "" ||data.unwrappingIO5 == undefined){
			return false;
		}
		else{
			$scope.unwrappingDiv5 = true;
		}
	}
$scope.unwrappingFn7 = function(data){
		//debugger;
	if(data.name == undefined || data.sharetype == undefined || data.share == undefined || data.name == "" || data.sharetype == "" || data.share == "" || data.unwrappingIO6 == "" ||data.unwrappingIO6 == undefined){
			return false;
		}
		else{
			$scope.unwrappingFn6();
		}
	}	
 $scope.unwrappingFn8 = function(data){
		//debugger;
	if(data.name == undefined || data.sharetype == undefined || data.share == undefined || data.name == "" || data.sharetype == "" || data.share == "" || data.unwrappingIO7 == "" ||data.unwrappingIO7 == undefined){
			return false;
		}
	}
	$scope.unwrappingFn9 = function(data){
		//debugger;
	if(data.name == undefined || data.sharetype == undefined || data.share == undefined || data.name == "" || data.sharetype == "" || data.share == "" || data.unwrappingIO8 == "" ||data.unwrappingIO8 == undefined){
			return false;
		}
	}
	
	$scope.sameAddressFn = function(){
	    if($scope.addressFlag == false){
			$scope.vmCustomerApplicationInfostep7OfficeAddress2 = $scope.vmCustomerApplicationInfostep7address;
			$scope.vmCustomerApplicationInfostep7addressoff2 = $scope.vmCustomerApplicationInfostep7address2;
			$scope.vmCustomerApplicationInfostep7pincodeoff9 = $scope.CustomerApplicationInfostep7pincode9;
		}
	}	
	
	
	$scope.hkFlag = true;
	$scope.closeHkfn = function(){
		$scope.hkFlag = false;
	}
	$scope.prohibitywrongfn = function(data){
	alert(data);
	}
	/* $scope.removeTab = function (tab) {
	alert(tab);
      var index = indexOf(tab);
      splice(tab);
    }; */
	
	$scope.risktab = 1; 
$scope.risktabaname = function(data){
$scope.risktab = data; 
}
	
	$scope.countryList = ["India", "Singapore", "Indonesia", "Malaysia", "Honkong", "Dubai"];
$scope.related_party = ["Individual","Non-Individual"];
$scope.risk_rating_tab = ["High","Medium","Low"];
$scope.risk_rating = ["High","Medium","Low"];
$scope.risk_rating_hl = ["High","Low"];
$scope.risk_rating_onboard = ["Onboard/Retain","Do not Onboard/Exit"];
$scope.risk_rating_response = ["Yes","No"];
$scope.risk_rating_response12 = "IH5265"
$scope.risk_rating_response13 = "IH5266"
$scope.risk_rating_response1 = ["Yes","No"];
$scope.relatedparty1 = "IH5245"
$scope.relatedparty2 = "IH5227"
$scope.relatedparty3 = "IH5232"
$scope.relatedparty4 = "IH5256"
$scope.riskasseschange = function(value){  
debugger;
if(value.ratingResponse1 == "Yes"){
$scope.ratingValue1 = "High";
}if(value.ratingResponse1 == "No"){
$scope.ratingValue1 = "Low";
}
}
$scope.riskbasedvalue7 = "High";
$scope.productrisk = function(value){
debugger
if(value.riskbased7 == "Yes" && value.riskbased6 == "Yes" && value.riskbased5 == "No"){
$scope.riskbasedvalue7 = "High"
}
else if(value.riskbased7 == "No" && value.riskbased6 == "Yes" && value.riskbased5 == "No"){
$scope.riskbasedvalue7 = "Medium"
}
else if(value.riskbased7 == "No" && value.riskbased6 == "No" && value.riskbased5 == "Yes"){
$scope.riskbasedvalue7 = "Low"
}
else if(value.riskbased7 == "Yes" && value.riskbased6 == "No" && value.riskbased5 == "No"){
$scope.riskbasedvalue7 = "High"
}
else if(value.riskbased7 == "Yes" && value.riskbased6 == "Yes" && value.riskbased5 == "Yes"){
$scope.riskbasedvalue7 = "High"
}
}
$scope.changeResponse1=function(value){
    if(value=="Yes"){
        $scope.ratingValue1="High";
    }
    else if(value=="No"){
        $scope.ratingValue1="Low";
    }
}
//$scope.riskbasedvalue11 = "High";
$scope.changeResponse2=function(value){
    if(value=="Yes"){
        $scope.ratingValue2="High";
    }
    else if(value=="No"){
        $scope.ratingValue2="Low";
    }
}

/* $scope.changeResponse3=function(value){
    if(value=="Yes"){
        $scope.ratingValue3="High";
    }
    else if(value=="No"){
        $scope.ratingValue3="Low";
    }
} */

    }
})();





(function () {
    'use strict';

    angular
        .module('app.manual')
        .directive('ddCollapseText', collapseText);

    collapseText.$inject = ['$compile'];

    /* @ngInject */
    function collapseText($compile) {
        return {
            restrict: 'A',
            replace: true,
            link: function(scope, element, attrs) {

                // start collapsed
                scope.collapsed = false;

                // create the function to toggle the collapse
                scope.toggle = function() {
                    scope.collapsed = !scope.collapsed;
                };

                // get the value of the dd-collapse-text attribute
                attrs.$observe('ddCollapseText', function(maxLength) {
                    // get the contents of the element
                    var text = element.text();

                    if (text.length > maxLength) {
                        // split the text in two parts, the first always showing
                        var firstPart = String(text).substring(0, maxLength);
                        var secondPart = String(text).substring(maxLength, text.length);

                        // create some new html elements to hold the separate info
                        var firstSpan = $compile('<span>' + firstPart + '</span>')(scope);
                        var secondSpan = $compile('<span ng-if="collapsed">' + secondPart + '</span>')(scope);
                        var moreIndicatorSpan = $compile('<span ng-if="!collapsed">...</span>')(scope);
                        var toggleButton = $compile('<span class="collapse-text-toggle" ng-click="toggle()">{{collapsed ? "less" : "more"}}</span>')(scope);

                        // remove the current contents of the element
                        // and add the new ones we created
                        element.empty();
                        element.append(firstSpan);
                        element.append(secondSpan);
                        element.append(moreIndicatorSpan);
                        element.append(toggleButton);
                    }
                });
            }
        };
    }
})();



