(function ()
{
    'use strict';

    angular
        .module('app.manual',[])
        .config(config);

    /** @ngInject */
    
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {

        // State
        $stateProvider.state('app.manual', {
            url    : '/add-customer/manual',
            views  : {
                'content@app': {
                    templateUrl: 'app/main/add-customer/views/manual/manual.html',
                    controller : 'manualController as vm'
                }
            },
            resolve: {
                Potential: function (msApi)
                {
                    return msApi.resolve('addcustomer.potential@get');
                },
				Potential1: function (msApi)
                {
                    return msApi.resolve('addcustomer.potential1@get');
                },
				Potential2: function (msApi)
                {
                    return msApi.resolve('addcustomer.potential2@get');
                },
				Potential3: function (msApi)
                {
                    return msApi.resolve('addcustomer.potential3@get');
                },
				Document: function (msApi)
                {
                    return msApi.resolve('addcustomer.document@get');
                },
				Prohibited: function (msApi)
                {
                    return msApi.resolve('addcustomer.prohibited@get');
                },
				Country: function (msApi)
                {
                    return msApi.resolve('addcustomer.country@get');
                },
				ISIC: function (msApi)
                {
                    return msApi.resolve('addcustomer.isic@get');
                },
				Currency: function (msApi)
                {
                    return msApi.resolve('addcustomer.curency@get');
                },
				Stock: function (msApi)
                {
                    return msApi.resolve('addcustomer.stock@get');
                },
                Timeline: function (msApi)
                {
                    return msApi.resolve('timeline.page1@get');
                },
				 addcustomerdedupe: function (msApi)
                {
                    return msApi.resolve('addcustomer.table7@get');
                },
                 screeningData: function (msApi)
                {
                    return msApi.resolve('screening.data@get');
                },
                 unwrappingData: function (msApi)
                {
                    return msApi.resolve('unwrapping.data@get');
                },
				relatedvalue: function (msApi)
                {
                    return msApi.resolve('related.data@get');
                },
				slidervalue: function (msApi)
                {
                    return msApi.resolve('slidetable.data@get');
                }
            }
                
            
        });

        // Api

        // Contacts data must be alphabatically ordered.
        // msApiProvider.register('chat.contacts', ['app/data/chat/contacts.json']);

        // msApiProvider.register('chat.chats', ['app/data/chat/chats/:id.json']);

         msApiProvider.register('addcustomer.potential', ['app/data/add-customer/potentialList.json']);
		 
		 msApiProvider.register('addcustomer.potential1', ['app/data/add-customer/potentialList1.json']);
		 
		 msApiProvider.register('addcustomer.potential2', ['app/data/add-customer/potentialList2.json']);
		 
		 msApiProvider.register('addcustomer.potential3', ['app/data/add-customer/potentialList3.json']);
		 
		 msApiProvider.register('addcustomer.document', ['app/data/add-customer/document.json']);
		 
		 msApiProvider.register('addcustomer.prohibited', ['app/data/add-customer/prohibited.json']);
		 
		 msApiProvider.register('addcustomer.country', ['app/data/country/country.json']);
		 
		 msApiProvider.register('addcustomer.isic', ['app/data/ISIC/isic.json']);
		 
		 msApiProvider.register('addcustomer.curency', ['app/data/currency/curency.json']);
		 
		 msApiProvider.register('addcustomer.stock', ['app/data/StockExchange/stock.json']);

         msApiProvider.register('timeline.page1', ['app/data/timeline/page-2.json']);
		 
		 msApiProvider.register('addcustomer.table7', ['app/data/add-customer/table7.json']);

         msApiProvider.register('screening.data', ['app/data/add-customer/screeningList.json']);

        msApiProvider.register('unwrapping.data', ['app/data/add-customer/unwrappingData.json']);
        msApiProvider.register('related.data', ['app/data/add-customer/relatedvlaue.json']);

        msApiProvider.register('slidetable.data', ['app/data/add-customer/slidetable.json']);
        // Navigation
        // msNavigationServiceProvider.saveItem('apps.help', {
            // title : 'Help',
			// icon  : 'icon-tile-four',
            // state : 'app.help',
            // weight: 14
        // });
    }

})();