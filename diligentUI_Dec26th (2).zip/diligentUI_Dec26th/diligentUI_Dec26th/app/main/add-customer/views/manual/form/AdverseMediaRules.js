if($scope.finCrime == "Yes" && $scope.proven == "Yes" && $scope.severity == "High" && $scope.time == "<5yrs"){
$scope.adverseMediaRating = "High";
}else if($scope.finCrime == "Yes" && $scope.proven == "Yes" && $scope.severity == "High" && $scope.time == ">5yrs"){
$scope.adverseMediaRating = "Medium";
}else if($scope.finCrime == "Yes" && $scope.proven == "Yes" && $scope.severity == "Medium" && $scope.time == "<5yrs"){
$scope.adverseMediaRating = "High";
}else if($scope.finCrime == "Yes" && $scope.proven == "Yes" && $scope.severity == "Medium" && $scope.time == ">5yrs"){
$scope.adverseMediaRating = "Medium";
}else if($scope.finCrime == "Yes" && $scope.proven == "Yes" && $scope.severity == "Low" && $scope.time == "<5yrs"){
$scope.adverseMediaRating = "Medium";
}else if($scope.finCrime == "Yes" && $scope.proven == "Yes" && $scope.severity == "Low" && $scope.time == ">5yrs"){
$scope.adverseMediaRating = "Low";
}else if($scope.finCrime == "Yes" && $scope.proven == "No" && $scope.severity == "High" && $scope.time == "<5yrs"){
$scope.adverseMediaRating = "High";
}else if($scope.finCrime == "Yes" && $scope.proven == "No" && $scope.severity == "High" && $scope.time == ">5yrs"){
$scope.adverseMediaRating = "Medium";
}else if($scope.finCrime == "Yes" && $scope.proven == "No" && $scope.severity == "Medium" && $scope.time == "<5yrs"){
$scope.adverseMediaRating = "Medium";
}else if($scope.finCrime == "Yes" && $scope.proven == "No" && $scope.severity == "Medium" && $scope.time == ">5yrs"){
$scope.adverseMediaRating = "Low";
}else if($scope.finCrime == "Yes" && $scope.proven == "No" && $scope.severity == "Low" && $scope.time == "<5yrs"){
$scope.adverseMediaRating = "Low";
}else if($scope.finCrime == "Yes" && $scope.proven == "No" && $scope.severity == "Low" && $scope.time == ">5yrs"){
$scope.adverseMediaRating = "Low";
}else if($scope.finCrime == "No" && $scope.proven == "Yes" && $scope.severity == "High" && $scope.time == "<5yrs"){
$scope.adverseMediaRating = "Medium";
}else if($scope.finCrime == "No" && $scope.proven == "Yes" && $scope.severity == "High" && $scope.time == ">5yrs"){
$scope.adverseMediaRating = "Medium";
}else if($scope.finCrime == "No" && $scope.proven == "Yes" && $scope.severity == "Medium" && $scope.time == "<5yrs"){
$scope.adverseMediaRating = "Medium";
}else if($scope.finCrime == "No" && $scope.proven == "Yes" && $scope.severity == "Medium" && $scope.time == ">5yrs"){
$scope.adverseMediaRating = "Low";
}else if($scope.finCrime == "No" && $scope.proven == "Yes" && $scope.severity == "Low" && $scope.time == "<5yrs"){
$scope.adverseMediaRating = "Low";
}else if($scope.finCrime == "No" && $scope.proven == "Yes" && $scope.severity == "Low" && $scope.time == ">5yrs"){
$scope.adverseMediaRating = "Low";
}else if($scope.finCrime == "No" && $scope.proven == "No" && $scope.severity == "High" && $scope.time == "<5yrs"){
$scope.adverseMediaRating = "Medium";
}else if($scope.finCrime == "No" && $scope.proven == "No" && $scope.severity == "High" && $scope.time == ">5yrs"){
$scope.adverseMediaRating = "Low";
}else if($scope.finCrime == "No" && $scope.proven == "No" && $scope.severity == "Medium" && $scope.time == "<5yrs"){
$scope.adverseMediaRating = "Low";
}else if($scope.finCrime == "No" && $scope.proven == "No" && $scope.severity == "Medium" && $scope.time == ">5yrs"){
$scope.adverseMediaRating = "Low";
}else if($scope.finCrime == "No" && $scope.proven == "No" && $scope.severity == "Low" && $scope.time == "<5yrs"){
$scope.adverseMediaRating = "Low";
}else if($scope.finCrime == "No" && $scope.proven == "No" && $scope.severity == "Low" && $scope.time == ">5yrs"){
$scope.adverseMediaRating = "Low";
}