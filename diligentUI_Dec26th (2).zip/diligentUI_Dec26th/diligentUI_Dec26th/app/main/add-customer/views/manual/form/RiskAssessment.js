if($scope.country == "High" && $scope.industry == "High" && $scope.product == "High" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "High";
}else if($scope.country == "High" && $scope.industry == "High" && $scope.product == "High" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "High";
}else if($scope.country == "High" && $scope.industry == "High" && $scope.product == "Medium" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "High";
}else if($scope.country == "High" && $scope.industry == "High" && $scope.product == "Medium" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "High" && $scope.industry == "High" && $scope.product == "Low" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "High" && $scope.industry == "High" && $scope.product == "Low" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "High" && $scope.industry == "Medium" && $scope.product == "High" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "High";
}else if($scope.country == "High" && $scope.industry == "Medium" && $scope.product == "High" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "High" && $scope.industry == "Medium" && $scope.product == "Medium" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "High" && $scope.industry == "Medium" && $scope.product == "Medium" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "High" && $scope.industry == "Medium" && $scope.product == "Low" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "High" && $scope.industry == "Medium" && $scope.product == "Low" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "High" && $scope.industry == "Low" && $scope.product == "High" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "High" && $scope.industry == "Low" && $scope.product == "High" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "High" && $scope.industry == "Low" && $scope.product == "Medium" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "High" && $scope.industry == "Low" && $scope.product == "Medium" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "High" && $scope.industry == "Low" && $scope.product == "Low" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "High" && $scope.industry == "Low" && $scope.product == "Low" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Medium" && $scope.industry == "High" && $scope.product == "High" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "High";
}else if($scope.country == "Medium" && $scope.industry == "High" && $scope.product == "High" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "Medium" && $scope.industry == "High" && $scope.product == "Medium" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "Medium" && $scope.industry == "High" && $scope.product == "Medium" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "Medium" && $scope.industry == "High" && $scope.product == "Low" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "Medium" && $scope.industry == "High" && $scope.product == "Low" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Medium" && $scope.industry == "Medium" && $scope.product == "High" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "Medium" && $scope.industry == "Medium" && $scope.product == "High" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "Medium" && $scope.industry == "Medium" && $scope.product == "Medium" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "Medium" && $scope.industry == "Medium" && $scope.product == "Medium" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "Medium" && $scope.industry == "Medium" && $scope.product == "Low" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Medium" && $scope.industry == "Medium" && $scope.product == "Low" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Medium" && $scope.industry == "Low" && $scope.product == "High" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "Medium" && $scope.industry == "Low" && $scope.product == "High" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Medium" && $scope.industry == "Low" && $scope.product == "Medium" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Medium" && $scope.industry == "Low" && $scope.product == "Medium" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Medium" && $scope.industry == "Low" && $scope.product == "Low" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Medium" && $scope.industry == "Low" && $scope.product == "Low" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "High" && $scope.product == "High" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "Low" && $scope.industry == "High" && $scope.product == "High" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "Low" && $scope.industry == "High" && $scope.product == "Medium" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "Low" && $scope.industry == "High" && $scope.product == "Medium" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "High" && $scope.product == "Low" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "High" && $scope.product == "Low" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "Medium" && $scope.product == "High" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Medium";
}else if($scope.country == "Low" && $scope.industry == "Medium" && $scope.product == "High" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "Medium" && $scope.product == "Medium" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "Medium" && $scope.product == "Medium" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "Medium" && $scope.product == "Low" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "Medium" && $scope.product == "Low" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "Low" && $scope.product == "High" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "Low" && $scope.product == "High" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "Low" && $scope.product == "Medium" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "Low" && $scope.product == "Medium" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "Low" && $scope.product == "Low" && $scope.Transparency == "Not Transparent"){
$scope.riskAssementRating = "Low";
}else if($scope.country == "Low" && $scope.industry == "Low" && $scope.product == "Low" && $scope.Transparency == "Transparent"){
$scope.riskAssementRating = "Low";
}
