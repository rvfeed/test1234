if($scope.Regulated  == "Yes" && $scope.OffshoreLicense == "No" && $scope.DownstreamCorBanks == "No" && $scope.CorBank == "Yes" 
&& $scope.AMLProgramRobust == "Yes"){
$scope.riskAssementRating = "Low";
}
else if($scope.Regulated  == "Yes" && $scope.OffshoreLicense == "No" && $scope.DownstreamCorBanks == "No" && $scope.CorBank == "Yes" 
&& $scope.AMLProgramRobust == "No"){
$scope.riskAssementRating = "High";
}
else if($scope.Regulated  == "Yes" && $scope.OffshoreLicense == "No" && $scope.DownstreamCorBanks == "No" && $scope.CorBank == "No" 
&& $scope.AMLProgramRobust == "Yes"){
$scope.riskAssementRating = "Medium";
}
else if($scope.Regulated  == "Yes" && $scope.OffshoreLicense == "No" && $scope.DownstreamCorBanks == "No" && $scope.CorBank == "No" 
&& $scope.AMLProgramRobust == "No"){
$scope.riskAssementRating = "High";
}

else if($scope.Regulated  == "Yes" && $scope.OffshoreLicense == "No" && $scope.DownstreamCorBanks == "Yes" && $scope.CorBank == "Yes" 
&& $scope.AMLProgramRobust == "Yes"){
$scope.riskAssementRating = "High";
}
else if($scope.Regulated  == "Yes" && $scope.OffshoreLicense == "No" && $scope.DownstreamCorBanks == "Yes" && $scope.CorBank == "Yes" 
&& $scope.AMLProgramRobust == "No"){
$scope.riskAssementRating = "High";
}
else if($scope.Regulated  == "Yes" && $scope.OffshoreLicense == "No" && $scope.DownstreamCorBanks == "Yes" && $scope.CorBank == "No" 
&& $scope.AMLProgramRobust == "High"){
$scope.riskAssementRating = "Medium";
}
else if($scope.Regulated  == "Yes" && $scope.OffshoreLicense == "No" && $scope.DownstreamCorBanks == "Yes" && $scope.CorBank == "No" 
&& $scope.AMLProgramRobust == "No"){
$scope.riskAssementRating = "High";
}
/*  */
else if($scope.Regulated  == "Yes" && $scope.OffshoreLicense == "Yes" && $scope.AMLProgramRobust == "Yes"){
$scope.riskAssementRating = "High";
}

else if($scope.Regulated  == "Yes" && $scope.OffshoreLicense == "Yes" && $scope.AMLProgramRobust == "No"){
$scope.riskAssementRating = "High";
}


else if($scope.Regulated  == "No" && $scope.OffshoreLicense == "Yes" && $scope.AMLProgramRobust == "Yes"){
$scope.riskAssementRating = "High";
}

else if($scope.Regulated  == "No" && $scope.OffshoreLicense == "Yes" && $scope.AMLProgramRobust == "No"){
$scope.riskAssementRating = "High";
}


else if($scope.Regulated  == "No" && $scope.OffshoreLicense == "No" && $scope.AMLProgramRobust == "Yes"){
$scope.riskAssementRating = "High";
}

else if($scope.Regulated  == "No" && $scope.OffshoreLicense == "No" && $scope.AMLProgramRobust == "No"){
$scope.riskAssementRating = "High";
}

