(function ()
{
    'use strict';

    angular
        .module('app.announcement',[])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {

        // State
        $stateProvider.state('app.announcement', {
            url    : '/activity',
            views  : {
                'content@app': {
                    templateUrl: 'app/main/pages/timeline/timeline.html',
                    controller : 'announcementController as vm'
                }
            },
                resolve  : {
                    Timeline: function (msApi)
                    {
                        return msApi.resolve('timeline.page1@get');
                    }
                },
                bodyClass: 'timeline'
        });


        // Api

        // Contacts data must be alphabatically ordered.
        // msApiProvider.register('chat.contacts', ['app/data/chat/contacts.json']);

        // msApiProvider.register('chat.chats', ['app/data/chat/chats/:id.json']);

        // msApiProvider.register('chat.user', ['app/data/chat/user.json']);
		 msApiProvider.register('timeline.page1', ['app/data/timeline/page-1.json']);


        // Navigation
       /*  msNavigationServiceProvider.saveItem('apps.announcement', {
            title : 'Activity',
			icon  : 'icon-tile-four',
            state : 'app.announcement',
            weight: 8
        }); */
    }

})();