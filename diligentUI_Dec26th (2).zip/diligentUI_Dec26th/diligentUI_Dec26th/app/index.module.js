(function ()
{
    'use strict';

    /**
     * Main module of the Fuse
     */
    angular
        .module('fuse', [

            // Core
            'app.core',

            // Navigation
            'app.navigation',

            // Toolbar
            'app.toolbar',

            // Quick panel
            'app.quick-panel',

            // Apps
            'app.dashboards',
            'app.calendar',
            //'app.e-commerce',
            'app.mail',
            'app.chat',
            'app.file-manager',
            //'app.scrumboard',
            //'app.gantt-chart',
            'app.todo',
            'app.contacts',
			'app.reports',
			'app.announcement',
			'app.search',
			'app.addcustomer',
			'app.viewcustomer',
			'app.manual',
			'app.login',
			'app.summary',
			'app.upload',
			'app.profile',
			'app.admin',
			'app.helpline',
			'app.screen1',
			'app.screen2',
			'app.appInfo',
			'app.table',
			'app.careers',
			'app.periodicreviews',
			'app.newproducts',
			'app.triggerevent',
			/* 'app.demo_file', */   
			'app.idv',
			'app.idvTwo',
			'app.idvThree',
			'app.idvFour',
			'app.idv_5',
			'app.idvdocsetting',
			'app.periodicnewreviews',
			'app.docconfiq',  
			//'app.idvCountryConfig',  
			'ui.bootstrap',
			
			
			'app.ManageExistingCustomers',
			'app.docSet2',
			'app.configuration'

            // Pages
            //'app.pages',

            // User Interface
            //'app.ui',

            // Components
            //'app.components'
        ]);
})();
