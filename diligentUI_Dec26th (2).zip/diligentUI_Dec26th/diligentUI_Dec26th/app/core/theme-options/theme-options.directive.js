(function ()
{
    'use strict';

    angular
        .module('app.core')
        .controller('MsThemeOptionsController', MsThemeOptionsController)
        .directive('msThemeOptions', msThemeOptions);

    /** @ngInject */
    function MsThemeOptionsController($cookies, fuseTheming, $scope)
    {
        var vm = this;

        // Data
        vm.themes = fuseTheming.themes;
		
		$scope.redflag1 = "Afghanistan";
		$scope.redflag2 = "Afghanistan";
		$scope.redflag3 = "848 Bottom Lane,clarence,NY";
		$scope.redflag4 = "Referral";
		$scope.customerName = "nexus bank";
		$scope.customerAliasName = "nexus";
		$scope.customerRegNo = "2ED343";
		$scope.customerOfcNo = "011-4844-4444";
		//$scope.menumaskflagred = false;
		$scope.menumaskredflag = function(){
		debugger
		$scope.menumaskflagred = true;
		}
        vm.layoutModes = [
            {
                label: 'Boxed',
                value: 'boxed'
            },
            {
                label: 'Wide',
                value: 'wide'
            }
        ];
        vm.layoutStyles = [
            {
                label : 'Vertical Navigation',
                value : 'verticalNavigation',
                figure: '/assets/images/theme-options/vertical-nav.jpg'
            },
            {
                label : 'Vertical Navigation with Fullwidth Toolbar',
                value : 'verticalNavigationFullwidthToolbar',
                figure: '/assets/images/theme-options/vertical-nav-with-full-toolbar.jpg'
            },
            {
                label : 'Vertical Navigation with Fullwidth Toolbar 2',
                value : 'verticalNavigationFullwidthToolbar2',
                figure: '/assets/images/theme-options/vertical-nav-with-full-toolbar-2.jpg'
            },
            {
                label : 'Horizontal Navigation',
                value : 'horizontalNavigation',
                figure: '/assets/images/theme-options/horizontal-nav.jpg'
            },
            {
                label : 'Content with Toolbar',
                value : 'contentWithToolbar',
                figure: '/assets/images/theme-options/content-with-toolbar.jpg'
            },
            {
                label : 'Content Only',
                value : 'contentOnly',
                figure: '/assets/images/theme-options/content-only.jpg'
            },
        ];

        vm.layoutMode = 'wide';
        vm.layoutStyle = $cookies.get('layoutStyle') || 'verticalNavigation';

        // Methods
        vm.setActiveTheme = setActiveTheme;
        vm.getActiveTheme = getActiveTheme;
        vm.updateLayoutMode = updateLayoutMode;
        vm.updateLayoutStyle = updateLayoutStyle;

        //////////

        /**
         * Set active theme
         *
         * @param themeName
         */
        function setActiveTheme(themeName)
        {
            fuseTheming.setActiveTheme(themeName);
        }

        /**
         * Get active theme
         *
         * @returns {service.themes.active|{name, theme}}
         */
        function getActiveTheme()
        {
            return fuseTheming.themes.active;
        }

        /**
         * Update layout mode
         */
        function updateLayoutMode()
        {
            var bodyEl = angular.element('body');

            // Update class on body element
            bodyEl.toggleClass('boxed', (vm.layoutMode === 'boxed'));
        }

        /**
         * Update layout style
         */
        function updateLayoutStyle()
        {
            // Update the cookie
            $cookies.put('layoutStyle', vm.layoutStyle);

            // Reload the page to apply the changes
            location.reload();
        }
    }

    /** @ngInject */
    function msThemeOptions($mdSidenav)
    { 
        return {
            restrict   : 'E',
            scope      : {},
            controller : 'MsThemeOptionsController as vm',
            templateUrl: 'app/core/theme-options/theme-options.html',
            compile    : function (tElement)
            {
                tElement.addClass('ms-theme-options');

                return function postLink(scope)
                {
                    /**
                     * Toggle options sidenav
                     */
                    function toggleOptionsSidenav()
                    {
						debugger;
						if(scope.redflagCon == true){
							scope.redflagCon = false;
						}else{
							scope.redflagCon = true;
						}
						
						scope.redFlagSlideFlag = true;
                        // Toggle the fuse theme options panel
                        $mdSidenav('fuse-theme-options').toggle();
						
						
						if($mdSidenav('fuse-theme-options1').isOpen()){
							$mdSidenav('fuse-theme-options1').hide();
						}
						
						if($mdSidenav('fuse-theme-options2').isOpen()){
							$mdSidenav('fuse-theme-options2').hide();
						}
						
						if($mdSidenav('fuse-theme-options3').isOpen()){
							$mdSidenav('fuse-theme-options3').hide();
						}
						
						if($mdSidenav('fuse-theme-options7').isOpen()){
							$mdSidenav('fuse-theme-options7').hide();
						}
						
                    }
					
					function toggleOptionsSidenav1()
                    {
                        // Toggle the fuse theme options panel
                        $mdSidenav('fuse-theme-options1').toggle();
						if($mdSidenav('fuse-theme-options').isOpen()){
							$mdSidenav('fuse-theme-options').hide();
						}
						
						if($mdSidenav('fuse-theme-options2').isOpen()){
							$mdSidenav('fuse-theme-options2').hide();
						}
						
						if($mdSidenav('fuse-theme-options3').isOpen()){
							$mdSidenav('fuse-theme-options3').hide();
						}
						
						if($mdSidenav('fuse-theme-options7').isOpen()){
							$mdSidenav('fuse-theme-options7').hide();
						}
                    }
					
					function toggleOptionsSidenav2()
                    {
                        // Toggle the fuse theme options panel
                        $mdSidenav('fuse-theme-options2').toggle();
					    if($mdSidenav('fuse-theme-options').isOpen()){
							$mdSidenav('fuse-theme-options').hide();
						}
						
						if($mdSidenav('fuse-theme-options1').isOpen()){
							$mdSidenav('fuse-theme-options1').hide();
						}
						
						if($mdSidenav('fuse-theme-options3').isOpen()){
							$mdSidenav('fuse-theme-options3').hide();
						}
						
						if($mdSidenav('fuse-theme-options7').isOpen()){
							$mdSidenav('fuse-theme-options7').hide();
						}
                    }
					
					function toggleOptionsSidenav3()
                    {
						if(scope.redflagCon == true){
							scope.redflagCon = false;
						}else{
							scope.redflagCon = true;
						}
						scope.reviewFlagSlideFlag = true;
                        // Toggle the fuse theme options panel
						$mdSidenav('fuse-theme-options3').toggle();
						if($mdSidenav('fuse-theme-options').isOpen()){
							$mdSidenav('fuse-theme-options').hide();
						}
						
						if($mdSidenav('fuse-theme-options1').isOpen()){
							$mdSidenav('fuse-theme-options1').hide();
						}
						
						if($mdSidenav('fuse-theme-options2').isOpen()){
							$mdSidenav('fuse-theme-options2').hide();
						}
						
						if($mdSidenav('fuse-theme-options7').isOpen()){
							$mdSidenav('fuse-theme-options7').hide();
						}
						
						
                    }
					
					function toggleOptionsSidenav4()
                    {
						debugger;
                       //localStorage.voiceIcon = $scope.arrowTabFlag;
                    }
					
					function toggleOptionsSidenav6()
                    {
						scope.redFlagSlideFlag = true;
						scope.reviewFlagSlideFlag = true;
						scope.redflagCon = false;
                    }
					
					function toggleOptionsSidenav7()
                    {
						if(scope.redflagCon == true){
							scope.redflagCon = false;
						}else{
							scope.redflagCon = true;
						}
						scope.reviewFlagSlideFlag = true;
						$mdSidenav('fuse-theme-options7').toggle();
						
						// if($mdSidenav('fuse-theme-options').isOpen()){
							// $mdSidenav('fuse-theme-options').hide();
						// }
						
						// if($mdSidenav('fuse-theme-options1').isOpen()){
							// $mdSidenav('fuse-theme-options1').hide();
						// }
						
						// if($mdSidenav('fuse-theme-options2').isOpen()){
							// $mdSidenav('fuse-theme-options2').hide();
						// }
						
						// if($mdSidenav('fuse-theme-options3').isOpen()){
							// $mdSidenav('fuse-theme-options3').hide();
						// }
                    }
                    // Expose the toggle function
                    scope.toggleOptionsSidenav = toggleOptionsSidenav;
					
					scope.toggleOptionsSidenav1 = toggleOptionsSidenav1;
					
					scope.toggleOptionsSidenav2 = toggleOptionsSidenav2;
					
					scope.toggleOptionsSidenav3 = toggleOptionsSidenav3;
					
					scope.toggleOptionsSidenav4 = toggleOptionsSidenav4;
					
					scope.toggleOptionsSidenav6 = toggleOptionsSidenav6;
					
					scope.toggleOptionsSidenav7 = toggleOptionsSidenav7;
                };
            }
        };
    }
})();