(function ()
{
    'use strict';

    angular
        .module('fuse')
        .controller('IndexController', IndexController);

    /** @ngInject */
    function IndexController(fuseTheming,$scope,$mdDialog,$timeout)
    {
        var vm = this;
		
		
		
		
		$('#hideIcon1').hide();
		$('#hideIcon2').hide();

        // Data
        vm.themes = fuseTheming.themes;

        //////////
		function notesController($scope, $mdDialog) {
  $scope.notestitle = localStorage.tabvalue;
	  var vm = this;
	  $scope.taToolbar = [
            ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'pre', 'quote', 'bold', 'italics', 'underline', 'strikeThrough', 'ul', 'ol', 'redo', 'undo', 'clear'],
            ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent', 'html', 'insertImage', 'insertLink', 'insertVideo', 'wordcount', 'charcount']
        ];
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  $scope.notespage = true;
$scope.savepopup = function(){
$mdDialog.cancel();
}
  }
  $scope.NoteSecFlag = false;
 
		
		$scope.notesInfo = function(ev,value) {
		
    $mdDialog.show({
      controller: notesController,
      templateUrl: 'app/main/add-customer/views/manual/form/notespage.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
     };
	 
	 
	 
    }
})();